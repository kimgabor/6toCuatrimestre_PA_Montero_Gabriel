const boton = document.getElementById("btnPerro"); // Busca el botón del HTML usando su id="btnPerro" y guarda ese elemento en la variable boton
const contenedor = document.getElementById("contenedor"); //Busca el div contenedor usando id=contenedor, y se moestraran las cards dinamicamente



boton.addEventListener("click", function(){ //agrega un evento al botony cuando el usuario haga click se ejcuta la funcion
    fetch("https://dog.ceo/api/breeds/image/random") //nuestro fetch realiza su peticion get y se elige una imagen random
    .then(response => { //.then() espera la respuesta del servidor y response es la respuesta
    return response.json();  //se convierte la respuesta de http a json y response.json() devuelve una promesa

    })

    .then(data => {   // este segundo .then() se ejecuta cuando el json ya fue convertido y data tiene el javascript final
     console.log(data);  //muestra el json completo 
        contenedor.innerHTML = ""; //limpia el contenido del contenedor esto para que no se queden ahi las cards 
        const card = document.createElement("div"); // se crea dinamicamente un div que es donde va la card
        card.classList.add("card"); // se agrega la clase card al div para darle estilo
        const imagen = document.createElement("img"); //se crea dinamicamente una etiqueta img para la imagen
        imagen.src = data.message;  //aqui se asigna la URL de la imagen al src y data.message tiene la url 
        const texto = document.createElement("p"); // se crea al igual que img una etiqueta p donde se muestra el nombre de la raza
        const partes = data.message.split("/"); //se divide la url para guardarla en un arreglo 
        const raza = partes[4]; //se obtiene la posicion 4 que es donde esta la raza del perro
        texto.textContent = "Raza: " + raza; //muestra el texto dentro de  p mas el nombre de la raza
        card.appendChild(imagen); //se inserta la imagen dentro de la imagen dentro del card
        card.appendChild(texto);  //se inserta el texto dentro del card
        contenedor.appendChild(card);  //se inserta el card completito dentro del div para que se muestre

    });

});