<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOG API</title>
    <link rel="stylesheet" href="assets/styles.css" >
</head>
<body>
    <h1> DOG API </h1>
     <button id="btnPerro">
        Obtener Perro
    </button>

    <div id="contenedor">
    </div>

    <script src="assets/script.js"></script>
</body>
</html>