const boton = document.getElementById("btnPersonajes");
const contenedor = document.getElementById("contenedor");


boton.addEventListener("click", function(){
    fetch("https://rickandmortyapi.com/api/character")
    .then(response => {
        return response.json();
    })

    .then(data => {
        data.results.forEach(personaje => {
            const card = document.createElement("div");
            card.classList.add("card");
            const imagen = document.createElement("img");
            imagen.src = personaje.image;
            const info = document.createElement("div");
            info.classList.add("info");
            const nombre = document.createElement("h2");
            nombre.textContent = personaje.name;
            const especie = document.createElement("p");
            especie.textContent = "Especie: " + personaje.species;
            const estado = document.createElement("p");
            estado.textContent = "Estado: " + personaje.status;
            const genero = document.createElement("p");
            genero.textContent = "Género: " + personaje.gender;

            info.appendChild(nombre);
            info.appendChild(especie);
            info.appendChild(estado);
            info.appendChild(genero);

            card.appendChild(imagen);
            card.appendChild(info);

            contenedor.appendChild(card);

        });

    });

});