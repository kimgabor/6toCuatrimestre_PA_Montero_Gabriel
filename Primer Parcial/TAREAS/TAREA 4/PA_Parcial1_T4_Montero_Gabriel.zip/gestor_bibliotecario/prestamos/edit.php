
<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0); // Recibimos el ID de la categoría desde la URL, mediante el método GET. Si no se proporciona un ID válido, se asigna el valor de 0. Y con intval() nos aseguramos que el valor sea un número entero.

    // Aquí va el código para obtener la categoría usando una consulta preparada
    if($id > 0){
         $stmt = $conn->prepare("SELECT 
                    prestamos.id, 
                    prestamos.id_usuario, 
                    prestamos.fecha_prestamo,
                    prestamos.fecha_devolucion, 
                    prestamos.estado,
                    usuarios.nombre AS Usuarios, 
                    libros.titulo AS Libro,
                    detalle_prestamo.id_libro
                FROM prestamos
                INNER JOIN usuarios ON prestamos.id_usuario = usuarios.id
                INNER JOIN detalle_prestamo ON prestamos.id = detalle_prestamo.id_prestamo
                INNER JOIN libros ON detalle_prestamo.id_libro = libros.id
                WHERE prestamos.id = ?
                
                ");  // En esta línea preparamos una consulta SQL, para mostrar las categorías. Esto lo hacemos mediante una consulta "SELECT", la cual seleccionará los campos "id", "nombre" y "descripcion" de la tabla "categorías".
     // Obtenemos la fila del resultado como un array asociativo y lo almacenamos en la variable $categoria.
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $prestamo = $resultado->fetch_assoc(); // Guardamos los datos actuales en la variable $prestamo
        $stmt->close();


        // obtengo los usuarios
       $stmt = $conn->prepare("SELECT id, nombre FROM usuarios ORDER BY nombre"); 
        $stmt->execute();
        $resultado_usuarios = $stmt->get_result();
        $usuarios = [];
        while($row = $resultado_usuarios->fetch_assoc()){ 
            $usuarios[] = $row; 
        }
        $stmt->close();

        // obtengo los libros
        $stmt = $conn->prepare("SELECT id, titulo FROM libros ORDER BY titulo"); 
        $stmt->execute();
        $resultado_libros = $stmt->get_result();
        $libros = [];
        while($row = $resultado_libros->fetch_assoc()){ 
            $libros[] = $row; 
        }
        $stmt->close();
    } else {

    header("Location: index.php?error=" . urlencode("ID inválido"));
    exit;
}
?>
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Prestamo</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $prestamo["id"] ?? $id ?>">

        <div class="form-group">
           <label><i class="fas fa-user"></i> Usuario</label>
            <select name="usuario" required>
                <option value="">Seleccionar Usuario</option>
                <?php
                // CORRECCIÓN: Cambiado a foreach para leer correctamente tu array de $usuarios sin romper PHP
                foreach ($usuarios as $u) {
                    $selected = ($u["id"] == $prestamo["id_usuario"]) ? "selected" : "";
                    echo "<option value='" . $u["id"] . "' $selected>" . htmlspecialchars($u["nombre"]) . "</option>";
                }
                ?>
            </select>
        </div>


        <div class="form-group">
           <label><i class="fas fa-book"></i> Libro</label>
            <select name="libro" required>
                <option value="">Seleccionar Libro</option>
                <?php foreach($libros as $l): ?>
                    <option value="<?= $l['id'] ?>" <?= $l['id'] == $prestamo['id_libro'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($l['titulo']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

            <div class="form-group">
            <label><i class="fas fa-calendar-alt"></i> Fecha de Préstamo</label>
            <input type="date" name="fecha_prestamo" value="<?= date('Y-m-d', strtotime($prestamo['fecha_prestamo'])) ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar-check"></i> Fecha de Devolución</label>
            <input type="date" name="fecha_devolucion" value="<?= date('Y-m-d', strtotime($prestamo['fecha_devolucion'])) ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-info-circle"></i> Estado</label>
            <select name="estado" required>
                <option value="">Seleccionar Estado</option>
                <option value="prestado" <?= $prestamo['estado'] === 'prestado' ? 'selected' : '' ?>>Prestado</option>
                <option value="devuelto" <?= $prestamo['estado'] === 'devuelto' ? 'selected' : '' ?>>Devuelto</option>
                <option value="retrasado" <?= $prestamo['estado'] === 'retrasado' ? 'selected' : '' ?>>Retrasado</option>
            </select>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
