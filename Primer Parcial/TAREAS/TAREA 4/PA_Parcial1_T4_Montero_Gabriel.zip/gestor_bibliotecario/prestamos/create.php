<?php
    require_once "../config/connection.php";

    $stmt = $conn->prepare("SELECT id, nombre FROM usuarios ORDER BY nombre"); 
    $stmt->execute(); // Ejecutamos la consulta
    $resultado_usuarios = $stmt->get_result(); // Obtengo el resultado de la consulta y lo guardo en una variable
    
    $usuarios = []; // Creo un array vacío para guardar los usuarios obtenidos
    while($row = $resultado_usuarios->fetch_assoc()){ // Recorro el resultado de la consulta usando un while
        $usuarios[] = $row; // Guardamos cada fila (usuario) dentro de nuestro arreglo
    }
    $stmt->close(); // Cerramos la consulta preparada para liberar recursos
?>

<?php
    require_once "../config/connection.php";

    $stmt = $conn->prepare("SELECT id, titulo FROM libros ORDER BY titulo"); 
    $stmt->execute(); // Ejecutamos la consulta
    $resultado_libros = $stmt->get_result(); // Obtengo el resultado de la consulta y lo guardo en una variable
    
    $libros = []; // Creo un array vacío para guardar los libros obtenidos
    while($row = $resultado_libros->fetch_assoc()){ // Recorro el resultado de la consulta usando un while
        $libros[] = $row; // Guardamos cada fila (libro) dentro de nuestro arreglo
    }
    $stmt->close(); // Cerramos la consulta preparada para liberar recursos
?>

<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Préstamo</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>  
<div class="card">
    <form action="save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Usuario</label>
            <select name="id_usuario" required>
                <option value="">Seleccionar Usuario</option>
                <?php
                    foreach($usuarios as $usuario){
                        echo "<option value='" . $usuario["id"] . "'>" . htmlspecialchars($usuario["nombre"]) . "</option>";
                    }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-book"></i> Libro</label>
            <select name="id_libro" required>
                <option value="">Seleccionar Libro</option>
                <?php
                    foreach($libros as $libro){
                        echo "<option value='" . $libro["id"] . "'>" . htmlspecialchars($libro["titulo"]) . "</option>";
                    }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Fecha de Préstamo</label>
            <input type="date" name="fecha_prestamo" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-lock"></i>Fecha de Devolución</label>
            <input type="date" name="fecha_devolucion" required>
        </div>

       <div class="form-group">
    <label><i class="fas fa-info-circle"></i> Estado</label>
    <select name="estado" required>
        <option value="">Seleccionar Estado</option>
        <option value="prestado">Prestado</option>
        <option value="devuelto">Devuelto</option>
        <option value="retrasado">Retrasado</option>
    </select>
</div>

        

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
