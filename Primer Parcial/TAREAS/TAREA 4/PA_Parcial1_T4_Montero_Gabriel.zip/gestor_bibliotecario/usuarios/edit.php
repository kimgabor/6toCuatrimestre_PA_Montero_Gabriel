<?php
    require_once "../config/connection.php";

    $stmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY nombre"); 
    $stmt->execute(); // Ejecutamos la consulta
    $resultado_roles = $stmt->get_result(); // Obtengo el resultado de la consulta y lo guardo en una variable
    
    $roles = []; // Creo un array vacío para guardar los roles obtenidos
    while($row = $resultado_roles->fetch_assoc()){ // Recorro el resultado de la consulta usando un while
        $roles[] = $row; // Guardamos cada fila (rol) dentro de nuestro arreglo
    }
    $stmt->close(); // Cerramos la consulta preparada para liberar recursos
?>
<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0); // Recibimos el ID de la categoría desde la URL, mediante el método GET. Si no se proporciona un ID válido, se asigna el valor de 0. Y con intval() nos aseguramos que el valor sea un número entero.

    // Aquí va el código para obtener la categoría usando una consulta preparada
    if($id > 0){
        $stmt = $conn->prepare("SELECT usuarios.id, usuarios.nombre, usuarios.apellido,
                usuarios.correo,
                usuarios.`password`, 
                usuarios.telefono,
       roles.nombre AS ROL, 
                usuarios.activo,
                usuarios.fecha_registro 
       FROM usuarios
       INNER JOIN roles
       ON usuarios.id_rol = roles.id WHERE usuarios.id = ? "); // En esta línea preparamos una consulta SQL, para mostrar las categorías. Esto lo hacemos mediante una consulta "SELECT", la cual seleccionará los campos "id", "nombre" y "descripcion" de la tabla "categorías".
        $stmt->bind_param("i", $id); // Lo que hacemos es decirle a la consulta que el marcador de posición es un número entero (i) y que el valor que pasará es el de la variable $id.
        $stmt->execute(); // Ejecutamos la consulta preparada.
        $resultado = $stmt->get_result(); // Obtenemos el resultado de la consulta
        $usuario = $resultado->fetch_assoc(); // Obtenemos la fila del resultado como un array asociativo y lo almacenamos en la variable $categoria.
        $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
        $conn->close(); // Cerramos la conexión a la base de datos para liberar recursos
    }else{
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
?>

<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Usuario</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $usuario["id"] ?? $id ?>">

        <div class="form-group">
            <label><i class="fas fa-tag"></i> Nombre</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($usuario["nombre"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Apellido</label>
            <input type="text" name="apellido" value="<?= htmlspecialchars($usuario["apellido"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo</label>
            <input type="email" name="correo" value="<?= htmlspecialchars($usuario["correo"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-lock"></i> Contraseña</label>
            <input type="password" name="password" value="<?= htmlspecialchars($usuario["password"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-phone"></i> Teléfono</label>
            <input type="text" name="telefono" value="<?= htmlspecialchars($usuario["telefono"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user-tag"></i> Rol</label>
            <select name="id_rol" required>
                <option value="">Seleccionar rol</option>
                <?php
                foreach($roles as $rol){
                        echo "<option value='" . $rol["id"] . "'>" . htmlspecialchars($rol["nombre"]) . "</option>";
                    }
                ?>
            </select>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
