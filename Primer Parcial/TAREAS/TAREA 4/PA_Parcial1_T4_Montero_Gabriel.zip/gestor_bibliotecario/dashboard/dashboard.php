<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor Bibliotecario</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <h2><i class="fas fa-book-open"></i> Bibliotech</h2>
        <p>Sistema de Gestión</p>
    </div>
    <?php $ruta = $_SERVER['PHP_SELF']; ?>
    <nav class="sidebar-nav">
        <a href="../categorias/index.php" <?= strpos($ruta, 'categorias') !== false ? 'class="active"' : '' ?>><i class="fas fa-tags"></i> Categorías</a>
        <a href="../autores/index.php" <?= strpos($ruta, 'autores') !== false ? 'class="active"' : '' ?>><i class="fas fa-user"></i> Autores</a>
        <a href="../libros/index.php" <?= strpos($ruta, 'libros') !== false ? 'class="active"' : '' ?>><i class="fas fa-book"></i> Libros</a>
        <a href="../usuarios/index.php" <?= strpos($ruta, 'usuarios') !== false ? 'class="active"' : '' ?>><i class="fas fa-users"></i> Usuarios</a>
        <a href="../prestamos/index.php" <?= strpos($ruta, 'prestamos') !== false ? 'class="active"' : '' ?>><i class="fas fa-hand-holding-heart"></i> Préstamos</a>
    </nav>
</aside>

<div class="main-content">
    <h1>Bienvenido al Dashboard</h1>
    <p>Desde aquí puedes gestionar todas las secciones de tu biblioteca.</p>

    <div class="video-container" style="margin-top: 20px; max-width: 800px;">
        <h3>IMAGEN DE REFERENCIA</h3>
       <div class="image-container" style="margin-top: 20px; max-width: 600px;">
        <img 
            src="https://img.freepik.com/premium-photo/magnificent-medieval-fantasy-library-with-countless-books-scrolls-dramatic-lighting-candleli_961179-424.jpg" 
            alt="Ilustración de Biblioteca Bibliotech" 
            style="width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);"
        >
    </div>
    </div>
</div>