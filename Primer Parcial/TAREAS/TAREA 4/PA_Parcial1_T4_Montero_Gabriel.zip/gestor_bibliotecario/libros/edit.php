<?php
require_once "../config/connection.php";

$id = intval($_GET["id"] ?? 0);

if ($id > 0) {
    $stmt = $conn->prepare("
        SELECT 
            libros.id,
            libros.titulo,
            libros.isbn,
            libros.anio_publicacion,
            libros.editorial,
            libros.cantidad,
            libros.disponibles,
            categorias.id AS id_categoria
        FROM libros
        INNER JOIN categorias
            ON libros.id_categoria = categorias.id
        WHERE libros.id = ?
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $libro = $resultado->fetch_assoc();
    $stmt->close();

    /////// AUTORES

    $stmtAutoresLibro = $conn->prepare("
        SELECT id_autor
        FROM libro_autor
        WHERE id_libro = ?
    ");

    $stmtAutoresLibro->bind_param("i", $id);
    $stmtAutoresLibro->execute();
    $resultadoAutoresLibro = $stmtAutoresLibro->get_result();
    $autoresSeleccionados = [];
    while ($fila = $resultadoAutoresLibro->fetch_assoc()) {
        $autoresSeleccionados[] = $fila["id_autor"];
    }
    $stmtAutoresLibro->close();
////////// CATEGORIAS 
    $stmtCategorias = $conn->prepare("
        SELECT id, nombre
        FROM categorias
    ");
    $stmtCategorias->execute();
    $categorias = $stmtCategorias->get_result();
    $stmtAutores = $conn->prepare("
        SELECT id, nombre
        FROM autores
    ");
    $stmtAutores->execute();
    $autores = $stmtAutores->get_result();
} else {

    header("Location: index.php?error=" . urlencode("ID inválido"));
    exit;
}
?>

<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book-open"></i> Editar Libro</h1>

    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">

    <form action="update.php" method="POST">

        <input type="hidden" name="id" value="<?= $libro["id"] ?>">

        <div class="form-group">
            <label>
                <i class="fas fa-book"></i> Título
            </label>

            <input
                type="text"
                name="titulo"
                value="<?= htmlspecialchars($libro["titulo"]) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label>
                <i class="fas fa-barcode"></i> ISBN
            </label>

            <input
                type="text"
                name="isbn"
                value="<?= htmlspecialchars($libro["isbn"]) ?>"
            >
        </div>

        <div class="form-group">
            <label>
                <i class="fas fa-calendar"></i> Año de Publicación
            </label>

            <input
                type="number"
                name="anio_publicacion"
                value="<?= $libro["anio_publicacion"] ?>"
                min="1000"
                max="<?= date('Y') ?>"
            >
        </div>

        <div class="form-group">
            <label>
                <i class="fas fa-building"></i> Editorial
            </label>

            <input
                type="text"
                name="editorial"
                value="<?= htmlspecialchars($libro["editorial"]) ?>"
            >
        </div>

        <div class="form-group">
            <label>
                <i class="fas fa-cubes"></i> Cantidad
            </label>

            <input
                type="number"
                name="cantidad"
                value="<?= $libro["cantidad"] ?>"
                min="0"
            >
        </div>

        <div class="form-group">
            <label>
                <i class="fas fa-check-circle"></i> Disponibles
            </label>

            <input
                type="number"
                name="disponibles"
                value="<?= $libro["disponibles"] ?>"
                min="0"
            >
        </div>

        <!-- Categorías -->
        <div class="form-group">

            <label>
                <i class="fas fa-tag"></i> Categoría
            </label>

            <select name="id_categoria" required>

                <option value="">
                    -- Selecciona una categoría --
                </option>

                <?php
                while ($categoria = $categorias->fetch_assoc()) {

                    $selected = (
                        $categoria["id"] == $libro["id_categoria"]
                    ) ? "selected" : "";

                    echo "<option value='" . $categoria["id"] . "' $selected>";

                    echo htmlspecialchars($categoria["nombre"]);

                    echo "</option>";
                }
                ?>

            </select>

        </div>

        <!-- Autores -->
        <div class="form-group">

            <label>
                <i class="fas fa-user"></i> Autor(es)
            </label>

            <select name="id_autores[]" multiple required>

                <?php
                while ($autor = $autores->fetch_assoc()) {

                    $selected = in_array(
                        $autor["id"],
                        $autoresSeleccionados
                    ) ? "selected" : "";

                    echo "<option value='" . $autor["id"] . "' $selected>";

                    echo htmlspecialchars($autor["nombre"]);

                    echo "</option>";
                }
                ?>

            </select>

            <small>
                Mantén Ctrl (o Cmd) para seleccionar varios autores
            </small>

        </div>

        <div class="form-actions">

            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>

            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>

        </div>

    </form>

</div>

<?php
$stmtCategorias->close();
$stmtAutores->close();
$conn->close();
?>

<?php include_once "../includes/footer.php"; ?>