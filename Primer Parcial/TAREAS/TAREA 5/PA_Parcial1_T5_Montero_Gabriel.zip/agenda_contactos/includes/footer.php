<footer class="bg-light py-3 border-top">

</footer>

<!-- Bootstrap -->
<script src="../assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>


</body>
</html>