
<?php

require_once "../config/connection.php";

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {

            header("Location: index.php");
            exit;
        }

                $nombre = trim($_POST["nombre"] ?? "");
                $apellido = trim($_POST["apellido"] ?? "");
                $telefono = trim($_POST["telefono"] ?? "");
                $correo = trim($_POST["correo"] ?? "");
                $direccion = trim($_POST["direccion"] ?? "");
                $categoria = trim($_POST["categoria"] ?? "");

                    if ($nombre === "" || $apellido === "") {

                        header(
                         "Location: create.php?error=" .
                         urlencode("Nombre y apellido son obligatorios"));
                        exit;
                    }

$sql = "
    INSERT INTO contactos (nombre, apellido, telefono, correo, direccion, categoria) VALUES ( ?, ?, ?, ?, ?, ? )";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    header(
    "Location: create.php?error=" .
    urlencode("Error en la consulta SQL"));
    exit;
}

$stmt->bind_param(
    "ssssss", $nombre, $apellido, $telefono, $correo, $direccion, $categoria );

        if ($stmt->execute()) {
          header(
             "Location: index.php?success=" .
             urlencode("Contacto creado exitosamente"));
        } else {
         header(
              "Location: create.php?error=" .
             urlencode("Error al guardar contacto"));
        }
        $stmt->close();
        $conn->close();
?>