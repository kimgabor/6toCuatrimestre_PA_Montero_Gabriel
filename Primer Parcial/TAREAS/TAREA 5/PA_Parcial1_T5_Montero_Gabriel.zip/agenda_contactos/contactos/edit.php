<?php
require_once "../config/connection.php";
$id = intval($_GET["id"] ?? 0);
if ($id <= 0) {
    header(
        "Location: index.php?error=" .
        urlencode("ID inválido"));
    exit;
}
$sql = " SELECT id, nombre, apellido, telefono, correo, direccion, categoria FROM contactos WHERE id = ? ";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();
$contacto = $resultado->fetch_assoc();
$stmt->close();
if (!$contacto) {
    header(
        "Location: index.php?error=" .
        urlencode("Contacto no encontrado"));
        exit;
}
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1>
        <i class="fas fa-user-edit"></i>
        Editar Contacto
    </h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i>
        Volver
    </a>
</div>
<div class="d-flex justify-content-center">
    <div class="card text-start">
        <form action="update.php" method="POST">
            <input
                type="hidden"
                name="id"
                value="<?= htmlspecialchars($contacto["id"]) ?>"
            >
            <div class="form-group">
                <label>
                    <i class="fas fa-user"></i>
                    Nombre
                </label>
                <input
                    type="text"
                    name="nombre"
                    value="<?= htmlspecialchars($contacto["nombre"]) ?>"
                    required
                >
            </div>
            <div class="form-group">
                <label>
                    <i class="fas fa-user"></i>
                    Apellido
                </label>
                <input
                    type="text"
                    name="apellido"
                    value="<?= htmlspecialchars($contacto["apellido"]) ?>"
                    required
                >
            </div>
            <div class="form-group">
                <label>
                    <i class="fas fa-phone"></i>
                    Teléfono
                </label>
                <input
                    type="text"
                    name="telefono"
                    value="<?= htmlspecialchars($contacto["telefono"]) ?>"
                >
            </div>

            <div class="form-group">
                <label>
                    <i class="fas fa-envelope"></i>
                    Correo
                </label>

                <input
                    type="email"
                    name="correo"
                    value="<?= htmlspecialchars($contacto["correo"]) ?>"
                >

            </div>

            <div class="form-group">
                <label>
                    <i class="fas fa-map-marker-alt"></i>
                    Dirección
                </label>
                <textarea
                    name="direccion"
                ><?= htmlspecialchars($contacto["direccion"]) ?></textarea>
            </div>

            <div class="form-group">
                <label>
                    <i class="fas fa-tags"></i>
                    Categoría
                </label>
                <select name="categoria">
                    <option
                        value="Familiar"
                        <?= $contacto["categoria"] === "Familiar" ? "selected" : "" ?>
                    >
                        Familiar
                    </option>
                    <option
                        value="Trabajo"
                        <?= $contacto["categoria"] === "Trabajo" ? "selected" : "" ?>
                    >
                        Trabajo
                    </option>

                    <option
                        value="Amigos"
                        <?= $contacto["categoria"] === "Amigos" ? "selected" : "" ?>
                    >
                        Amigos
                    </option>

                    <option
                        value="General"
                        <?= $contacto["categoria"] === "General" ? "selected" : "" ?>
                    >
                        General
                    </option>
                </select>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save"></i>
                    Actualizar
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Cancelar
                </a>
            </div>
        </form>
    </div>
</div>
<?php
$conn->close();

?>

<?php include_once "../includes/footer.php"; ?>
```
