<?php
    require_once "../config/connection.php";
    $id = intval($_GET["id"] ?? 0);
    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    // Aquí va el código para eliminar el contacto usando una consulta preparada
    $stmt = $conn->prepare("DELETE FROM contactos WHERE id = ?");
    $stmt->bind_param("i", $id);
    if($stmt->execute()){
    header("Location: index.php?success=" . urlencode("Contacto eliminado correctamente :)"));
    exit;
    } else {
        header("Location: index.php?error=" .urlencode("Error al tratar de eliminar el contacto:" .$stmt->error));
        exit;
    }

?>
