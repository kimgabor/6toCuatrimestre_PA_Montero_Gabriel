
<?php require_once "../config/connection.php";?>

<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1>
        <i class="fas fa-user-plus"></i>
        Nuevo Contacto
    </h1>

    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i>
        Volver
    </a>
</div>

<?php if (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
            <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="d-flex justify-content-center">

    <div class="card text-start">

     <form action="save.php" method="POST">

         <div class="form-group">
             <label>
                 <i class="fas fa-user"></i>
                  Nombre
            </label>

                <input
                    type="text"
                    name="nombre"
                    placeholder="Ej: Gabriel"
                     >
          </div>

            <div class="form-group">
                <label>
                    <i class="fas fa-user"></i>
                    Apellido
                </label>

                <input
                    type="text"
                    name="apellido"
                    placeholder="Ej: García"
                    
                >
            </div>

            <div class="form-group">
                <label>
                    <i class="fas fa-phone"></i>
                    Teléfono
                </label>

                <input
                    type="text"
                    name="telefono"
                    placeholder="Ej: 9811234567"
                >
            </div>

            <div class="form-group">
                <label>
                    <i class="fas fa-envelope"></i>
                    Correo
                </label>

                <input
                    type="email"
                    name="correo"
                    placeholder="Ej: correo@email.com"
                >
            </div>

            <div class="form-group">
                <label>
                    <i class="fas fa-map-marker-alt"></i>
                    Dirección
                </label>

                <textarea
                    name="direccion"
                    placeholder="Ej: Calle 123, Colonia Centro"
                ></textarea>
            </div>

            <div class="form-group">
                <label>
                    <i class="fas fa-tags"></i>
                    Categoría
                </label>

                <select name="categoria">

                    <option value="Familiar">
                        Familiar
                    </option>

                    <option value="Trabajo">
                        Trabajo
                    </option>

                    <option value="Amigos">
                        Amigos
                    </option>

                    <option value="General">
                        General
                    </option>

                </select>
            </div>

            <div class="form-actions">

                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save"></i>
                    Guardar
                </button>

                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Cancelar
                </a>

            </div>

        </form>

    </div>

</div>

<?php include_once "../includes/footer.php"; ?>