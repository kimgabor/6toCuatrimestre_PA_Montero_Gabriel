
        <?php

        require_once "../config/connection.php";

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {

         header("Location: index.php");
         exit;
        }

            $id = intval($_POST["id"] ?? 0);

            $nombre = trim($_POST["nombre"] ?? "");
            $apellido = trim($_POST["apellido"] ?? "");
            $telefono = trim($_POST["telefono"] ?? "");
            $correo = trim($_POST["correo"] ?? "");
            $direccion = trim($_POST["direccion"] ?? "");
            $categoria = trim($_POST["categoria"] ?? "");

                if ($id <= 0 || $nombre === "" || $apellido === "") {

                 header(
                      "Location: index.php?error=" .
                     urlencode("Datos inválidos"));
                    exit;
                }

$sql = " UPDATE contactos SET nombre = ?, apellido = ?, telefono = ?, correo = ?, direccion = ?, categoria = ? WHERE id = ?";

$stmt = $conn->prepare($sql);

        if (!$stmt) {

         header(
             "Location: index.php?error=" .
             urlencode("Error en la consulta SQL"));
            exit;
        }

$stmt->bind_param( "ssssssi", $nombre, $apellido, $telefono, $correo, $direccion, $categoria, $id);

if ($stmt->execute()) {

    header(
        "Location: index.php?success=" .
        urlencode("Contacto actualizado exitosamente")
    );

} else {

    header(
        "Location: index.php?error=" .
        urlencode("Error al actualizar contacto")
    );
}

$stmt->close();
$conn->close();

?>

