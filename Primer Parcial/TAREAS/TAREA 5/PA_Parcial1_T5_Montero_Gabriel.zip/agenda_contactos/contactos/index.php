<?php
    require_once "../config/connection.php";
?>
<?php include_once "../includes/header.php"; ?>



<div class="page-header">
    <br>
    <h1><i class="fas fa-users mt-5"></i><br> CONTACTOS</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i><br> NUEVO CONTACTO
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-responsive">

<table class="table table-striped table-hover table-bordered align-middle">

    <thead class="table-dark">
        
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Teléfono</th>
                <th>Correo</th>
                <th>Dirección</th>
                <th>Categoría</th>
                <th>Fecha de Registro</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
           <?php

        $stmt = $conn->prepare(
           " SELECT id, nombre, apellido, telefono, correo, direccion, categoria, fecha_registro FROM contactos
        ");

        $stmt->execute();

        $resultado = $stmt->get_result();

        while ($row = $resultado->fetch_assoc()) {

            echo "<tr>";

            echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["nombre"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["apellido"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["telefono"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["correo"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["direccion"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["categoria"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["fecha_registro"]) . "</td>";

                echo "<td class='actions'>";

                echo "<a href='edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'>
                        <i class='fas fa-edit'></i> Editar
                     </a>";

                echo "<a href='delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger'>
                      <i class='fas fa-trash'></i> Eliminar
                     </a>";

                echo "</td>";

                echo "</tr>";
}

        $stmt->close();
        $conn->close();

?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>
