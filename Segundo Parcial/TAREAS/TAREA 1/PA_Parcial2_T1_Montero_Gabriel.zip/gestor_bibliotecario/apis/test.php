<?php

header("Content-Type: application/json");

echo json_encode([
    "metodo" => $_SERVER["REQUEST_METHOD"]
]);