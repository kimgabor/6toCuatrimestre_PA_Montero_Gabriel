<?php
require_once('../config/connection.php');

// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Procesar la solicitud
        // Endpoint para obtener un rol por ID
        // http://localhost/gestor_bibliotecario/gestor_bibliotecario/api/api-roles.php?id=1
        
        switch ($method){
        case 'GET':
            if (isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn -> prepare ("SELECT id, nombre FROM roles WHERE id = ?");
                $stmt -> bind_param("i" , $id);
                $stmt -> execute();
                $resultado = $stmt-> get_result();
                if($resultado->num_rows > 0){
                    $rol = $resultado-> fetch_assoc();
                    echo json_encode($rol);
                } else {
                    echo json_encode(array("mensaje" => "Rol no encontrado"));
                }
                $stmt->close();
                $conn->close();

            } else {

            // Endpoint para obtener todos los roles
            // http://localhost/gestor_bibliotecario/gestor_bibliotecario/api/api-roles.php
            $stmt = $conn->prepare("SELECT * FROM roles");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $roles = array();
            while ($row = $resultado->fetch_assoc()) {
                $roles[] = $row;
            }
            echo json_encode($roles);
            $stmt->close();
            $conn->close();
        }
break;
default:
http_response_code(405);
echo json_encode(array("mensaje" => "Método no permitido"));
break;
}