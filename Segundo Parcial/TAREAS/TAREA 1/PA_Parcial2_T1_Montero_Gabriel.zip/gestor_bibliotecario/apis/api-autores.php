<?php
require_once('../config/connection.php');

// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];
// Procesar la solicitud
switch ($method) {
case 'GET':
        // Buscar autor por ID
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido FROM autores WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $autor = $resultado->fetch_assoc();
                echo json_encode($autor);
            } else {
                echo json_encode(array(
                    "mensaje" => "Autor no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        }
        // Buscar autor por nombre
        elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido FROM autores WHERE nombre LIKE ?");
            $nombre_param = "%".$nombre."%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            if (count($autores) > 0) {
                echo json_encode($autores);
            } else {
                echo json_encode(array(
                    "mensaje" => "Autor no encontrado"
                ));
            }

            $stmt->close();
            $conn->close();
        }

        // Buscar autor por nacionalidad
        elseif (isset($_GET['nacionalidad'])) {
            $nacionalidad = trim($_GET['nacionalidad']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad FROM autores WHERE nacionalidad LIKE ?");
            $nacionalidad_param = "%".$nacionalidad."%";
            $stmt->bind_param("s", $nacionalidad_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            if (count($autores) > 0) {
                echo json_encode($autores);
            } else {
                echo json_encode(array(
                    "mensaje" => "Autor no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();

        } 
        //Obtener autores nacidos despues de cierta fecha
        elseif(isset($_GET['fecha_nacimiento'])){
            $fecha_nacimiento = trim($_GET['fecha_nacimiento']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, fecha_nacimiento FROM autores WHERE fecha_nacimiento > ?");
            $stmt->bind_param("s", $fecha_nacimiento);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()){
                $autores[] = $row;
            } 
            if(count($autores) > 0){
                echo json_encode($autores);
            } else{
                echo json_encode(array( "mensaje" => "Autores no encontrados"));
            }
            $stmt->close();
            $conn->close();

        }
        // Obtener todos los autores
        else {
            $stmt = $conn->prepare("SELECT * FROM autores");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            echo json_encode($autores);
            $stmt->close();
            $conn->close();
        }
        break;
    default:
    http_response_code(405);
 echo json_encode(array("mensaje" => "Método no permitido"));
        break;
}