<?php
require_once('../config/connection.php');

// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
        case 'GET':
        // Buscar usuario por ID
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn->prepare("SELECT id, nombre, apellido FROM usuarios WHERE id=?");
                $stmt -> bind_param("i", $id);
                $stmt -> execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    echo json_encode($resultado->fetch_assoc());
                } else {
                    echo json_encode(array("mensaje" => "Usuario no encontrado"));
                }
                $stmt -> close();
                $conn->close();
            }

        // Buscar usuario por nombre
        elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido FROM usuarios WHERE nombre LIKE ?");
            $nombre_param = "%".$nombre."%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();
            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }
            echo json_encode($usuarios);
            $stmt->close();
            $conn->close();
        }
        // Buscar usuario por correo
        elseif (isset($_GET['correo'])) {
            $correo = trim($_GET['correo']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo FROM usuarios WHERE correo = ?");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                echo json_encode(array(
                    "mensaje" => "Correo no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        }
        // Obtener todos los usuarios
        else {
            $stmt = $conn->prepare("SELECT * FROM usuarios");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();
            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }
            echo json_encode($usuarios);
            $stmt->close();
            $conn->close();
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array(
            "mensaje" => "Método no permitido"
        ));
        break;
} 