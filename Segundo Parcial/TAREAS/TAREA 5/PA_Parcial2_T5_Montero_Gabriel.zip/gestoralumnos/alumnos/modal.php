<div class="modal fade" id="modalAlumno" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="formAlumno">
                <div class="modal-header">
                    <h5 class="modal-title" id="tituloModal">
                        Nuevo Alumno
                    </h5>
                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                    </button>
                </div>
 <div class="modal-body">
 <input type="hidden" id="idAlumno">
         <div class="row g-3">
        <div class="col-md-6">
                <label class="form-label">
                    Matrícula
                 </label>
             <input
                type="text"
              id="matricula"
             class="form-control"
             required>
            </div>
            <div class="col-md-6">
                 <label class="form-label">
                    Nombre
                   </label>
                    <input
                     type="text"
                     id="nombre"
                    class="form-control"
                     required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">
                                Apellido paterno
                            </label>
                            <input
                                type="text"
                                id="apellidoPaterno"
                                class="form-control"
                                required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">
                                Apellido materno
                            </label>
                            <input
                                type="text"
                                id="apellidoMaterno"
                                class="form-control"
                                required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">
                                Correo
                            </label>
                            <input
                                type="email"
                                id="correo"
                                class="form-control"
                                required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">
                                Teléfono
                            </label>
                            <input
                                type="text"
                                id="telefono"
                                class="form-control"
                                required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">
                                Carrera
                            </label>
                            <select
                                id="carrera"
                                class="form-select"
                                required>
                                <option value="">
                                    Seleccione una carrera
                                </option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">
                                Cuatrimestre
                            </label>
                            <select
                                id="cuatrimestre"
                                class="form-select"
                                required>
                                <option value="">
                                    Seleccione un cuatrimestre
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        class="btn btn-primary">
                        Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>