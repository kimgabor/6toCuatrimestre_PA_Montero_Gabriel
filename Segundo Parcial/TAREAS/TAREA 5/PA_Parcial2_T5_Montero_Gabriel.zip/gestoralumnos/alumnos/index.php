<?php
$titulo = "Alumnos";
$modulo = "alumnos";
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<div class="container-fluid">
    <div class="mb-4">
        <h1 class="h3 fw-bold mb-1">
            Gestión de Alumnos
        </h1>
        <p class="text-muted mb-0">
            Administra los alumnos registrados en el sistema.
        </p>
    </div>
    <div id="alertas"></div>
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-header bg-white border-0 py-3">
            <div class="row g-3 align-items-center">
                <div class="col-lg-4">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="bi bi-search"></i>
                        </span>
                        <input
                            type="text"
                            id="buscarAlumno"
                            class="form-control"
                            placeholder="Buscar alumno...">
                    </div>
                </div>
                <div class="col-lg-2">
                    <select
                        class="form-select"
                        id="filtroCarrera">
                        <option value="">
                            Todas las carreras
                        </option>
                    </select>
                </div>
                <div class="col-lg-2">
                    <select
                        class="form-select"
                        id="filtroCuatrimestre">
                        <option value="">
                            Todos los cuatrimestres
                        </option>
                    </select>
                </div>
                <div class="col-lg-2">
                    <button
                        class="btn btn-outline-primary w-100"
                        id="btnActualizar">
                        <i class="bi bi-arrow-clockwise me-2"></i>
                        Actualizar
                    </button>
                </div>
                <div class="col-lg-2">
                    <button
                        class="btn btn-primary w-100"
                        id="btnNuevo"
                        data-bs-toggle="modal"
                        data-bs-target="#modalAlumno">
                        <i class="bi bi-plus-circle me-2"></i>
                           Nuevo
                 </button>
             </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                 <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Matrícula</th>
                            <th>Nombre</th>
                            <th>Carrera</th>
                            <th>Cuatrimestre</th>
                            <th>Correo</th>
                            <th width="150">
                                Acciones
                            </th>
                        </tr>
                    </thead>
                    <tbody id="tbodyAlumnos">
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <div class="spinner-border text-primary"></div>
                                <div class="mt-3">
                                    Cargando alumnos...
                                </div>
                     </td>
                      </tr>
         </tbody>
     </table>
       </div>
     </div>
     </div>
 </div>
<?php include 'modal.php'; ?>
<script src="<?= URL_BASE ?>assets/js/alumnos.js"></script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>