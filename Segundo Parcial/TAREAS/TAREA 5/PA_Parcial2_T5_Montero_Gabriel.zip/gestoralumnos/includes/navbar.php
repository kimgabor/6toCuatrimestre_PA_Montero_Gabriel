<?php
$currentFolder = basename(dirname($_SERVER['PHP_SELF']));
$currentFile = basename($_SERVER['PHP_SELF']);
if ($currentFolder === '' || $currentFolder === '.' || $currentFile === 'index.php' && $currentFolder === basename($_SERVER['DOCUMENT_ROOT'])) {
    $activePage = 'inicio';
} else {
    $activePage = $currentFolder;
}
?>
<div class="offcanvas-lg offcanvas-start sidebar" tabindex="-1" id="sidebar">
    <div class="offcanvas-header d-lg-none bg-dark text-white">
        <h5 class="offcanvas-title ">
            <i class="bi bi-mortarboard-fill me-2"></i>
            Sistema Gestor
        </h5>
        <button type="button"
                class="btn-close btn-close-white"
                data-bs-dismiss="offcanvas">
        </button>
    </div>
    <div class="offcanvas-body d-flex flex-column p-0">
        <!-- Logo -->
        <div class="sidebar-header text-center py-4 border-bottom">
            <i class="bi bi-mortarboard-fill display-5"></i>
            <h5 class="textonegros fw-bold">
                Sistema Gestor
            </h5>
            <small class="text-secondary">
                Gestión de Alumnos
            </small>
        </div>
        <ul class="nav nav-pills flex-column p-3">
            <li class="nav-item mb-1">
                <a href="<?= URL_BASE ?>index.php"
                   class="nav-link <?= $activePage == 'inicio' ? 'active' : '' ?>">
                    <i class="bi bi-house-door me-2"></i>
                    Inicio
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= URL_BASE ?>carreras/"
                   class="nav-link <?= $activePage == 'carreras' ? 'active' : '' ?>">
                    <i class="bi bi-mortarboard me-2"></i>
                    Carreras
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= URL_BASE ?>cuatrimestres/"
                   class="nav-link <?= $activePage == 'cuatrimestres' ? 'active' : '' ?>">
                    <i class="bi bi-calendar3 me-2"></i>
                    Cuatrimestres
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= URL_BASE ?>materias/"
                   class="nav-link <?= $activePage == 'materias' ? 'active' : '' ?>">
                    <i class="bi bi-book me-2"></i>
                    Materias
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= URL_BASE ?>alumnos/"
                   class="nav-link <?= $activePage == 'alumnos' ? 'active' : '' ?>">
                    <i class="bi bi-people me-2"></i>
                    Alumnos
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= URL_BASE ?>inscripciones/"
                   class="nav-link <?= $activePage == 'inscripciones' ? 'active' : '' ?>">
                    <i class="bi bi-journal-check me-2"></i>
                    Inscripciones
                </a>
            </li>
        </ul>
        <div class="mt-auto border-top text-center py-3">
            <small class="text-secondary d-block">
                Sistema Gestor de Alumnos
            </small>
            <small class="text-secondary d-block">
                Versión 1.0
            </small>
            <small class="text-secondary">
                &copy; 2026
            </small>
        </div>
    </div>
</div>
<main class="main-content">