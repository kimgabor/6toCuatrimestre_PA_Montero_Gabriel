<?php

$titulo = "Carreras";
$modulo = "carreras";

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';

?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 fw-bold mb-1">
                Gestión de Carreras
            </h1>

            <p class="text-muted mb-0">
                Consulta las carreras registradas dentro del sistema.
            </p>
        </div>
    </div>

    <div id="alertas"></div>

    <div class="card shadow-sm border-0 rounded-4">

        <div class="card-header bg-white border-0 py-3">

            <div class="row g-3 align-items-center">

                <div class="col-md-8">

                    <div class="input-group">

                        <span class="input-group-text bg-light">
                            <i class="bi bi-search"></i>
                        </span>

                        <input
                            type="text"
                            id="buscarCarrera"
                            class="form-control"
                            placeholder="Buscar carrera...">

                    </div>

                </div>

                <div class="col-md-4 text-md-end">

                    <button
                        class="btn btn-outline-primary"
                        id="btnActualizar">

                        <i class="bi bi-arrow-clockwise me-2"></i>

                        Actualizar

                    </button>

                </div>

            </div>

        </div>

        <div class="card-body p-0">

            <div class="table-responsive">

                <table
                    class="table table-hover align-middle mb-0"
                    id="tablaCarreras">

                    <thead>

                        <tr>

                            <th width="10%">ID</th>

                            <th width="35%">Nombre</th>

                            <th width="40%">Descripción</th>

                            <th width="15%">Estado</th>

                        </tr>

                    </thead>

                    <tbody id="tbodyCarreras">

                        <tr>

                            <td colspan="4" class="text-center py-5">

                                <div
                                    class="spinner-border text-primary"
                                    role="status">

                                    <span class="visually-hidden">
                                        Cargando...
                                    </span>

                                </div>

                                <div class="mt-3 text-muted">

                                    Cargando carreras...

                                </div>

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<script src="<?= URL_BASE ?>assets/js/carreras.js"></script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>