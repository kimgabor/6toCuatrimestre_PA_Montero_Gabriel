<?php
$titulo = "Cuatrimestres";
$modulo = "cuatrimestres";
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 fw-bold mb-1">
                Gestión de Cuatrimestres
            </h1>
            <p class="text-muted mb-0">
                Consulta los cuatrimestres registrados dentro del sistema.
            </p>
        </div>
    </div>
    <div id="alertas"></div>
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-header bg-white border-0 py-3">
            <div class="row g-3 align-items-center">
                <div class="col-md-8">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="bi bi-search"></i>
                        </span>
                        <input
                            type="text"
                            id="buscarCuatrimestre"
                            class="form-control"
                            placeholder="Buscar cuatrimestre...">
                    </div>
                </div>
                <div class="col-md-4 text-md-end">
                    <button
                        class="btn btn-outline-primary"
                        id="btnActualizar">
                        <i class="bi bi-arrow-clockwise me-2"></i>
                        Actualizar
                    </button>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="text-center" width="20%">ID</th>
                            <th>Cuatrimestre</th>
                        </tr>
                    </thead>
                    <tbody id="tbodyCuatrimestres">
                        <tr>
                            <td colspan="2" class="text-center py-5">
                                <div class="spinner-border text-primary"></div>
                                <div class="mt-3">
                                    Cargando cuatrimestres...
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="<?= URL_BASE ?>assets/js/cuatrimestres.js"></script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>