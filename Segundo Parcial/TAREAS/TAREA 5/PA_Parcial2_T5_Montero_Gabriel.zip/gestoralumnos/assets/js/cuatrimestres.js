const API_URL = "../api/cuatrimestres.php";
let cuatrimestres = [];
document.addEventListener("DOMContentLoaded", () => {
    document
        .getElementById("btnActualizar")
        .addEventListener("click", cargarCuatrimestres);
    document
        .getElementById("buscarCuatrimestre")
        .addEventListener("input", buscarCuatrimestre);
    cargarCuatrimestres();
});
async function cargarCuatrimestres() {
    mostrarSpinner();
    try {
        const response = await fetch(API_URL);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const resultado = await response.json();
        if (!resultado.success) {
            throw new Error(resultado.message);
        }
        cuatrimestres = resultado.data;
        mostrarCuatrimestres(cuatrimestres);
    } catch (error) {
        console.error(error);
        mostrarAlerta(
            "No se pudieron cargar los cuatrimestres.",
            "danger"
        );
    }
}
function mostrarCuatrimestres(datos) {
    const tbody = document.getElementById("tbodyCuatrimestres");
    if (datos.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="2" class="text-center py-4">
                    No existen cuatrimestres registrados.
                </td>
            </tr>
        `;
        return;
    }
    let html = "";
    datos.forEach(cuatrimestre => {
        html += `
<tr>
    <td class="text-center fw-semibold">
        ${cuatrimestre.id}
    </td>
    <td>
        ${cuatrimestre.nombre}
    </td>
</tr>
`;
    });
    tbody.innerHTML = html;
}
function buscarCuatrimestre() {
    const texto = document
        .getElementById("buscarCuatrimestre")
        .value
        .toLowerCase();
    const filtrados = cuatrimestres.filter(cuatrimestre =>
        cuatrimestre.nombre
            .toLowerCase()
            .includes(texto)
    );
    mostrarCuatrimestres(filtrados);
}
function mostrarSpinner() {
    document.getElementById("tbodyCuatrimestres").innerHTML = `
        <tr>
            <td colspan="2" class="text-center py-5">
                <div class="spinner-border text-primary"></div>
                <div class="mt-3">
                    Cargando cuatrimestres...
                </div>
            </td>
        </tr>
    `;
}
function mostrarAlerta(mensaje, tipo) {
    document.getElementById("alertas").innerHTML = `
        <div class="alert alert-${tipo} alert-dismissible fade show">
            ${mensaje}
            <button
                class="btn-close"
                data-bs-dismiss="alert">
            </button>
        </div>
    `;
}