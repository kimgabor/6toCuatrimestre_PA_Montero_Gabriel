
const API_URL = "../api/carreras.php";
let carreras = [];
document.addEventListener("DOMContentLoaded", () => {
    document
        .getElementById("btnActualizar")
        .addEventListener("click", cargarCarreras);
    document
        .getElementById("buscarCarrera")
        .addEventListener("input", buscarCarrera);
    cargarCarreras();
});
async function cargarCarreras() {
    mostrarSpinner();
    try {
        const response = await fetch(API_URL);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const resultado = await response.json();
        if (!resultado.success) {
            throw new Error(resultado.message);
        }
        carreras = resultado.data;
        mostrarCarreras(carreras);
    } catch (error) {
        console.error(error);
        mostrarAlerta(
            "No se pudieron cargar las carreras.",
            "danger"
        );
    }
}

function mostrarCarreras(datos) {
    const tbody = document.getElementById("tbodyCarreras");
    if (!datos || datos.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="2" class="text-center py-4">
                    No existen carreras registradas.
                </td>
            </tr>
        `;
        return;
    }
    let html = "";
    datos.forEach(carrera => {
        html += `
            <tr>
                <td>${carrera.id}</td>
                <td>${carrera.nombre}</td>
            </tr>
        `;
    });
    tbody.innerHTML = html;
}

function buscarCarrera() {
    const texto = document
        .getElementById("buscarCarrera")
        .value
        .toLowerCase();
    const filtradas = carreras.filter(carrera =>
        carrera.nombre
            .toLowerCase()
            .includes(texto)
    );
    mostrarCarreras(filtradas);
}

function mostrarSpinner() {
    document.getElementById("tbodyCarreras").innerHTML = `
        <tr>
            <td colspan="2" class="text-center py-5">
                <div class="spinner-border text-primary"></div>
                <div class="mt-3">
                    Cargando carreras...
                </div>
            </td>
        </tr>
    `;
}

function mostrarAlerta(mensaje, tipo) {
    const alertas = document.getElementById("alertas");
    alertas.innerHTML = `
        <div class="alert alert-${tipo} alert-dismissible fade show">
            ${mensaje}
            <button
                class="btn-close"
                data-bs-dismiss="alert">
            </button>
        </div>
    `;
}