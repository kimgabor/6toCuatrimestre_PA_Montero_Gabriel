// ==========================================================
// Sistema Gestor de Alumnos - Módulo de Alumnos
// Archivo: assets/js/alumnos.js
// ==========================================================
// Variables
const API_ALUMNOS = '../api/alumnos.php';
const API_CARRERAS = '../api/carreras.php';
const API_CUATRIMESTRES = '../api/cuatrimestres.php';
let modalAlumno = null;
document.addEventListener("DOMContentLoaded", () => {
    console.log("1. DOM cargado");
    modalAlumno = new bootstrap.Modal(document.getElementById("modalAlumno"));
    console.log("2. Modal creado");
    inicializarEventos();
    console.log("3. Eventos inicializados");
    cargarCarreras();
    console.log("4. cargarCarreras llamada");
    cargarCuatrimestres();
    console.log("5. cargarCuatrimestres llamada");
    cargarAlumnos();
    console.log("6. cargarAlumnos llamada");
});
// Eventos
function inicializarEventos() {
    document.getElementById("btnNuevo").addEventListener("click", abrirModalNuevo);
    document.getElementById("formAlumno").addEventListener("submit", guardarAlumno);
    document.getElementById("btnActualizar").addEventListener("click", actualizarVista);
    document.getElementById("buscarAlumno").addEventListener("input", cargarAlumnos);
    document.getElementById("filtroCarrera").addEventListener("change", cargarAlumnos);
    document.getElementById("filtroCuatrimestre").addEventListener("change", cargarAlumnos);
    // Delegación de eventos para los botones dinámicos en la tabla
    document.getElementById("tbodyAlumnos").addEventListener("click", (e) => {
        if (e.target.closest(".btnEditar")) {
            editarAlumno(e.target.closest(".btnEditar").dataset.id);
        } else if (e.target.closest(".btnEliminar")) {
            eliminarAlumno(e.target.closest(".btnEliminar").dataset.id);
        }
    });
}
// Carga de datos
async function cargarCarreras() {
    try {
        const response = await fetch(API_CARRERAS);
        if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
        const data = await response.json();
        if (!data.success) throw new Error(data.message || "Error al obtener carreras");
        poblarSelect(data.data, "filtroCarrera", "Todas las carreras");
        poblarSelect(data.data, "carrera", "Seleccione una carrera");
    } catch (error) {
        console.error("Error al cargar carreras:", error);
        mostrarAlerta("No se pudieron cargar las carreras.", "danger");
    }
}
async function cargarCuatrimestres() {
    try {
        const response = await fetch(API_CUATRIMESTRES);
        if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
        const data = await response.json();
        if (!data.success) throw new Error(data.message || "Error al obtener cuatrimestres");
        poblarSelect(data.data, "filtroCuatrimestre", "Todos los cuatrimestres");
        poblarSelect(data.data, "cuatrimestre", "Seleccione un cuatrimestre");
    } catch (error) {
        console.error("Error al cargar cuatrimestres:", error);
        mostrarAlerta("No se pudieron cargar los cuatrimestres.", "danger");
    }
}
async function cargarAlumnos() {
    mostrarSpinner();
    const buscar = document.getElementById("buscarAlumno").value.trim();
    const carrera = document.getElementById("filtroCarrera").value;
    const cuatrimestre = document.getElementById("filtroCuatrimestre").value;
    const params = new URLSearchParams();
    if (buscar) params.append("nombre", buscar);
    if (carrera) params.append("carrera", carrera);
    if (cuatrimestre) params.append("cuatrimestre", cuatrimestre);
    const url = `${API_ALUMNOS}${params.toString() ? '?' + params.toString() : ''}`;
    try {
        const response = await fetch(url);
        // Corrección 1: Si es 404, no mostrar error, renderiza vacío y termina
        if (response.status === 404) {
            renderizarTabla([]);
            return;
        }
        if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
        const data = await response.json();
        if (data.success && data.data.length > 0) {
            renderizarTabla(data.data);
        } else {
            renderizarTabla([]);
        }
    } catch (error) {
        console.error("Error en cargarAlumnos:", error);
        document.getElementById("tbodyAlumnos").innerHTML = `
            <tr>
                <td colspan="7" class="text-center text-danger py-4">
                    Error al cargar los alumnos.
                </td>
            </tr>
        `;
        mostrarAlerta("No se pudieron cargar los alumnos. " + error.message, "danger");
    }
}
// Renderizado
function renderizarTabla(data) {
    const tbody = document.getElementById("tbodyAlumnos");
    if (!tbody) return;
    if (!data.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="10" class="text-center text-muted py-4">
                    No se encontraron alumnos.
                </td>
            </tr>
        `;
        return;
    }
    tbody.innerHTML = data.map(alumno => `
        <tr>
            <td>${alumno.id}</td>
            <td>${alumno.matricula}</td>
            <td>${alumno.nombre}</td>
            <td>${alumno.apellido_paterno}</td>
            <td>${alumno.apellido_materno}</td>
            <td>${alumno.correo}</td>
            <td>${alumno.telefono}</td>
            <td>${alumno.carrera}</td>
            <td>${alumno.cuatrimestre}</td>
            <td class="text-end">
                <button
                    class="btn btn-sm btn-outline-primary btnEditar"
                    data-id="${alumno.id}">
                    <i class="bi bi-pencil"></i>
                </button>
                <button
                    class="btn btn-sm btn-outline-danger btnEliminar"
                    data-id="${alumno.id}">
                    <i class="bi bi-trash-fill"></i>
                </button>
            </td>
        </tr>
    `).join("");
}
function poblarSelect(datos, selectId, textoDefault) {
    const select = document.getElementById(selectId);
    select.innerHTML = `<option value="">${textoDefault}</option>`;
    datos.forEach(item => {
        select.innerHTML += `<option value="${item.id}">${item.nombre}</option>`;
    });
}
function mostrarSpinner() {
    document.getElementById("tbodyAlumnos").innerHTML = `
        <tr>
            <td colspan="7" class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2 text-muted">Cargando alumnos...</p>
            </td>
        </tr>
    `;
}
// CRUD
function abrirModalNuevo() {
    document.getElementById("formAlumno").reset();
    document.getElementById("idAlumno").value = "";
    document.getElementById("tituloModal").textContent = "Nuevo Alumno";
    modalAlumno.show();
}
async function editarAlumno(id) {
    try {
        const response = await fetch(`${API_ALUMNOS}?id=${id}`);
        // Prevenir error si la API devuelve 404 al buscar un alumno por ID
        if (response.status === 404) {
            mostrarAlerta("Alumno no encontrado.", "warning");
            return;
        }
        if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
        const data = await response.json();
        // Corrección 2: La API responde con un array en "data", se toma el elemento 0
        if (!data.success || data.data.length === 0) {
            mostrarAlerta("Alumno no encontrado.", "warning");
            return;
        }
        const alumno = data.data[0];
        document.getElementById("idAlumno").value = alumno.id;
        document.getElementById("matricula").value = alumno.matricula;
        document.getElementById("nombre").value = alumno.nombre;
        document.getElementById("apellidoPaterno").value = alumno.apellido_paterno || '';
        document.getElementById("apellidoMaterno").value = alumno.apellido_materno || '';
        document.getElementById("correo").value = alumno.correo;
        document.getElementById("telefono").value = alumno.telefono;
        document.getElementById("carrera").value = alumno.id_carrera;
        document.getElementById("cuatrimestre").value = alumno.cuatrimestre_actual;
        document.getElementById("tituloModal").textContent = "Editar Alumno";
        modalAlumno.show();
    } catch (error) {
        console.error("Error en editarAlumno:", error);
        mostrarAlerta("No se pudieron cargar los datos del alumno.", "danger");
    }
}
async function guardarAlumno(e) {
    e.preventDefault();
    if (!validarFormulario()) return;
    const id = document.getElementById("idAlumno").value;
    // Construir el JSON exactamente como lo espera la API
    const payload = {
        matricula: document.getElementById("matricula").value.trim(),
        nombre: document.getElementById("nombre").value.trim(),
        apellido_paterno: document.getElementById("apellidoPaterno").value.trim(),
        apellido_materno: document.getElementById("apellidoMaterno").value.trim(),
        correo: document.getElementById("correo").value.trim(),
        telefono: document.getElementById("telefono").value.trim(),
        id_carrera: document.getElementById("carrera").value,
        cuatrimestre_actual: document.getElementById("cuatrimestre").value
    };
    // Si hay ID, es PUT, de lo contrario es POST
    const method = id ? "PUT" : "POST";
    const url = id ? `${API_ALUMNOS}?id=${id}` : API_ALUMNOS;
    try {
        const response = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || "Error al guardar el alumno");
        modalAlumno.hide();
        cargarAlumnos();
        mostrarAlerta(id ? "Alumno actualizado correctamente." : "Alumno registrado correctamente.", "success");
    } catch (error) {
        console.error("Error en guardarAlumno:", error);
        mostrarAlerta("No se pudo guardar el alumno. " + error.message, "danger");
    }
}
async function eliminarAlumno(id) {
    if (!confirm("¿Está seguro de eliminar a este alumno?")) return;
    try {
        const response = await fetch(`${API_ALUMNOS}?id=${id}`, { method: "DELETE" });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || "Error al eliminar el alumno");
        cargarAlumnos();
        mostrarAlerta("Alumno eliminado correctamente.", "success");
    } catch (error) {
        console.error("Error en eliminarAlumno:", error);
        mostrarAlerta("No se pudo eliminar el alumno. " + error.message, "danger");
    }
}
// Utilidades
function actualizarVista() {
    document.getElementById("buscarAlumno").value = "";
    document.getElementById("filtroCarrera").value = "";
    document.getElementById("filtroCuatrimestre").value = "";
    cargarAlumnos();
}
function validarFormulario() {
    const matricula = document.getElementById("matricula").value.trim();
    const nombre = document.getElementById("nombre").value.trim();
    const apellidoPaterno = document.getElementById("apellidoPaterno").value.trim();
    const apellidoMaterno = document.getElementById("apellidoMaterno").value.trim();
    const correo = document.getElementById("correo").value.trim();
    const telefono = document.getElementById("telefono").value.trim();
    const carrera = document.getElementById("carrera").value;
    const cuatrimestre = document.getElementById("cuatrimestre").value;
    if (!matricula || !nombre || !apellidoPaterno || !apellidoMaterno || !correo || !telefono || !carrera || !cuatrimestre) {
        mostrarAlerta("Todos los campos son obligatorios.", "warning");
        return false;
    }
    return true;
}
function mostrarAlerta(mensaje, tipo) {
    const contenedor = document.getElementById("alertas");
    const alerta = document.createElement("div");
    alerta.className = `alert alert-${tipo} alert-dismissible fade show`;
    alerta.role = "alert";
    alerta.innerHTML = `
        ${mensaje}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    contenedor.appendChild(alerta);
    // Ocultar automáticamente después de 4 segundos
    setTimeout(() => {
        if (alerta.classList.contains("show")) {
            bootstrap.Alert.getOrCreateInstance(alerta).close();
        }
    }, 4000);
}