<?php
require_once __DIR__ . '/../config/connection.php';
header('Content-Type: application/json; charset=utf-8');
 $method = $_SERVER['REQUEST_METHOD'];
try {
    switch ($method) {
        case 'GET':
            $sql = "SELECT a.id, a.matricula, a.nombre, a.apellido_paterno, a.apellido_materno, a.correo, a.telefono, a.id_carrera, a.cuatrimestre_actual, c.nombre AS carrera, cu.nombre AS cuatrimestre  FROM alumnos a   INNER JOIN carreras c ON a.id_carrera = c.id   INNER JOIN cuatrimestres cu ON a.cuatrimestre_actual = cu.id ";
            $conditions = [];
            $params = [];
            $types = '';
            if (isset($_GET['id']) && !empty($_GET['id'])) {
                $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
                if ($id !== false) {
                    $conditions[] = "a.id = ?";
                    $params[] = $id;
                    $types .= 'i';
                }
            }
            if (isset($_GET['matricula']) && !empty($_GET['matricula'])) {
                $conditions[] = "a.matricula = ?";
                $params[] = $_GET['matricula'];
                $types .= 's';
            }
            if (isset($_GET['nombre']) && !empty($_GET['nombre'])) {
                $conditions[] = "a.nombre LIKE ?";
                $params[] = "%" . $_GET['nombre'] . "%";
                $types .= 's';
            }
            if (isset($_GET['carrera']) && !empty($_GET['carrera'])) {
                $carreraId = filter_var($_GET['carrera'], FILTER_VALIDATE_INT);
                if ($carreraId !== false) {
                    $conditions[] = "a.id_carrera = ?";
                    $params[] = $carreraId;
                    $types .= 'i';
                }
            }
            if (isset($_GET['cuatrimestre']) && !empty($_GET['cuatrimestre'])) {
                $cuatrimestreId = filter_var($_GET['cuatrimestre'], FILTER_VALIDATE_INT);
                if ($cuatrimestreId !== false) {
                    $conditions[] = "a.cuatrimestre_actual = ?";
                    $params[] = $cuatrimestreId;
                    $types .= 'i';
                }
            }
            if (!empty($conditions)) {
                $sql .= " WHERE " . implode(" AND ", $conditions);
            }
            $sql .= " ORDER BY a.nombre ASC";
            $stmt = $mysqli->prepare($sql);
            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }
            $stmt->execute();
            $result = $stmt->get_result();
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            if (count($data) > 0) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Consulta realizada correctamente',
                    'data' => $data
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'message' => 'Alumno no encontrado'
                ]);
            }
            break;
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Datos JSON inválidos o vacíos.']);
                exit;
            }
            $matricula = trim($data['matricula'] ?? '');
            $nombre = trim($data['nombre'] ?? '');
            $apellido_paterno = trim($data['apellido_paterno'] ?? '');
            $apellido_materno = trim($data['apellido_materno'] ?? '');
            $correo = trim($data['correo'] ?? '');
            $telefono = trim($data['telefono'] ?? '');
            $id_carrera = filter_var($data['id_carrera'] ?? null, FILTER_VALIDATE_INT);
            $cuatrimestre_actual = filter_var($data['cuatrimestre_actual'] ?? null, FILTER_VALIDATE_INT);
            if (empty($matricula) || empty($nombre) || empty($apellido_paterno) || empty($apellido_materno) || empty($correo) || empty($telefono) || empty($id_carrera) || empty($cuatrimestre_actual)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios.']);
                exit;
            }
            if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'El formato del correo electrónico no es válido.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM alumnos WHERE matricula = ?");
            $stmt->bind_param('s', $matricula);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'La matrícula ya está registrada.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM alumnos WHERE correo = ?");
            $stmt->bind_param('s', $correo);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'El correo electrónico ya está registrado.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM carreras WHERE id = ?");
            $stmt->bind_param('i', $id_carrera);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'La carrera especificada no existe.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM cuatrimestres WHERE id = ?");
            $stmt->bind_param('i', $cuatrimestre_actual);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'El cuatrimestre especificado no existe.']);
                exit;
            }
            $stmt = $mysqli->prepare("INSERT INTO alumnos (matricula, nombre, apellido_paterno, apellido_materno, correo, telefono, id_carrera, cuatrimestre_actual) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param('ssssssii', $matricula, $nombre, $apellido_paterno, $apellido_materno, $correo, $telefono, $id_carrera, $cuatrimestre_actual);
            $stmt->execute();
            http_response_code(201);
            echo json_encode(['success' => true, 'message' => 'Alumno registrado correctamente']);
            break;
        case 'PUT':
            $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID de alumno no proporcionado o inválido.']);
                exit;
            }
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Datos JSON inválidos o vacíos.']);
                exit;
            }
            $matricula = trim($data['matricula'] ?? '');
            $nombre = trim($data['nombre'] ?? '');
            $apellido_paterno = trim($data['apellido_paterno'] ?? '');
            $apellido_materno = trim($data['apellido_materno'] ?? '');
            $correo = trim($data['correo'] ?? '');
            $telefono = trim($data['telefono'] ?? '');
            $id_carrera = filter_var($data['id_carrera'] ?? null, FILTER_VALIDATE_INT);
            $cuatrimestre_actual = filter_var($data['cuatrimestre_actual'] ?? null, FILTER_VALIDATE_INT);
            if (empty($matricula) || empty($nombre) || empty($apellido_paterno) || empty($apellido_materno) || empty($correo) || empty($telefono) || empty($id_carrera) || empty($cuatrimestre_actual)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios.']);
                exit;
            }
            if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'El formato del correo electrónico no es válido.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM alumnos WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Alumno no encontrado.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM alumnos WHERE matricula = ? AND id != ?");
            $stmt->bind_param('si', $matricula, $id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'La matrícula ingresada ya pertenece a otro alumno.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM carreras WHERE id = ?");
            $stmt->bind_param('i', $id_carrera);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'La carrera especificada no existe.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM cuatrimestres WHERE id = ?");
            $stmt->bind_param('i', $cuatrimestre_actual);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'El cuatrimestre especificado no existe.']);
                exit;
            }
            $stmt = $mysqli->prepare("UPDATE alumnos SET matricula = ?, nombre = ?, apellido_paterno = ?, apellido_materno = ?, correo = ?, telefono = ?, id_carrera = ?, cuatrimestre_actual = ? WHERE id = ?");
            $stmt->bind_param('ssssssiii', $matricula, $nombre, $apellido_paterno, $apellido_materno, $correo, $telefono, $id_carrera, $cuatrimestre_actual, $id);
            $stmt->execute();
            echo json_encode(['success' => true, 'message' => 'Alumno actualizado correctamente']);
            break;
        case 'PATCH':
            $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID de alumno no proporcionado o inválido.']);
                exit;
            }
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Datos JSON inválidos o vacíos.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM alumnos WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Alumno no encontrado.']);
                exit;
            }
            $setClauses = [];
            $params = [];
            $types = '';
            if (isset($data['matricula'])) {
                $matricula = trim($data['matricula']);
                if (empty($matricula)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'La matrícula no puede estar vacía.']);
                    exit;
                }
                $stmt = $mysqli->prepare("SELECT id FROM alumnos WHERE matricula = ? AND id != ?");
                $stmt->bind_param('si', $matricula, $id);
                $stmt->execute();
                if ($stmt->get_result()->num_rows > 0) {
                    http_response_code(409);
                    echo json_encode(['success' => false, 'message' => 'La matrícula ingresada ya pertenece a otro alumno.']);
                    exit;
                }
                $setClauses[] = "matricula = ?";
                $params[] = $matricula;
                $types .= 's';
            }
            if (isset($data['nombre'])) {
                $nombre = trim($data['nombre']);
                if (empty($nombre)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'El nombre no puede estar vacío.']);
                    exit;
                }
                $setClauses[] = "nombre = ?";
                $params[] = $nombre;
                $types .= 's';
            }
            if (isset($data['apellido_paterno'])) {
                $apellido_paterno = trim($data['apellido_paterno']);
                if (empty($apellido_paterno)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'El apellido paterno no puede estar vacío.']);
                    exit;
                }
                $setClauses[] = "apellido_paterno = ?";
                $params[] = $apellido_paterno;
                $types .= 's';
            }
            if (isset($data['apellido_materno'])) {
                $apellido_materno = trim($data['apellido_materno']);
                if (empty($apellido_materno)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'El apellido materno no puede estar vacío.']);
                    exit;
                }
                $setClauses[] = "apellido_materno = ?";
                $params[] = $apellido_materno;
                $types .= 's';
            }
            if (isset($data['correo'])) {
                $correo = trim($data['correo']);
                if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'El formato del correo electrónico no es válido.']);
                    exit;
                }
                $setClauses[] = "correo = ?";
                $params[] = $correo;
                $types .= 's';
            }
            if (isset($data['telefono'])) {
                $telefono = trim($data['telefono']);
                $setClauses[] = "telefono = ?";
                $params[] = $telefono;
                $types .= 's';
            }
            if (isset($data['id_carrera'])) {
                $id_carrera = filter_var($data['id_carrera'], FILTER_VALIDATE_INT);
                if (!$id_carrera) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'El ID de carrera no es válido.']);
                    exit;
                }
                $stmt = $mysqli->prepare("SELECT id FROM carreras WHERE id = ?");
                $stmt->bind_param('i', $id_carrera);
                $stmt->execute();
                if ($stmt->get_result()->num_rows === 0) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'La carrera especificada no existe.']);
                    exit;
                }
                $setClauses[] = "id_carrera = ?";
                $params[] = $id_carrera;
                $types .= 'i';
            }
            if (isset($data['cuatrimestre_actual'])) {
                $cuatrimestre_actual = filter_var($data['cuatrimestre_actual'], FILTER_VALIDATE_INT);
                if (!$cuatrimestre_actual) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'El ID de cuatrimestre no es válido.']);
                    exit;
                }
                $stmt = $mysqli->prepare("SELECT id FROM cuatrimestres WHERE id = ?");
                $stmt->bind_param('i', $cuatrimestre_actual);
                $stmt->execute();
                if ($stmt->get_result()->num_rows === 0) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'El cuatrimestre especificado no existe.']);
                    exit;
                }
                $setClauses[] = "cuatrimestre_actual = ?";
                $params[] = $cuatrimestre_actual;
                $types .= 'i';
            }
            if (empty($setClauses)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'No se proporcionaron campos válidos para actualizar.']);
                exit;
            }
            $sql = "UPDATE alumnos SET " . implode(', ', $setClauses) . " WHERE id = ?";
            $params[] = $id;
            $types .= 'i';
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            echo json_encode(['success' => true, 'message' => 'Alumno actualizado correctamente']);
            break;
        case 'DELETE':
            $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID de alumno no proporcionado o inválido.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM alumnos WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Alumno no encontrado.']);
                exit;
            }
            $stmt = $mysqli->prepare("SELECT id FROM inscripciones WHERE id_alumno = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'No se puede eliminar el alumno porque tiene inscripciones asociadas.']);
                exit;
            }
            $stmt = $mysqli->prepare("DELETE FROM alumnos WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            echo json_encode(['success' => true, 'message' => 'Alumno eliminado correctamente']);
            break;
        default:
            http_response_code(405);
            echo json_encode([
                'success' => false,
                'message' => 'Método no permitido.'
            ]);
            break;
    }
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error interno en la base de datos.",
        "dev" => $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno del servidor.',
        'dev' => $e->getMessage()
    ]);
}