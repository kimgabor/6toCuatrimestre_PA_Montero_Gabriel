<?php
require_once __DIR__ . '/../config/connection.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido. Esta API solo soporta GET.'
    ]);
    exit;
}

try {
    if (isset($_GET['id']) && !empty($_GET['id'])) {
        $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

        if ($id === false) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'El ID proporcionado no es válido.'
            ]);
            exit;
        }

        $stmt = $mysqli->prepare("SELECT * FROM carreras WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();
            echo json_encode([
                'success' => true,
                'message' => 'Consulta realizada correctamente',
                'data' => $data
            ]);
        } else {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'message' => 'Carrera no encontrada'
            ]);
        }
    } else {
        $result = $mysqli->query("SELECT * FROM carreras ORDER BY nombre ASC");
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        if (count($data) > 0) {
            echo json_encode([
                'success' => true,
                'message' => 'Consulta realizada correctamente',
                'data' => $data
            ]);
        } else {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'message' => 'No se encontraron carreras registradas'
            ]);
        }
    }
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno en la base de datos.',
        'dev' => $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno del servidor.',
        'dev' => $e->getMessage()
    ]);
}