<?php

require_once __DIR__ . '/../config/connection.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido. Esta API solo soporta GET.'
    ]);
    exit;
}
try {
    $result = $mysqli->query("SELECT * FROM cuatrimestres ORDER BY id ASC");

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    if (count($data) > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Consulta realizada correctamente',
            'data' => $data
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'No existen cuatrimestres registrados'
        ]);
    }
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno en la base de datos.',
        'dev' => $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno del servidor.',
        'dev' => $e->getMessage()
    ]);
}