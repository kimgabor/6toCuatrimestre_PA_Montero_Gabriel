<?php/*
    require_once "../config/connection.php";
    $id = intval($_GET["id"] ?? 0);
    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
    // Aquí va el código para eliminar el libro usando una consulta preparada
    $stmt = $conn->prepare("DELETE FROM libros WHERE id = ?");
    $stmt->bind_param("i", $id);
    if($stmt->execute()){
    header("Location: index.php?success=" . urlencode("Libro eliminado correctamente :)"));
    exit;
    } else {
        header("Location: index.php?error=" .urlencode("Error al tratar de eliminar el libro:" .$stmt->error));
        exit;
    }
*/
?>
<?php
$id = intval($_GET["id"] ?? 0);
if ($id <= 0) {
    header("Location: index.php?error=" . urlencode("ID inválido"));
    exit;
}
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-libros.php?id=" . $id;
$opciones = array(
    "http" => array(
        "method" => "DELETE",
        "header" => "Content-Type: application/json\r\n"
    )
);
$contexto = stream_context_create($opciones);
$respuesta = file_get_contents($url, false, $contexto);
if ($respuesta === FALSE) {
    header("Location: index.php?error=" . urlencode("No fue posible eliminar el libro"));
    exit;
}
$resultado = json_decode($respuesta, true);
if (isset($resultado["mensaje"])) {
    header("Location: index.php?success=" . urlencode($resultado["mensaje"]));
} else {
    header("Location: index.php?error=" . urlencode("Error al eliminar el libro"));
}
exit;
?>