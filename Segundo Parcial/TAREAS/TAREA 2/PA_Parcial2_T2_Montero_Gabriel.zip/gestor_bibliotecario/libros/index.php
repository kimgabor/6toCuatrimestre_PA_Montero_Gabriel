<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1><i class="fas fa-book"></i> Libros</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Libro
    </a>
</div>
<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>
<?php
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-libros.php";
$respuesta = file_get_contents($url);
$libros = json_decode($respuesta, true);
?>
<div class="table-container">
<table>
<thead>
<tr>
<th>#</th>
<th>Título</th>
<th>ISBN</th>
<th>Categoría</th>
<th>Año</th>
<th>Editorial</th>
<th>Cantidad</th>
<th>Disponibles</th>
<th>Acciones</th>
</tr>
</thead>
<tbody>
<?php
if(is_array($libros)){
    foreach($libros as $libro){
        echo "<tr>";
        echo "<td>".htmlspecialchars($libro["id"])."</td>";
        echo "<td>".htmlspecialchars($libro["titulo"])."</td>";
        echo "<td>".htmlspecialchars($libro["isbn"])."</td>";
        echo "<td>".htmlspecialchars($libro["categoria"])."</td>";
        echo "<td>".htmlspecialchars($libro["anio_publicacion"])."</td>";
        echo "<td>".htmlspecialchars($libro["editorial"])."</td>";
        echo "<td>".htmlspecialchars($libro["cantidad"])."</td>";
        echo "<td>".htmlspecialchars($libro["disponibles"])."</td>";
        echo "<td>";
        echo "<a href='edit.php?id=".$libro["id"]."' class='btn btn-warning btn-sm'>
        <i class='fas fa-edit'></i> Editar
        </a> ";
        echo "<a href='delete.php?id=".$libro["id"]."' class='btn btn-danger btn-sm'>
        <i class='fas fa-trash'></i> Eliminar
        </a>";
        echo "</td>";
        echo "</tr>";
    }
}else{
    echo "<tr>";
    echo "<td colspan='9'>No hay libros registrados</td>";
    echo "</tr>";
}
?>
</tbody>
</table>
</div>
<?php include_once "../includes/footer.php"; ?>