<?php
require_once "../config/connection.php";
$id = intval($_GET["id"] ?? 0);
if ($id <= 0) {
    header("Location: index.php?error=" . urlencode("ID inválido"));
    exit;
}
    //OBTENER LIBRO DESDE LA API
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-libros.php?id=" . $id;
$respuesta = file_get_contents($url);
$libro = json_decode($respuesta, true);
if (!$libro || isset($libro["mensaje"])) {
    header("Location: index.php?error=" . urlencode("Libro no encontrado"));
    exit;
}
    //AUTORES DEL LIBRO

$stmtAutoresLibro = $conn->prepare("
    SELECT id_autor
    FROM libro_autor
    WHERE id_libro = ?
");
$stmtAutoresLibro->bind_param("i", $id);
$stmtAutoresLibro->execute();
$resultadoAutoresLibro = $stmtAutoresLibro->get_result();
$autoresSeleccionados = [];
while ($fila = $resultadoAutoresLibro->fetch_assoc()) {
    $autoresSeleccionados[] = $fila["id_autor"];
}
$stmtAutoresLibro->close();

$stmtCategorias = $conn->prepare("
    SELECT id, nombre
    FROM categorias
    ORDER BY nombre
");
$stmtCategorias->execute();
$categorias = $stmtCategorias->get_result();

$stmtAutores = $conn->prepare("
    SELECT id, nombre
    FROM autores
    ORDER BY nombre
");
$stmtAutores->execute();
$autores = $stmtAutores->get_result();
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1>
        <i class="fas fa-book-open"></i>
        Editar Libro
    </h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i>
        Volver
    </a>
</div>
<div class="card">
<form action="update.php" method="POST">
<input
type="hidden"
name="id"
value="<?= $libro["id"] ?>">
    <div class="form-group">
        <label>
            <i class="fas fa-book"></i> Título
        </label>
        <input
            type="text"
            name="titulo"
            value="<?= htmlspecialchars($libro["titulo"]) ?>"
            required>
    </div>
    <div class="form-group">
        <label>
            <i class="fas fa-barcode"></i> ISBN
        </label>
        <input
            type="text"
            name="isbn"
            value="<?= htmlspecialchars($libro["isbn"]) ?>">
    </div>
    <div class="form-group">
        <label>
            <i class="fas fa-calendar"></i> Año de Publicación
        </label>
        <input
            type="number"
            name="anio_publicacion"
            value="<?= htmlspecialchars($libro["anio_publicacion"]) ?>"
            min="1000"
            max="<?= date('Y') ?>">
    </div>
    <div class="form-group">
        <label>
            <i class="fas fa-building"></i> Editorial
        </label>
        <input
            type="text"
            name="editorial"
            value="<?= htmlspecialchars($libro["editorial"]) ?>">
    </div>
    <div class="form-group">
        <label>
            <i class="fas fa-cubes"></i> Cantidad
        </label>
        <input
            type="number"
            name="cantidad"
            value="<?= htmlspecialchars($libro["cantidad"]) ?>"
            min="0">
    </div>
    <div class="form-group">
        <label>
            <i class="fas fa-check-circle"></i> Disponibles
        </label>
        <input
            type="number"
            name="disponibles"
            value="<?= htmlspecialchars($libro["disponibles"]) ?>"
            min="0">
    </div>
    <!-- Categorías -->
    <div class="form-group">
        <label>
            <i class="fas fa-tag"></i> Categoría
        </label>
        <select name="id_categoria" required>
            <option value="">-- Selecciona una categoría --</option>
            <?php while($categoria = $categorias->fetch_assoc()) { ?>
                <option
                    value="<?= $categoria["id"] ?>"
                    <?= ($categoria["id"] == $libro["id_categoria"]) ? "selected" : "" ?>>
                    <?= htmlspecialchars($categoria["nombre"]) ?>
                </option>
            <?php } ?>
        </select>
    </div>
    <!-- Autores -->
    <div class="form-group">
        <label>
            <i class="fas fa-user"></i> Autor(es)
        </label>
        <select
            name="id_autores[]"
            multiple
            required>
            <?php while($autor = $autores->fetch_assoc()) { ?>
                <option
                    value="<?= $autor["id"] ?>"
                    <?= in_array($autor["id"], $autoresSeleccionados) ? "selected" : "" ?>>
                    <?= htmlspecialchars($autor["nombre"]) ?>
                </option>
            <?php } ?>
        </select>
        <small>
            Mantén Ctrl (o Cmd) para seleccionar varios autores
        </small>
    </div>
    <div class="form-actions">
        <button
            type="submit"
            class="btn btn-success">
            <i class="fas fa-save"></i>
            Actualizar
        </button>
        <a
            href="index.php"
            class="btn btn-secondary">
            <i class="fas fa-times"></i>
            Cancelar
        </a>
    </div>
</form>
</div>
<?php
$stmtCategorias->close();
$stmtAutores->close();
$conn->close();
?>
<?php include_once "../includes/footer.php"; ?>