<?php
   /* require_once "../config/connection.php";
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }
    $id               = intval($_POST["id"] ?? 0);
    $nombre           = trim($_POST["nombre"] ?? "");
    $apellido         = trim($_POST["apellido"] ?? "");
    $nacionalidad     = trim($_POST["nacionalidad"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "") ?: null;
    if ($id <= 0 || $nombre === "" || $apellido === "") {
        header("Location: index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }
    // Aquí va el código para actualizar el autor usando una consulta preparada
    $stmt = $conn->prepare("UPDATE autores SET nombre = ?, apellido = ?, nacionalidad = ?, fecha_nacimiento = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id);
    if ($stmt->execute()) {
        header("Location: index.php?success=" . urlencode("Autor actualizado exitosamente"));
        exit;
    } else {
        header("Location: index.php?error=" . urlencode("Error al actualizar el autor: " . $stmt->error));
        exit;
    }
    $stmt->close();
    $conn->close();
    */
?>
<?php
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}
$id = intval($_POST["id"] ?? 0);
$nombre = trim($_POST["nombre"] ?? "");
$apellido = trim($_POST["apellido"] ?? "");
$nacionalidad = trim($_POST["nacionalidad"] ?? "");
$fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "");
if (
    $id <= 0 ||
    $nombre === "" ||
    $apellido === "" ||
    $nacionalidad === "" ||
    $fecha_nacimiento === ""
) {
    header("Location: edit.php?id=".$id."&error=".urlencode("Todos los campos son obligatorios."));
    exit;
}
$datos = array(
    "nombre" => $nombre,
    "apellido" => $apellido,
    "nacionalidad" => $nacionalidad,
    "fecha_nacimiento" => $fecha_nacimiento
);
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-autores.php?id=".$id;
$opciones = array(
    "http" => array(
        "method" => "PUT",
        "header" => "Content-Type: application/json\r\n",
        "content" => json_encode($datos),
        "ignore_errors" => true
    )
);
$contexto = stream_context_create($opciones);
$respuesta = file_get_contents($url, false, $contexto);
if ($respuesta === FALSE) {
    header("Location: edit.php?id=".$id."&error=".urlencode("No fue posible conectar con la API."));
    exit;
}
$resultado = json_decode($respuesta, true);
if (isset($resultado["mensaje"])) {
    if ($resultado["mensaje"] === "Autor actualizado exitosamente") {
        header("Location: index.php?success=".urlencode($resultado["mensaje"]));
        exit;
    } else {
        header("Location: edit.php?id=".$id."&error=".urlencode($resultado["mensaje"]));
        exit;
    }
} else {
    header("Location: edit.php?id=".$id."&error=".urlencode("Respuesta inesperada de la API."));
    exit;
}
?>