<?php
  /*  require_once "../config/connection.php";
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }
    $nombre           = trim($_POST["nombre"] ?? "");
    $apellido         = trim($_POST["apellido"] ?? "");
    $nacionalidad     = trim($_POST["nacionalidad"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "") ?: null;
    if ($nombre === "" || $apellido === "") {
        header("Location: create.php?error=" . urlencode("El nombre y apellido son obligatorios"));
    }
    // Aquí va el código para crear el autor usando una consulta preparada
    $stmt = $conn->prepare("INSERT INTO autores (nombre, apellido, nacionalidad, fecha_nacimiento) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nombre, $apellido, $nacionalidad, $fecha_nacimiento);
    if ($stmt->execute()) {
        header("Location: index.php?success=" . urlencode("Autor creado exitosamente"));
    } else {
        header("Location: create.php?error=" . urlencode("Error al crear el autor: " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
    */
?>
<?php
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}
$nombre = trim($_POST["nombre"] ?? "");
$apellido = trim($_POST["apellido"] ?? "");
$nacionalidad = trim($_POST["nacionalidad"] ?? "");
$fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "");
if (
    $nombre === "" ||
    $apellido === "" ||
    $nacionalidad === "" ||
    $fecha_nacimiento === ""
) {
    header("Location: create.php?error=" . urlencode("Todos los campos son obligatorios."));
    exit;
}
$datos = array(
    "nombre" => $nombre,
    "apellido" => $apellido,
    "nacionalidad" => $nacionalidad,
    "fecha_nacimiento" => $fecha_nacimiento
);
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-autores.php";
$opciones = array(
    "http" => array(
        "method" => "POST",
        "header" =>
            "Content-Type: application/json\r\n",
        "content" => json_encode($datos),
        "ignore_errors" => true
    )
);
$contexto = stream_context_create($opciones);
$respuesta = file_get_contents($url, false, $contexto);
if ($respuesta === FALSE) {
    header("Location: create.php?error=" . urlencode("No fue posible conectar con la API."));
    exit;
}
$resultado = json_decode($respuesta, true);
if (isset($resultado["mensaje"])) {
    if ($resultado["mensaje"] == "Autor creado exitosamente") {
        header("Location: index.php?success=" . urlencode($resultado["mensaje"]));
        exit;
    } else {
        header("Location: create.php?error=" . urlencode($resultado["mensaje"]));
        exit;
    }
} else {
    header("Location: create.php?error=" . urlencode("Respuesta inesperada de la API."));
    exit;
}
?>