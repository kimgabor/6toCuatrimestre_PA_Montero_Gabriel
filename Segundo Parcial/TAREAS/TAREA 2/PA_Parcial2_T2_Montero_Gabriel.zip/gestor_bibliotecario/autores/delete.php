<?php /*
    require_once "../config/connection.php";
    $id = intval($_GET["id"] ?? 0);
    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
    // Aquí va el código para eliminar el autor usando una consulta preparada
    $stmt = $conn->prepare("DELETE FROM autores WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header("Location: index.php?success=" . urlencode("Autor eliminado con éxito."));
        exit;
    } else {
        header("Location: index.php?error=" . urlencode("Error al eliminar el autor: " . $stmt->error));
        exit;
    }
        */
?>
<?php
$id = intval($_GET["id"] ?? 0);
if ($id <= 0) {
    header("Location: index.php?error=" . urlencode("ID inválido"));
    exit;
}
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-autores.php?id=" . $id;
$opciones = array(
    "http" => array(
        "method" => "DELETE",
        "header" => "Content-Type: application/json\r\n"
    )
);
$contexto = stream_context_create($opciones);
$respuesta = file_get_contents($url, false, $contexto);
if ($respuesta === FALSE) {
    header("Location: index.php?error=" . urlencode("No fue posible eliminar el autor"));
    exit;
}
$resultado = json_decode($respuesta, true);
if (isset($resultado["mensaje"])) {
    header("Location: index.php?success=" . urlencode($resultado["mensaje"]));
} else {
    header("Location: index.php?error=" . urlencode("Error al eliminar el autor"));
}
exit;
?>