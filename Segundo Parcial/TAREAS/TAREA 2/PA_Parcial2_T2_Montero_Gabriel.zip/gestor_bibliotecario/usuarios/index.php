<?php
    require_once "../config/connection.php"; // Incluimos la conexión a la base de datos
?>
<?php include_once "../includes/header.php"; // Incluimos el encabezado. Básicamente lo que hace esto es que el archivo header.php se incrusta en mi archivo actual, el archivo header.php ya contiene el código HTML del encabezado, lo que me permitirá reutilizarlo cuantas veces sea necesario?> 
<!--
<div class="page-header">
    <h1><i class="fas fa-tags"></i> Usuarios</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Usuario
    </a>
</div>
<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Correo</th>
                <th>Password</th>
                <th>Telefono</th>
                <th>id_rol</th>
                <th>Fecha y Hora de Registro</th>
            </tr>
        </thead>
        <tbody>
            <?php
                // Aquí va el código para el select que mostrará las categorías
                $stmt = $conn->prepare("SELECT usuarios.id, usuarios.nombre, usuarios.apellido,
                usuarios.correo,
                usuarios.`password`, 
                usuarios.telefono,
       roles.nombre AS ROL, 
                usuarios.activo,
                usuarios.fecha_registro 
       FROM usuarios
       INNER JOIN roles
       ON usuarios.id_rol = roles.id"); // En esta línea preparamos una consulta SQL, para mostrar las categorías. Esto lo hacemos mediante una consulta "SELECT", la cual seleccionará los campos "id", "nombre" y "descripcion" de la tabla "categorías".
                $stmt->execute(); // En esta linea, la función execute() ejecutamos la consulta que previamente preparamos.
                $resultado = $stmt->get_result(); // En la variable resultado, almacenamos el resultado de la consulta que ejecutamos. Hacemos utilizando la función o método get_result() el cual nos devuelve un objeto que representa el conjunto de resultados obtenido de la consulta.
                while($row = $resultado->fetch_assoc()){ // En esta línea de código, iniciamos un ciclo while para recorrer cada fila del resultado obtenido. Utilizamos una variable llamada $row para almacenar cada fila, y por medio de la función fetch_assoc() obtenemos cada fila como si fuera un array asociativo, lo cual permitirá que accedamos a los valores mediante clave-valor.
                    echo "<tr>"; // La etiqueta <tr> se utiliza para definir una fila en una tabla HTML.
                    echo "<td>" . htmlspecialchars($row["id"]) . "</td>"; // Utilizamos la etiqueta <td> para definir una celda dentro de la fila. En ella mostraremos el ID de la categooría y usaremos htmlspecialchars() para sanitizar el valor y evitar posibles inyecciones SQL.
                    echo "<td>" . htmlspecialchars($row["nombre"]) . "</td>";  // Insertamos el valor del nombre de la categoría.
                    echo "<td>" . htmlspecialchars($row["apellido"]) . "</td>";  // Insertamos el valor del nombre de la descripcion.
                    echo "<td>" . htmlspecialchars($row["correo"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["password"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["telefono"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["ROL"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["fecha_registro"]) . "</td>";
                    echo "<td>"; // Abrimos una nueva celda para colocar los botones de acción (editar y eliminar).
                    echo "<a href='edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Editar</a>";
                    echo "<a href='delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger'><i class='fas fa-trash'></i> Eliminar</a>";
                    echo "</td>";
                    echo "</tr>"; // Cerramos la etiqueta <tr> para finalizar la fila.
                }
                $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
                $conn->close(); // Cerramos la conexión a la base de datos para liberar recursos.
            ?>
        </tbody>
    </table>
</div>
-->
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1><i class="fas fa-users"></i> Usuarios</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i>
        Nuevo Usuario
    </a>
</div>
<?php if (isset($_GET["success"])): ?>
<div class="alert alert-success">
    <i class="fas fa-check-circle"></i>
    <?= htmlspecialchars($_GET["success"]) ?>
</div>
<?php elseif (isset($_GET["error"])): ?>
<div class="alert alert-danger">
    <i class="fas fa-exclamation-circle"></i>
    <?= htmlspecialchars($_GET["error"]) ?>
</div>
<?php endif; ?>
<div class="table-container">
<table>
<thead>
<tr>
    <th>#</th>
    <th>Nombre</th>
    <th>Apellido</th>
    <th>Correo</th>
    <th>Password</th>
    <th>Teléfono</th>
    <th>Rol</th>
    <th>Activo</th>
    <th>Fecha Registro</th>
    <th>Acciones</th>
</tr>
</thead>
<tbody>
<?php
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-usuarios.php";
$respuesta = file_get_contents($url);
$usuarios = json_decode($respuesta, true);
if (is_array($usuarios)) {
    foreach ($usuarios as $usuario) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($usuario["id"]) . "</td>";
        echo "<td>" . htmlspecialchars($usuario["nombre"]) . "</td>";
        echo "<td>" . htmlspecialchars($usuario["apellido"]) . "</td>";
        echo "<td>" . htmlspecialchars($usuario["correo"]) . "</td>";
        echo "<td>" . htmlspecialchars($usuario["password"]) . "</td>";
        echo "<td>" . htmlspecialchars($usuario["telefono"]) . "</td>";
        echo "<td>" . htmlspecialchars($usuario["id_rol"]) . "</td>";
        echo "<td>" . htmlspecialchars($usuario["activo"]) . "</td>";
        echo "<td>" . htmlspecialchars($usuario["fecha_registro"]) . "</td>";
        echo "<td>";
        echo "<a href='edit.php?id=".$usuario["id"]."' class='btn btn-sm btn-warning'>
                <i class='fas fa-edit'></i> Editar
              </a> ";
        echo "<a href='delete.php?id=".$usuario["id"]."' class='btn btn-sm btn-danger'>
                <i class='fas fa-trash'></i> Eliminar
              </a>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr>";
    echo "<td colspan='10'>No hay usuarios registrados.</td>";
    echo "</tr>";
}
?>
</tbody>
</table>
</div>
<?php include_once "../includes/footer.php"; ?>