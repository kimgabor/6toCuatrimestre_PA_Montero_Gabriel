<?php
    require_once "../config/connection.php";
/*
    $stmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY nombre"); 
    $stmt->execute(); // Ejecutamos la consulta
    $resultado_roles = $stmt->get_result(); // Obtengo el resultado de la consulta y lo guardo en una variable
    $roles = []; // Creo un array vacío para guardar los roles obtenidos
    while($row = $resultado_roles->fetch_assoc()){ // Recorro el resultado de la consulta usando un while
        $roles[] = $row; // Guardamos cada fila (rol) dentro de nuestro arreglo
    }
    $stmt->close(); // Cerramos la consulta preparada para liberar recursos
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Usuario</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>  
<div class="card">
    <form action="save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Nombre</label>
            <input type="text" name="nombre" placeholder="Ej: Programación" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Apellido</label>
            <input type="text" name="apellido" placeholder="Ej: García" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo</label>
            <input type="email" name="correo" placeholder="Ej: juan@example.com" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-lock"></i> Password</label>
            <input type="password" name="password" placeholder="Ej: 123456" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-phone"></i> Teléfono</label>
            <input type="text" name="telefono" placeholder="Ej: 1234567890" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-user-tag"></i> Rol</label>
            <select name="id_rol" required>
                <option value="">Seleccionar Rol</option>
                <?php
                    foreach($roles as $rol){
                        echo "<option value='" . $rol["id"] . "'>" . htmlspecialchars($rol["nombre"]) . "</option>";
                    }
                ?>
            </select>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>*/
?>
<?php
require_once "../config/connection.php";
/* Obtener los roles */
$stmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY nombre");
$stmt->execute();
$resultado_roles = $stmt->get_result();
$roles = array();
while($row = $resultado_roles->fetch_assoc()){
    $roles[] = $row;
}
$stmt->close();
$conn->close();
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1>
        <i class="fas fa-plus-circle"></i>
        Nuevo Usuario
    </h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i>
        Volver
    </a>
</div>
<?php if(isset($_GET["error"])): ?>
<div class="alert alert-danger">
    <i class="fas fa-exclamation-circle"></i>
    <?= htmlspecialchars($_GET["error"]) ?>
</div>
<?php endif; ?>
<div class="card">
<form action="save.php" method="POST">
    <div class="form-group">
        <label><i class="fas fa-user"></i> Nombre</label>
        <input
            type="text"
            name="nombre"
            placeholder="Nombre"
            required>
    </div>
    <div class="form-group">
        <label><i class="fas fa-user"></i> Apellido</label>
        <input
            type="text"
            name="apellido"
            placeholder="Apellido"
            required>
    </div>
    <div class="form-group">
        <label><i class="fas fa-envelope"></i> Correo</label>
        <input
            type="email"
            name="correo"
            placeholder="correo@ejemplo.com"
            required>
    </div>
    <div class="form-group">
        <label><i class="fas fa-lock"></i> Password</label>
        <input
            type="password"
            name="password"
            required>
    </div>
    <div class="form-group">
        <label><i class="fas fa-phone"></i> Teléfono</label>
        <input
            type="text"
            name="telefono">
    </div>
    <div class="form-group">
        <label><i class="fas fa-user-tag"></i> Rol</label>
        <select name="id_rol" required>
            <option value="">Seleccionar Rol</option>
            <?php
            foreach($roles as $rol){
                echo "<option value='".$rol["id"]."'>";
                echo htmlspecialchars($rol["nombre"]);
                echo "</option>";
            }
            ?>
        </select>
    </div>
    <div class="form-actions">
        <button
            type="submit"
            class="btn btn-success">
            <i class="fas fa-save"></i>
            Guardar
        </button>
        <a
            href="index.php"
            class="btn btn-secondary">
            <i class="fas fa-times"></i>
            Cancelar
        </a>
    </div>
</form>
</div>
<?php include_once "../includes/footer.php"; ?>