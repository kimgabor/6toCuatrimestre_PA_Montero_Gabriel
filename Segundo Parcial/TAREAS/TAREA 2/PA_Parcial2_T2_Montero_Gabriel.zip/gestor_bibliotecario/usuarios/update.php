<?php
    require_once "../config/connection.php";
    /*if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }
    $id = intval($_POST["id"] ?? 0); 
    $nombre = trim($_POST["nombre"] ?? "");
    $apellido = trim($_POST["apellido"] ?? "");
    $correo = trim($_POST["correo"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $telefono = trim($_POST["telefono"] ?? "");
    $id_rol = intval($_POST["id_rol"] ?? 0);
    if ($id <= 0 || $nombre === "") {
        header("Location: index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }
    // Aquí va el código para actualizar la categoría usando una consulta preparada
    $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ?, telefono = ?, id_rol = ? WHERE id = ?"); // Aquí hacemos una consulta preparada utilizando UPDATE para actualizar los datos de la categoría. Los signos "?" son marcadores de posición para los valores que se pasarán posteriormente.
    $stmt->bind_param("sssssii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $id); // Aquí le pasamos los valores de los marcadores de posición a nuestra consulta previamente preparada. "ssi".
    if($stmt->execute()){
        header("Location:index.php?success=" . urlencode("Usuario actualizado exitosamente"));
        exit;
    }else{
        header("Location: index.php?error=" .urlencode("Error al actualizar el usuario: " . $stmt->error));
        exit;
    }
    $stmt->close(); // Cerramos la consulta preparada
    $conn->close(); // Cerramos la conexión a la base de datos
    */
?>
<?php
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: index.php");
    exit;
}
$id = intval($_POST["id"] ?? 0);
$nombre = trim($_POST["nombre"] ?? "");
$apellido = trim($_POST["apellido"] ?? "");
$correo = trim($_POST["correo"] ?? "");
$password = trim($_POST["password"] ?? "");
$telefono = trim($_POST["telefono"] ?? "");
$id_rol = intval($_POST["id_rol"] ?? 0);
$activo = 1;
if (
    $id <= 0 ||
    $nombre == "" ||
    $apellido == "" ||
    $correo == "" ||
    $password == "" ||
    $id_rol <= 0
) {
    header("Location: edit.php?id=".$id."&error=".urlencode("Datos inválidos"));
    exit;
}
$datos = array(
    "nombre" => $nombre,
    "apellido" => $apellido,
    "correo" => $correo,
    "password" => $password,
    "telefono" => $telefono,
    "id_rol" => $id_rol,
    "activo" => $activo
);
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-usuarios.php?id=".$id;
$opciones = array(
    "http" => array(
        "method" => "PUT",
        "header" => "Content-Type: application/json\r\n",
        "content" => json_encode($datos),
        "ignore_errors" => true
    )
);
$contexto = stream_context_create($opciones);
$respuesta = file_get_contents($url, false, $contexto);
if ($respuesta === FALSE) {
    header("Location: edit.php?id=".$id."&error=".urlencode("No fue posible actualizar."));
    exit;
}
$resultado = json_decode($respuesta, true);
if (isset($resultado["mensaje"])) {
    if ($resultado["mensaje"] == "Usuario actualizado exitosamente") {
        header("Location: index.php?success=".urlencode($resultado["mensaje"]));
    } else {
        header("Location: edit.php?id=".$id."&error=".urlencode($resultado["mensaje"]));
    }
} else {
    header("Location: edit.php?id=".$id."&error=".urlencode("Respuesta inesperada de la API."));
}
exit;
?>