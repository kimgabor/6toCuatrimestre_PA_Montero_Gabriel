<?php
    require_once "../config/connection.php";
    /*$stmt = $conn->prepare("SELECT id, nombre FROM roles"); 
    $stmt->execute(); // Ejecutamos la consulta
    $resultado_roles = $stmt->get_result(); // Obtengo el resultado de la consulta y lo guardo en una variable
    $roles = []; // Creo un array vacío para guardar los roles obtenidos
    while($row = $resultado_roles->fetch_assoc()){ // Recorro el resultado de la consulta usando un while
        $roles[] = $row; // Guardamos cada fila (rol) dentro de nuestro arreglo
    }
    $stmt->close(); // Cerramos la consulta preparada para liberar recursos
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Rol en el sistema</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>  
<div class="card">
    <form action="save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Nombre de Rol</label>
            <input type="text" name="nombre" placeholder="Ej: Bibliotecario" required>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>
*/
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1>
        <i class="fas fa-plus-circle"></i>
        Nuevo Rol en el sistema
    </h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i>
        Volver
    </a>
</div>
<?php if(isset($_GET["error"])): ?>
<div class="alert alert-danger">
    <i class="fas fa-exclamation-circle"></i>
    <?= htmlspecialchars($_GET["error"]) ?>
</div>
<?php endif; ?>
<div class="card">
<form action="save.php" method="POST">
    <div class="form-group">
        <label>
            <i class="fas fa-tag"></i>
            Nombre del Rol
        </label>
        <input
            type="text"
            name="nombre"
            placeholder="Ej: Bibliotecario"
            required>
    </div>
    <div class="form-actions">
        <button
            type="submit"
            class="btn btn-success">
            <i class="fas fa-save"></i>
            Guardar
        </button>
        <a
            href="index.php"
            class="btn btn-secondary">
            <i class="fas fa-times"></i>
            Cancelar
        </a>
    </div>
</form>
</div>
<?php include_once "../includes/footer.php"; ?>