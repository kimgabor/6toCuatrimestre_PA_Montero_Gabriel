<?php
   /* require_once "../config/connection.php";
    $id = intval($_GET["id"] ?? 0); // Recibimos el ID de la categoría desde la URL, mediante el método GET. Si no se proporciona un ID válido, se asigna el valor de 0. Y con intval() nos aseguramos que el valor sea un número entero.
    // Aquí va el código para obtener la categoría usando una consulta preparada
    if($id > 0){
    $stmt = $conn->prepare("SELECT id, nombre FROM roles WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $rol = $resultado->fetch_assoc();
    $stmt->close();
    $conn->close();
}else{
    header("Location: index.php?error=" . urlencode("ID inválido"));
    exit;
}
    */
?>
<?php include_once "../includes/header.php"; ?>
<!--
<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Rol</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>
<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $rol["id"] ?? $id ?>">
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Nombre</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($rol["nombre"] ?? "") ?>" required>
        </div>
</div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>
-->
<?php
$id = intval($_GET["id"] ?? 0);
if ($id <= 0) {
    header("Location: index.php?error=" . urlencode("ID inválido"));
    exit;
}
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-roles.php?id=".$id;
$respuesta = file_get_contents($url);
$rol = json_decode($respuesta, true);
if (!$rol || isset($rol["mensaje"])) {
    header("Location: index.php?error=" . urlencode("Rol no encontrado"));
    exit;
}
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1>
        <i class="fas fa-edit"></i>
        Editar Rol
    </h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i>
        Volver
    </a>
</div>
<div class="card">
<form action="update.php" method="POST">
    <input
        type="hidden"
        name="id"
        value="<?= $rol["id"] ?>">
    <div class="form-group">
        <label>
            <i class="fas fa-tag"></i>
            Nombre
        </label>
        <input
            type="text"
            name="nombre"
            value="<?= htmlspecialchars($rol["nombre"]) ?>"
            required>
    </div>
    <div class="form-actions">
        <button
            type="submit"
            class="btn btn-success">
            <i class="fas fa-save"></i>
            Actualizar
        </button>
        <a
            href="index.php"
            class="btn btn-secondary">
            <i class="fas fa-times"></i>
            Cancelar
        </a>
    </div>
</form>
</div>
<?php include_once "../includes/footer.php"; ?>