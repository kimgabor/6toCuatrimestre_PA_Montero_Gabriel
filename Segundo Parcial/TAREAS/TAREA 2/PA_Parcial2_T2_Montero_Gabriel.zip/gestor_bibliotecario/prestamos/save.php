<?php
   /* require_once "../config/connection.php"; // Importo la conexión a la base de datos
    if ($_SERVER["REQUEST_METHOD"] !== "POST") { // Este if contiene una validación. Esta validación se asegura que nuestro script solo se ejecute si el método por el cual fue enviado el formulario es POST.
        header("Location: index.php");
        exit;
    }
    // Recibiendo las variables del formulario y sanitizándolas
    $id_usuario = trim($_POST["id_usuario"] ?? ""); // Recibimos el nombre de la categoría y lo sanitizamos usando la función trim() esta función elimina todos los espacios en blanco AL INICIO y AL FINAL de la cadena. ?? "" es un operador conocido como OPERADOR DE FUNCIÓN NULL, este operador te devolverá el valor de $_POST["nombre"] si existe, pero si no existe o es null, te devolverá un cadena vacía "", esto para evitar generar errores.
    $id_libro = trim($_POST["id_libro"] ?? ""); // Recibimos la descripción de la categoría y la sanitizamos de la misma manera que el nombre.
    $fecha_prestamo = date("Y-m-d H:i:s");  // Recibimos el correo del usuario y lo sanitizamos de la misma manera que el nombre.
    $fecha_devolucion = date("Y-m-d H:i:s");  // Recibimos el password del usuario y lo sanitizamos de la misma manera que el nombre.
    $estado = trim($_POST["estado"] ?? "");// Recibimos el telefono del usuario y lo sanitizamos de la misma manera que el nombre.
   //uso la validacion para los datos ingresados como el id de usuario, libro y estado
   //no cree una tabla para estado :c
   //en el caso de las fechas no se si le pueda poner una validacion
   if ($id_usuario === "" || $id_libro === "" || $fecha_prestamo === "" || $fecha_devolucion === "" || $estado === "") { 
    header("Location: create.php?error=" . urlencode("Por favor, llena todos los campos obligatorios. El estado llegó como: '" . $estado . "'"));
    exit;
}
    $conn->begin_transaction();   // Iniciamos una transacción para asegurarnos de que ambas inserciones (prestamo y detalle_prestamo) se realicen correctamente.
    try {
      // Aquí va el código para crear el prestamo usando udos consultas preparadas
    // ¿Qué es un prepared statement? Es una forma segura de ejecutar consultas SQL, haciendo uso de una plantilla de consulta con marcadores de posición, y luego vinculando los valores a esos marcadores. Esto ayuda a prevenir ataques de inyección SQL.
$stmt1 = $conn->prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion, estado) VALUES (?, ?, ?, ?)"); // En esta línea preparamos una consulta SQL para insertar un nuevo registro en la tabla "prestamos". La consulta tiene marcadores de posición (?).
$stmt1->bind_param("isss", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado);  // Aquí le pasamos los valores de los marcadores de posición a nuestra consulta previamente preparada. "ss" indica el tipo de valor de los parámetros que voy a pasar a la consulta, para este ejemplo significa "string". $nombre y $descripcion son dos variables que contienen los valores que voy a insertar en mi base de datos. 
$stmt1->execute(); // Ejecutamos la consulta preparada, lo que hará que se inserte el nuevo registro en la base de datos.
    $id_prestamo = $conn->insert_id;
    $stmt2 = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro) VALUES (?, ?)"); //en esta linea se hará la insercion de los dstos en la tabla detalle_prestamo para el id delc prestamo y el id del libro
    $stmt2->bind_param("ii", $id_prestamo, $id_libro); //pasamos valores de tipo int
    $stmt2->execute(); //ejecutamos la consulta preparada
        $conn->commit();  // en esta linea confirma la transaccion guardando cambios
        $stmt1->close(); // Cerramos la consulta preparada para liberar recursos
        $stmt2->close();
        $conn->close();   // Cerramos la conexión a la base de datos para liberar recursos
        header("Location: index.php?success=" . urlencode("Préstamo creado exitosamente"));
        exit;
    } catch (Exception $e) {
        // Si algo falla, cancelamos cualquier inserción para no dejar datos corruptos
        $conn->rollback();
        header("Location: create.php?error=" . urlencode("Error al crear el préstamo: " . $e->getMessage()));
        exit;
    }
        */
?>
<?php
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: index.php");
    exit;
}
$id_usuario = intval($_POST["id_usuario"] ?? 0);
$id_libro = intval($_POST["id_libro"] ?? 0);
$fecha_prestamo = $_POST["fecha_prestamo"] ?? "";
$fecha_devolucion = $_POST["fecha_devolucion"] ?? "";
$estado = trim($_POST["estado"] ?? "");
if (
    $id_usuario <= 0 ||
    $id_libro <= 0 ||
    $fecha_prestamo == "" ||
    $fecha_devolucion == "" ||
    $estado == ""
) {
    header("Location: create.php?error=" . urlencode("Datos inválidos"));
    exit;
}
$datos = array(
    "id_usuario" => $id_usuario,
    "id_libro" => $id_libro,
    "fecha_prestamo" => $fecha_prestamo,
    "fecha_devolucion" => $fecha_devolucion,
    "estado" => $estado
);
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-prestamos.php";
$opciones = array(
    "http" => array(
        "method" => "POST",
        "header" => "Content-Type: application/json\r\n",
        "content" => json_encode($datos)
    )
);
$contexto = stream_context_create($opciones);
$respuesta = file_get_contents($url, false, $contexto);
if ($respuesta === FALSE) {
    header("Location: create.php?error=" . urlencode("No fue posible crear el préstamo"));
    exit;
}
$resultado = json_decode($respuesta, true);
if (isset($resultado["mensaje"])) {
    header("Location: index.php?success=" . urlencode($resultado["mensaje"]));
} else {
    header("Location: create.php?error=" . urlencode("Error al crear el préstamo"));
}
exit;
?>