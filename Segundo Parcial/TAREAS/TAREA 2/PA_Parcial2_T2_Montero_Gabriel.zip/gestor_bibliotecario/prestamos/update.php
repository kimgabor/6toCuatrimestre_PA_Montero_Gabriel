<?php
   /* require_once "../config/connection.php";
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }
    $id = intval($_POST["id"] ?? 0); // Recibimos el ID de la categoría desde la URL, mediante el método GET. Si no se proporciona un ID válido, se asigna el valor de 0. Y con intval() nos aseguramos que el valor sea un número entero.
    $id_usuario = trim($_POST["usuario"] ?? "");       
    $id_libro = trim($_POST["libro"] ?? "");           
    $fecha_prestamo = trim($_POST["fecha_prestamo"] ?? "");   
    $fecha_devolucion = trim($_POST["fecha_devolucion"] ?? ""); 
    $estado = trim($_POST["estado"] ?? "");
   if ($id <= 0 || $id_usuario === "" || $id_libro === "" || $fecha_prestamo === "" || $fecha_devolucion === "" || $estado === "") {
        header("Location: index.php?error=" . urlencode("Por favor, llena todos los campos obligatorios"));
        exit;
    }
    $conn->begin_transaction();   // Iniciamos una transacción para asegurarnos de que ambas inserciones (prestamo y detalle_prestamo) se realicen correctamente.
    try {
      // Aquí va el código para crear el prestamo usando udos consultas preparadas
    // ¿Qué es un prepared statement? Es una forma segura de ejecutar consultas SQL, haciendo uso de una plantilla de consulta con marcadores de posición, y luego vinculando los valores a esos marcadores. Esto ayuda a prevenir ataques de inyección SQL.
$stmt1 = $conn->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ?, estado = ? WHERE id = ?"); // En esta línea preparamos una consulta SQL para insertar un nuevo registro en la tabla "prestamos". La consulta tiene marcadores de posición (?).
$stmt1->bind_param("isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id);  // Aquí le pasamos los valores de los marcadores de posición a nuestra consulta previamente preparada. "ss" indica el tipo de valor de los parámetros que voy a pasar a la consulta, para este ejemplo significa "string". $nombre y $descripcion son dos variables que contienen los valores que voy a insertar en mi base de datos. 
$stmt1->execute(); // Ejecutamos la consulta preparada, lo que hará que se inserte el nuevo registro en la base de datos.
    $stmt2 = $conn->prepare("UPDATE detalle_prestamo SET id_libro = ? WHERE id_prestamo = ?"); //en esta linea se hará la insercion de los dstos en la tabla detalle_prestamo para el id delc prestamo y el id del libro
    $stmt2->bind_param("ii", $id_libro, $id); //pasamos valores de tipo int
    $stmt2->execute(); //ejecutamos la consulta preparada
        $conn->commit();  // en esta linea confirma la transaccion guardando cambios
        $stmt1->close(); // Cerramos la consulta preparada para liberar recursos
        $stmt2->close();
        $conn->close();   // Cerramos la conexión a la base de datos para liberar recursos
        header("Location: index.php?success=" . urlencode("Préstamo actualizado exitosamente"));
        exit;
    } catch (Exception $e) {
        // Si algo falla, cancelamos cualquier inserción para no dejar datos corruptos
        $conn->rollback();
        header("Location: edit.php?id=" . $id . "&error=" . urlencode("Error al actualizar el préstamo: " . $e->getMessage()));
        exit;
    }
    */
?>
<?php
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: index.php");
    exit;
}
$id = intval($_POST["id"] ?? 0);
$id_usuario = intval($_POST["id_usuario"] ?? 0);
$id_libro = intval($_POST["id_libro"] ?? 0);
$fecha_prestamo = $_POST["fecha_prestamo"] ?? "";
$fecha_devolucion = $_POST["fecha_devolucion"] ?? "";
$estado = trim($_POST["estado"] ?? "");
if (
    $id <= 0 ||
    $id_usuario <= 0 ||
    $id_libro <= 0 ||
    $fecha_prestamo == "" ||
    $fecha_devolucion == "" ||
    $estado == ""
) {
    header("Location: edit.php?id=".$id."&error=" . urlencode("Datos inválidos"));
    exit;
}
$datos = array(
    "id_usuario" => $id_usuario,
    "id_libro" => $id_libro,
    "fecha_prestamo" => $fecha_prestamo,
    "fecha_devolucion" => $fecha_devolucion,
    "estado" => $estado
);
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-prestamos.php?id=".$id;
$opciones = array(
    "http" => array(
        "method" => "PUT",
        "header" => "Content-Type: application/json\r\n",
        "content" => json_encode($datos)
    )
);
$contexto = stream_context_create($opciones);
$respuesta = file_get_contents($url, false, $contexto);
if ($respuesta === FALSE) {
    header("Location: edit.php?id=".$id."&error=" . urlencode("No fue posible actualizar el préstamo"));
    exit;
}
$resultado = json_decode($respuesta, true);
if (isset($resultado["mensaje"])) {
    header("Location: index.php?success=" . urlencode($resultado["mensaje"]));
} else {
    header("Location: edit.php?id=".$id."&error=" . urlencode("Error al actualizar el préstamo"));
}
exit;
?>