<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1><i class="fas fa-tags"></i> Préstamos</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Préstamo
    </a>
</div>
<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Usuario</th>
                <th>Libro</th>
                <th>Fecha de Préstamo</th>
                <th>Fecha de Devolución</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
<?php
$url = "http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/api-prestamos.php";
$respuesta = file_get_contents($url);
$prestamos = json_decode($respuesta, true);
if (is_array($prestamos)) {
    foreach ($prestamos as $prestamo) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($prestamo["id"]) . "</td>";
        echo "<td>" . htmlspecialchars($prestamo["Usuario"]) . "</td>";
        echo "<td>" . htmlspecialchars($prestamo["Libro"]) . "</td>";
        echo "<td>" . htmlspecialchars($prestamo["fecha_prestamo"]) . "</td>";
        echo "<td>" . htmlspecialchars($prestamo["fecha_devolucion"]) . "</td>";
        echo "<td>" . htmlspecialchars($prestamo["estado"]) . "</td>";
        echo "<td>";
        echo "<a href='edit.php?id=" . urlencode($prestamo["id"]) . "' class='btn btn-sm btn-warning'>
                <i class='fas fa-edit'></i> Editar
              </a> ";
        echo "<a href='delete.php?id=" . urlencode($prestamo["id"]) . "' class='btn btn-sm btn-danger'>
                <i class='fas fa-trash'></i> Eliminar
              </a>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr>";
    echo "<td colspan='7'>No hay préstamos registrados.</td>";
    echo "</tr>";
}
?>
        </tbody>
    </table>
</div>
<?php include_once "../includes/footer.php"; ?>