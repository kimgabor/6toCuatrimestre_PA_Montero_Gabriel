const URL_BASE = 'http://localhost/gestor_bibliotecario/gestor_bibliotecario/apis/';
// Funciones para realizar peticiones
// GET ../api/api-categorias.php — listar todas
async function getCategorias() {
    const tbody = document.querySelector('#tabla-categorias tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php`);
        const data = await response.json();
        tbody.innerHTML = '';
        data.forEach(categoria => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${categoria.id}</td>
                <td>${categoria.nombre}</td>
                <td>${categoria.descripcion}</td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="obtenerId(${categoria.id})">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="eliminarCategoria(${categoria.id})">Eliminar</button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener las categorías: ', error);
    }
}
// GET ../api/api-categorias.php?nombre=texto — buscar por nombre
// GET ../api/api-categorias.php?id=1 — obtener una por ID
async function getCategoriaPorId(id){
    try{
        const response = await fetch(`${URL_BASE}api-categorias.php?id=${id}`);
        if(response.ok){
            const categoria = await response.json();
            return categoria;
        }else{
            console.log('Error al obtener la categoría: ', response.statusText);
        }
    } catch (error) {
        console.error('Error al obtener la categoría: ', error);
    }
}
// POST ../api/api-categorias.php — crear (body: {nombre, descripcion})
async function crearCategoria(nombre, descripcion) {
    try {
        const nuevaCategoria = {
            nombre: nombre,
            descripcion: descripcion
        };
        const response = await fetch(`${URL_BASE}api-categorias.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevaCategoria)
        })
        if (response.ok) {
            window.location.replace('index.php'); // Redirige a la página de listado de categorías después de crear una nueva
            return;
        } else {
            const errorData = await response.json().catch(() => null); // Intenta obtener el mensaje de error del cuerpo de la respuesta, si es que existe
            const mensaje = errorData?.mensaje || response.statusText || 'Error al crear la categoría';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al crear la categoría: ', error);
    }
}
// PUT ../api/api-categorias.php?id=1 — actualizar completa (body: {nombre, descripcion})
async function actualizarCategoria(id, nombre, descripcion) {
    const categoriaActualizada = {
        nombre: nombre,
        descripcion: descripcion
    }
    try{
        const response = await fetch(`${URL_BASE}api-categorias.php?id=${id}`,{
            method: 'PUT',
            headers:{
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(categoriaActualizada)
        })
        if(response.ok){
            window.location.replace('index.php'); // Redirige a la página de listado de categorías después de actualizar
            return;
        }else{
            const errorData = await response.json().catch(() => null); // Intenta obtener el mensaje de error del cuerpo de la respuesta, si es que existe
            const mensaje = errorData?.mensaje || response.statusText || 'Error al actualizar la categoría';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al actualizar la categoría: ', error);
    }
}
// PATCH ../api/api-categorias.php?id=1 — actualizar parcial (body: {nombre?, descripcion?})
// DELETE ../api/api-categorias.php?id=1 — eliminar
// Funciones generales
async function eventoCrearCategoria(){
    const nombre = document.getElementById('nombre').value.trim(); // El método .value obtiene el valor del input con id 'nombre'
    const descripcion = document.getElementById('descripcion').value.trim(); // El método .value obtiene el valor del input con id 'descripcion'
    if (!nombre) {
        console.log('El nombre es obligatorio');
        return;
    }
    await crearCategoria(nombre, descripcion);
}
async function poblarFormularioEdicion(id){
    const categoria = await getCategoriaPorId(id);
    console.log('Categoría obtenida para poblar el formulario de edición: ', categoria.nombre);
    console.log('Categoría obtenida para poblar el formulario de edición: ', categoria.descripcion);
    const formularioEdicion = document.getElementById('categoria-edit-form');
    const nombre = formularioEdicion.querySelector('#nombre');
    const descripcion = formularioEdicion.querySelector('#descripcion');
    if(categoria){
        nombre.value = categoria.nombre;
        descripcion.value = categoria.descripcion;
    }else{
        console.log('No se pudo poblar el formulario de edición: categoría no encontrada');
    }
}
async function obtenerId(id){
    // Redirige a la página de edición con el ID de la categoría como parámetro en la URL
    window.location.href = `edit.php?id=${id}`; // Redirige a la página de edición con el ID de la categoría como parámetro en la URL
    const categoriaId = new URLSearchParams(window.location.search).get('id'); // Una vez que redirige, obtiene el ID de la categoría desde la URL
    if(categoriaId){
        await poblarFormularioEdicion(categoriaId); // Llama a la función poblarFormularioEdicion() para llenar el formulario con los datos de la categoría obtenida por ID
    }else{
        console.log('No se pudo obtener el ID de la categoría desde la URL');
    }
}
// Llamadas de funciones y eventos
document.addEventListener('DOMContentLoaded', () => {
    getCategorias();
    // Se crea esta variable para almacenar el formulario de alta de categorías y se agrega un listener al evento submit del formulario. Así, cuando se envíe el formulario se manda a llamar a la función eventoCrearCategoria() que se encarga de obtener los valores de los inputs y llamar a la función crearCategoria() para enviar los datos al servidor.
    const categoriaCreateForm = document.getElementById('categoria-create-form');
    if (categoriaCreateForm) {
        categoriaCreateForm.addEventListener('submit', (event) => {
            event.preventDefault(); // Evita que el formulario se envíe de la manera tradicional
            eventoCrearCategoria();
        });
    }
});
/**BARRA BUSCADORA CON GET */
async function buscarCategoria(){
alert("Ahorita solo funcia el botón Buscar. Para volver a mostrar todas las categorías es necesario recargar la página.");
    const nombre = document.getElementById("buscar").value.trim();
    if(nombre.length < 3){
        alert("Escribe al menos 3 caracteres.");
        return;
    }
    const response = await fetch(`${URL_BASE}api-categorias.php?nombre=${encodeURIComponent(nombre)}`);
    const categorias = await response.json();
    const tbody = document.querySelector("#tabla-categorias tbody");
    tbody.innerHTML = "";
    if(categorias.mensaje){
        tbody.innerHTML = `
            <tr>
                <td colspan="4">${categorias.mensaje}</td>
            </tr>
        `;
        return;
    }
    categorias.forEach(categoria=>{
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${categoria.id}</td>
            <td>${categoria.nombre}</td>
            <td>${categoria.descripcion}</td>
            <td>
                <a href="edit.php?id=${categoria.id}" class="btn btn-sm btn-warning">
                    Editar
                </a>
                <a href="delete.php?id=${categoria.id}" class="btn btn-sm btn-danger">
                    Eliminar
                </a>
            </td>
        `;
        tbody.appendChild(tr);
    });
    console.log(categorias);
}