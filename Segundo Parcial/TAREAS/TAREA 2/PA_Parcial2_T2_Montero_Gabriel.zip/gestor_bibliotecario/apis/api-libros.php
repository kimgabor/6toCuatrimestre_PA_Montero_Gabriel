<?php
require_once('../config/connection.php');
// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];
// Respuesta para preflight
if ($method === "OPTIONS") {
    http_response_code(200);
    exit;}
switch ($method) {
    case 'GET':
        // Obtener libro por ID
        // api-libros.php?id=1
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT libros.id, libros.titulo, libros.isbn, libros.anio_publicacion, libros.editorial,  libros.cantidad,  libros.disponibles,  libros.id_categoria FROM libros WHERE libros.id = ? ");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array(
                    "mensaje" => "Libro no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        }
        // Buscar libro por título
        // api-libros.php?titulo=java
        elseif (isset($_GET['titulo'])) {
            $titulo = trim($_GET['titulo']);
            $stmt = $conn->prepare("SELECT libros.id, libros.titulo, libros.isbn, categorias.nombre AS categoria, libros.anio_publicacion,  libros.editorial, libros.cantidad,  libros.disponibles FROM libros INNER JOIN categorias  ON libros.id_categoria = categorias.id WHERE libros.titulo LIKE ? ");
            $titulo_param = "%".$titulo."%";
            $stmt->bind_param("s", $titulo_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            if (count($libros) > 0) {
                http_response_code(200);
                echo json_encode($libros);
            } else {
                http_response_code(404);
                echo json_encode(array(
                    "mensaje" => "Libro no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        }
        // Buscar libros por año
        // api-libros.php?anio_publicacion=2024
        elseif (isset($_GET['anio_publicacion'])) {
            $anio = intval($_GET['anio_publicacion']);
            $stmt = $conn->prepare("SELECT libros.id,libros.titulo, libros.isbn, categorias.nombre AS categoria, libros.anio_publicacion, libros.editorial,libros.cantidad,libros.disponibles FROM libros INNER JOIN categorias ON libros.id_categoria = categorias.id WHERE libros.anio_publicacion = ? ");
            $stmt->bind_param("i", $anio);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode($libros);
            $stmt->close();
            $conn->close();
        }
        // Buscar libros por categoría
        // api-libros.php?id_categoria=1
        elseif (isset($_GET['id_categoria'])) {
            $id_categoria = intval($_GET['id_categoria']);
            $stmt = $conn->prepare("SELECT  libros.id,  libros.titulo,  libros.isbn, categorias.nombre AS categoria, libros.anio_publicacion, libros.editorial, libros.cantidad,   libros.disponibles  FROM libros  INNER JOIN categorias   ON libros.id_categoria = categorias.id WHERE libros.id_categoria = ? ");
            $stmt->bind_param("i", $id_categoria);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode($libros);
            $stmt->close();
            $conn->close();
        }
        // Buscar libros por disponibles
        // api-libros.php?disponibles=5
        elseif (isset($_GET['disponibles'])) {
            $disponibles = intval($_GET['disponibles']);
            $stmt = $conn->prepare("SELECT libros.id, libros.titulo, libros.isbn, categorias.nombre AS categoria, libros.anio_publicacion,  libros.editorial,  libros.cantidad,   libros.disponibles  FROM libros   INNER JOIN categorias   ON libros.id_categoria = categorias.id  WHERE libros.disponibles = ? ");
            $stmt->bind_param("i", $disponibles);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode($libros);
            $stmt->close();
            $conn->close();
        }
        // Buscar libros por editorial
        // api-libros.php?editorial=Pearson
        elseif (isset($_GET['editorial'])) {
            $editorial = trim($_GET['editorial']);
            $editorial_param = "%" . $editorial . "%";
            $stmt = $conn->prepare("SELECT  libros.id, libros.titulo,libros.isbn,categorias.nombre AS categoria,libros.anio_publicacion,libros.editorial,libros.cantidad,libros.disponibles FROM libros INNER JOIN categorias ON libros.id_categoria = categorias.id WHERE libros.editorial LIKE ?");
            $stmt->bind_param("s", $editorial_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode($libros);
            $stmt->close();
            $conn->close();
        }
        // Obtener todos los libros
        // api-libros.php
        else {
            $stmt = $conn->prepare("SELECT libros.id, libros.titulo,  libros.isbn, categorias.nombre AS categoria,  libros.anio_publicacion, libros.editorial,  libros.cantidad, libros.disponibles  FROM libros INNER JOIN categorias ON libros.id_categoria = categorias.id  ORDER BY libros.id ");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            http_response_code(200);
            echo json_encode($libros);
            $stmt->close();
            $conn->close();
        }
        break;
    // Crear libro
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if ($data === null) {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "JSON inválido"
            ));
            break;
        }
        $titulo = trim($data['titulo'] ?? "");
        $isbn = trim($data['isbn'] ?? "");
        $anio_publicacion = trim($data['anio_publicacion'] ?? "");
        $editorial = trim($data['editorial'] ?? "");
        $cantidad = intval($data['cantidad'] ?? 0);
        $disponibles = intval($data['disponibles'] ?? 0);
        $id_categoria = intval($data['id_categoria'] ?? 0);
        $fecha_registro = trim($data['fecha_registro'] ?? "");
        if (
            !empty($titulo) &&
            !empty($isbn) &&
            !empty($anio_publicacion) &&
            !empty($editorial) &&
            $cantidad > 0 &&
            $disponibles >= 0 &&
            $id_categoria > 0 &&
            !empty($fecha_registro)
        ) {
            $stmt = $conn->prepare("INSERT INTO libros(titulo,isbn,anio_publicacion,editorial,cantidad,disponibles,id_categoria,fecha_registro)
            VALUES(?,?,?,?,?,?,?,?)");
            $stmt->bind_param(
                "ssssiiis",$titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria, $fecha_registro);
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array(
                    "mensaje" => "Libro creado exitosamente"
                ));
            } else {
                http_response_code(500);
                echo json_encode(array(
                    "mensaje" => "Error al crear el libro"
                ));
            }
            $stmt->close();
            $conn->close();
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "Todos los campos son obligatorios"
            ));
        }
    break;
    // Actualizar libro completo
    case 'PUT':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $titulo = trim($data['titulo'] ?? "");
            $isbn = trim($data['isbn'] ?? "");
            $anio_publicacion = trim($data['anio_publicacion'] ?? "");
            $editorial = trim($data['editorial'] ?? "");
            $cantidad = intval($data['cantidad'] ?? 0);
            $disponibles = intval($data['disponibles'] ?? 0);
            $id_categoria = intval($data['id_categoria'] ?? 0);
            if ( !empty($titulo) && !empty($isbn) && !empty($anio_publicacion) && !empty($editorial) && $cantidad > 0 && $disponibles >= 0 && $id_categoria > 0) {
                $stmt = $conn->prepare("UPDATE libros SET titulo=?,  isbn=?,  anio_publicacion=?,  editorial=?,  cantidad=?,  disponibles=?,  id_categoria=? WHERE id=?  ");
                $stmt->bind_param(  "ssssiiii",  $titulo,  $isbn,  $anio_publicacion,  $editorial, $cantidad, $disponibles, $id_categoria,  $id );
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array(
                        "mensaje" => "Libro actualizado exitosamente"
                    ));
                } else {
                    http_response_code(500);
                    echo json_encode(array(
                        "mensaje" => "Error al actualizar el libro"
                    ));
                }
                $stmt->close();
                $conn->close();
            } else {
                http_response_code(400);
                echo json_encode(array(
                    "mensaje" => "Todos los campos son obligatorios"
                ));
            }
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "El id es obligatorio"
            ));
        }
    break;
    // Actualización parcial
    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $titulo = trim($data['titulo'] ?? "");
            $isbn = trim($data['isbn'] ?? "");
            $anio_publicacion = trim($data['anio_publicacion'] ?? "");
            $editorial = trim($data['editorial'] ?? "");
            $cantidad = intval($data['cantidad'] ?? 0);
            $disponibles = intval($data['disponibles'] ?? 0);
            $id_categoria = intval($data['id_categoria'] ?? 0);
            if ( !empty($titulo) || !empty($isbn) || !empty($anio_publicacion) || !empty($editorial) || $cantidad > 0 || $disponibles >= 0 || $id_categoria > 0  ) {
                $stmt = $conn->prepare("UPDATE libros SET titulo = COALESCE(NULLIF(?,''),titulo), isbn = COALESCE(NULLIF(?,''),isbn), anio_publicacion = COALESCE(NULLIF(?,''),anio_publicacion), editorial = COALESCE(NULLIF(?,''),editorial), cantidad = COALESCE(NULLIF(?,0),cantidad), disponibles = COALESCE(NULLIF(?,0),disponibles),  id_categoria = COALESCE(NULLIF(?,0),id_categoria) WHERE id= ?  ");
                $stmt->bind_param(
                    "ssssiiii", $titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria, $id );
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array(
                        "mensaje" => "Libro actualizado parcialmente"
                    ));
                } else {
                    http_response_code(500);
                    echo json_encode(array(
                        "mensaje" => "Error al actualizar el libro"
                    ));
                }
                $stmt->close();
                $conn->close();
            } else {
                http_response_code(400);
                echo json_encode(array(
                    "mensaje" => "Debe enviar al menos un campo"
                ));
            }
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "El id es obligatorio"
            ));
        }
    break;
    // Eliminar libro
    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM libros WHERE id=?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array(
                    "mensaje" => "Libro eliminado correctamente"
                ));
            } else {
                http_response_code(500);
                echo json_encode(array(
                    "mensaje" => "Error al eliminar el libro"
                ));
            }
            $stmt->close();
            $conn->close();
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "El id es obligatorio"
            ));
        }
    break;
    default:
        http_response_code(405);
        echo json_encode(array(
            "mensaje" => "Método no permitido"
        ));
    break;
}