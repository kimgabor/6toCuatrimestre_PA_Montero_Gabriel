<?php
require_once('../config/connection.php');
// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];
// Respuesta para preflight
if ($method === "OPTIONS") {
    http_response_code(200);
    exit;
}
switch ($method) {
    case 'GET':
        // Obtener un rol por ID
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre FROM roles WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $rol = $resultado->fetch_assoc();
                http_response_code(200);
                echo json_encode($rol);
            } else {
                http_response_code(404);
                echo json_encode(array(
                    "mensaje" => "Rol no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        } else {
            // Obtener todos los roles
            $stmt = $conn->prepare("SELECT * FROM roles");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $roles = array();
            while ($row = $resultado->fetch_assoc()) {
                $roles[] = $row;
            }
            http_response_code(200);
            echo json_encode($roles);
            $stmt->close();
            $conn->close();
        }
    break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if ($data === null) {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "JSON inválido"
            ));
            exit;
        }
        $nombre = trim($data['nombre'] ?? "");
        if (!empty($nombre)) {
            $stmt = $conn->prepare("INSERT INTO roles(nombre) VALUES(?)");
            $stmt->bind_param("s", $nombre);
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array(
                    "mensaje" => "Rol creado exitosamente"
                ));
            } else {
                http_response_code(500);
                echo json_encode(array(
                    "mensaje" => "Error al crear el rol"
                ));
            }
            $stmt->close();
            $conn->close();
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "El nombre es obligatorio"
            ));
        }
    break;

    case 'PUT':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $verificar = $conn->prepare("SELECT id FROM roles WHERE id = ?");
            $verificar->bind_param("i", $id);
            $verificar->execute();
            if ($verificar->get_result()->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array(
                    "mensaje" => "El rol no existe"
                ));
                exit;
            }
            $data = json_decode(file_get_contents("php://input"), true);
            if ($data === null) {
                http_response_code(400);
                echo json_encode(array(
                    "mensaje" => "JSON inválido"
                ));
                exit;
            }
            $nombre = trim($data['nombre'] ?? "");
            if (!empty($nombre)) {
                $stmt = $conn->prepare("UPDATE roles SET nombre=? WHERE id=?");
                $stmt->bind_param("si", $nombre, $id);
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array(
                        "mensaje" => "Rol actualizado exitosamente"
                    ));
                } else {
                    http_response_code(500);
                    echo json_encode(array(
                        "mensaje" => "Error al actualizar el rol"
                    ));
                }
                $stmt->close();
                $conn->close();
            } else {
                http_response_code(400);
                echo json_encode(array(
                    "mensaje" => "El nombre es obligatorio"
                ));
            }
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "El id es obligatorio"
            ));
        }
    break;
    
    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $verificar = $conn->prepare("SELECT id FROM roles WHERE id=?");
            $verificar->bind_param("i", $id);
            $verificar->execute();
            if ($verificar->get_result()->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array(
                    "mensaje" => "El rol no existe"
                ));
                exit;
            }
            $data = json_decode(file_get_contents("php://input"), true);
            if ($data === null) {
                http_response_code(400);
                echo json_encode(array(
                    "mensaje" => "JSON inválido"
                ));
                exit;
            }
            $nombre = trim($data['nombre'] ?? "");
            if (!empty($nombre)) {
                $stmt = $conn->prepare("UPDATE roles
                    SET nombre = COALESCE(NULLIF(?,''),nombre)
                    WHERE id=?");
                $stmt->bind_param("si", $nombre, $id);
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array(
                        "mensaje" => "Rol actualizado parcialmente"
                    ));
                } else {
                    http_response_code(500);
                    echo json_encode(array(
                        "mensaje" => "Error al actualizar el rol"
                    ));
                }
                $stmt->close();
                $conn->close();
            } else {
                http_response_code(400);
                echo json_encode(array(
                    "mensaje" => "Debe enviar al menos un campo"
                ));
            }
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "El id es obligatorio"
            ));
        }
    break;
    
    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $verificar = $conn->prepare("SELECT id FROM roles WHERE id=?");
            $verificar->bind_param("i", $id);
            $verificar->execute();
            if ($verificar->get_result()->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array(
                    "mensaje" => "El rol no existe"
                ));
                exit;
            }
            $stmt = $conn->prepare("DELETE FROM roles WHERE id=?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array(
                    "mensaje" => "Rol eliminado exitosamente"
                ));
            } else {
                http_response_code(500);
                echo json_encode(array(
                    "mensaje" => "Error al eliminar el rol"
                ));
            }
            $stmt->close();
            $conn->close();
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "El id es obligatorio"
            ));
        }
    break;
    
    default:
        http_response_code(405);
        echo json_encode(array(
            "mensaje" => "Método no permitido"
        ));
    break;
}