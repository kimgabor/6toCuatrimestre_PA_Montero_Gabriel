<?php
require_once('../config/connection.php');
// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
        case 'GET':
        // Buscar usuario por ID
            // Buscar usuario por ID
if(isset($_GET['id'])){
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, password, telefono, id_rol, activo,  fecha_registro FROM usuarios WHERE id = ? ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    if($resultado->num_rows > 0){
        echo json_encode($resultado->fetch_assoc());
    }else{
        echo json_encode(array(
            "mensaje" => "Usuario no encontrado"
        ));
    }
    $stmt->close();
    $conn->close();
}
        // Buscar usuario por nombre
        elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido FROM usuarios WHERE nombre LIKE ?");
            $nombre_param = "%".$nombre."%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();
            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }
            echo json_encode($usuarios);
            $stmt->close();
            $conn->close();
        }
        // Buscar usuario por correo
        elseif (isset($_GET['correo'])) {
            $correo = trim($_GET['correo']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo FROM usuarios WHERE correo = ?");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                echo json_encode(array(
                    "mensaje" => "Correo no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        }
        // Obtener todos los usuarios
        else {
            $stmt = $conn->prepare("SELECT * FROM usuarios");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();
            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }
            echo json_encode($usuarios);
            $stmt->close();
            $conn->close();
        }
        break;
            case 'POST':
    $data = json_decode(file_get_contents("php://input"), true);
    if ($data === null) {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "JSON inválido"
        ));
        break;
    }
    $nombre = trim($data['nombre'] ?? "");
    $apellido = trim($data['apellido'] ?? "");
    $correo = trim($data['correo'] ?? "");
    $password = trim($data['password'] ?? "");
    $telefono = trim($data['telefono'] ?? "");
    $id_rol = intval($data['id_rol'] ?? 0);
    $activo = intval($data['activo'] ?? 1);
    if ( !empty($nombre) && !empty($apellido) && !empty($correo) && !empty($password) && $id_rol > 0 )
         { $stmt = $conn->prepare("INSERT INTO usuarios(nombre, apellido, correo, password, telefono, id_rol, activo)VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "sssssii",$nombre,$apellido,$correo,$password,$telefono,$id_rol,$activo );
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array(
                "mensaje" => "Usuario creado exitosamente"
            ));
        } else {
            http_response_code(500);
            echo json_encode(array(
                "mensaje" => "Error al crear el usuario: " . $stmt->error
            ));
        }
        $stmt->close();
        $conn->close();
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "Los campos obligatorios están incompletos"
        ));
    }
break;
                case 'PUT':
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        if ($data === null) {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "JSON inválido"
            ));
            break;
        }
        $nombre = trim($data['nombre'] ?? "");
        $apellido = trim($data['apellido'] ?? "");
        $correo = trim($data['correo'] ?? "");
        $password = trim($data['password'] ?? "");
        $telefono = trim($data['telefono'] ?? "");
        $id_rol = intval($data['id_rol'] ?? 0);
        $activo = intval($data['activo'] ?? 1);
        if ( !empty($nombre) && !empty($apellido) && !empty($correo) && !empty($password) && $id_rol > 0
        ) { $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ?, telefono = ?,id_rol = ?,activo = ? WHERE id = ?");
            $stmt->bind_param( "sssssiii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $id
            );
            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array(
                    "mensaje" => "Usuario actualizado exitosamente"
                ));
            } else {
                http_response_code(500);
                echo json_encode(array(
                    "mensaje" => "Error al actualizar el usuario: " . $stmt->error
                ));
            }
            $stmt->close();
            $conn->close();
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "Todos los campos obligatorios deben enviarse"
            ));
        }
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "El id es obligatorio para actualizar un usuario"
        ));
    }
break;
                case 'DELETE':
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array(
                "mensaje" => "Usuario eliminado exitosamente"
            ));
        } else {
            http_response_code(500);
            echo json_encode(array(
                "mensaje" => "Error al eliminar el usuario: " . $stmt->error
            ));
        }
        $stmt->close();
        $conn->close();
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "El id es obligatorio para eliminar un usuario"
        ));
    }
break;
    default:
        http_response_code(405);
        echo json_encode(array(
            "mensaje" => "Método no permitido"
        ));
        break;
} 