<?php
require_once('../config/connection.php');
// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];
// Procesar la solicitud
switch ($method) {
case 'GET':
        // Buscar autor por ID
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $autor = $resultado->fetch_assoc();
                echo json_encode($autor);
            } else {
                echo json_encode(array(
                    "mensaje" => "Autor no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        }
        // Buscar autor por nombre
        elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido FROM autores WHERE nombre LIKE ?");
            $nombre_param = "%".$nombre."%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            if (count($autores) > 0) {
                echo json_encode($autores);
            } else {
                echo json_encode(array(
                    "mensaje" => "Autor no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        }
        // Buscar autor por nacionalidad
        elseif (isset($_GET['nacionalidad'])) {
            $nacionalidad = trim($_GET['nacionalidad']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad FROM autores WHERE nacionalidad LIKE ?");
            $nacionalidad_param = "%".$nacionalidad."%";
            $stmt->bind_param("s", $nacionalidad_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            if (count($autores) > 0) {
                echo json_encode($autores);
            } else {
                echo json_encode(array(
                    "mensaje" => "Autor no encontrado"
                ));
            }
            $stmt->close();
            $conn->close();
        } 
        //Obtener autores nacidos despues de cierta fecha
        elseif(isset($_GET['fecha_nacimiento'])){
            $fecha_nacimiento = trim($_GET['fecha_nacimiento']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, fecha_nacimiento FROM autores WHERE fecha_nacimiento > ?");
            $stmt->bind_param("s", $fecha_nacimiento);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()){
                $autores[] = $row;
            } 
            if(count($autores) > 0){
                echo json_encode($autores);
            } else{
                echo json_encode(array( "mensaje" => "Autores no encontrados"));
            }
            $stmt->close();
            $conn->close();
        }
        // Obtener todos los autores
        else {
            $stmt = $conn->prepare("SELECT * FROM autores");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            echo json_encode($autores);
            $stmt->close();
            $conn->close();
        }
        break;
case 'POST':
    $data = json_decode(file_get_contents("php://input"), true);
    if ($data === null) {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "JSON inválido"
        ));
        break;
    }
    $nombre = trim($data['nombre'] ?? "");
    $apellido = trim($data['apellido'] ?? "");
    $nacionalidad = trim($data['nacionalidad'] ?? "");
    $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
    if (
        !empty($nombre) &&
        !empty($apellido) &&
        !empty($nacionalidad) &&
        !empty($fecha_nacimiento)
    ) {
        $stmt = $conn->prepare("INSERT INTO autores(nombre, apellido, nacionalidad, fecha_nacimiento) VALUES(  ?,?,?,? )");
        $stmt->bind_param(
            "ssss",$nombre,$apellido,$nacionalidad,$fecha_nacimiento);
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array(
                "mensaje" => "Autor creado exitosamente"
            ), JSON_UNESCAPED_UNICODE);
            } else {
            http_response_code(500);
            echo json_encode(array(
                "mensaje" => "Error al crear el autor"
            ), JSON_UNESCAPED_UNICODE);}
        $stmt->close();
        $conn->close();
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "Todos los campos son obligatorios"
        ), JSON_UNESCAPED_UNICODE);
    }
break;
case 'PUT':
    if (isset($_GET['id'])) {
     $id = intval($_GET['id']);
     $data = json_decode(file_get_contents("php://input"), true);
     if ($data === null) {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "JSON inválido"));
            break;}
        $nombre = trim($data['nombre'] ?? "");
        $apellido = trim($data['apellido'] ?? "");
        $nacionalidad = trim($data['nacionalidad'] ?? "");
        $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
        if (
            !empty($nombre) &&
            !empty($apellido) &&
            !empty($nacionalidad) &&
            !empty($fecha_nacimiento)
        ) {
            $stmt = $conn->prepare("UPDATE autores SET nombre = ?, apellido = ?, nacionalidad = ?, fecha_nacimiento = ? WHERE id = ? ");
            $stmt->bind_param(
                "ssssi",$nombre,$apellido,$nacionalidad,$fecha_nacimiento,$id);
            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array(
                    "mensaje" => "Autor actualizado exitosamente"
                ), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array(
                    "mensaje" => "Error al actualizar el autor"
                ), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "Todos los campos son obligatorios"
            ), JSON_UNESCAPED_UNICODE);
        }
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "El id es obligatorio"
        ), JSON_UNESCAPED_UNICODE);
    }
break;

case 'PATCH':
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        if ($data === null) {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "JSON inválido"
            ));
            break;
        }
        $nombre = trim($data['nombre'] ?? "");
        $apellido = trim($data['apellido'] ?? "");
        $nacionalidad = trim($data['nacionalidad'] ?? "");
        $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
        if (
            !empty($nombre) ||
            !empty($apellido) ||
            !empty($nacionalidad) ||
            !empty($fecha_nacimiento)
        ) {
            $stmt = $conn->prepare("UPDATE autores SET nombre = COALESCE(NULLIF(?,''), nombre), apellido = COALESCE(NULLIF(?,''), apellido), nacionalidad = COALESCE(NULLIF(?,''), nacionalidad), fecha_nacimiento = COALESCE(NULLIF(?,''), fecha_nacimiento)  WHERE id = ?");
            $stmt->bind_param(
                "ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id);
            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array(
                    "mensaje" => "Autor actualizado parcialmente"
                ), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array(
                    "mensaje" => "Error al actualizar el autor"
                ), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } else {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "Debe enviar al menos un campo"
            ), JSON_UNESCAPED_UNICODE);
        }
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "El id es obligatorio"
        ), JSON_UNESCAPED_UNICODE);
    }
break;
case 'DELETE':
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("DELETE FROM autores WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array(
                "mensaje" => "Autor eliminado exitosamente"
            ), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array(
                "mensaje" => "Error al eliminar el autor"
            ), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        $conn->close();
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "El id es obligatorio"
        ), JSON_UNESCAPED_UNICODE);
    }
break;
default:
    http_response_code(405);
    echo json_encode(array(
        "mensaje" => "Método no permitido"
    ), JSON_UNESCAPED_UNICODE);
break;
}