<?php
require_once('../config/connection.php');
// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
    // Obtener préstamo por ID
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT prestamos.id, prestamos.id_usuario, usuarios.nombre AS Usuario, detalle_prestamo.id_libro, libros.titulo AS Libro, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios  ON prestamos.id_usuario = usuarios.id  INNER JOIN detalle_prestamo  ON prestamos.id = detalle_prestamo.id_prestamo  INNER JOIN libros  ON detalle_prestamo.id_libro = libros.id WHERE prestamos.id = ? ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        if ($resultado->num_rows > 0) {
            echo json_encode($resultado->fetch_assoc());
        } else {
            echo json_encode(array(
                "mensaje" => "Préstamo no encontrado"
            ));
        }
        $stmt->close();
        $conn->close();
    }
    // Buscar préstamos por usuario
    elseif (isset($_GET['id_usuario'])) {
        $id_usuario = intval($_GET['id_usuario']);
        $stmt = $conn->prepare("SELECT prestamos.id, usuarios.nombre AS Usuario, libros.titulo AS Libro, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios     ON prestamos.id_usuario = usuarios.id INNER JOIN detalle_prestamo   ON prestamos.id = detalle_prestamo.id_prestamo INNER JOIN libros  ON detalle_prestamo.id_libro = libros.id  WHERE prestamos.id_usuario = ? ");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $prestamos = array();
        while ($row = $resultado->fetch_assoc()) {
            $prestamos[] = $row;
        }
        if (count($prestamos) > 0) {
            echo json_encode($prestamos);
        } else {
            echo json_encode(array(
                "mensaje" => "No existen préstamos para ese usuario"
            ));
        }
        $stmt->close();
        $conn->close();
    }
    // Buscar por estado
    elseif (isset($_GET['estado'])) {
        $estado = trim($_GET['estado']);
        $estado_param = "%".$estado."%";
        $stmt = $conn->prepare("SELECT prestamos.id, usuarios.nombre AS Usuario, libros.titulo AS Libro, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios ON prestamos.id_usuario = usuarios.id INNER JOIN detalle_prestamo ON prestamos.id = detalle_prestamo.id_prestamo INNER JOIN libros ON detalle_prestamo.id_libro = libros.id WHERE prestamos.estado LIKE ?");
        $stmt->bind_param("s", $estado_param);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $prestamos = array();
        while ($row = $resultado->fetch_assoc()) {
            $prestamos[] = $row;
        }
        if (count($prestamos) > 0) {
            echo json_encode($prestamos);
        } else {
            echo json_encode(array(
                "mensaje" => "No existen préstamos con ese estado"
            ));
        }
        $stmt->close();
        $conn->close();
    }
    // Obtener todos los préstamos
    else {
        $stmt = $conn->prepare("SELECT prestamos.id, usuarios.nombre AS Usuario, libros.titulo AS Libro, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios ON prestamos.id_usuario = usuarios.id INNER JOIN detalle_prestamo  ON prestamos.id = detalle_prestamo.id_prestamo INNER JOIN libros ON detalle_prestamo.id_libro = libros.id ORDER BY prestamos.fecha_prestamo DESC  ");
        $stmt->execute();
        $resultado = $stmt->get_result();
        $prestamos = array();
        while ($row = $resultado->fetch_assoc()) {
            $prestamos[] = $row;
        }
        echo json_encode($prestamos);
        $stmt->close();
        $conn->close();
    }
break;
       case 'POST':
    $data = json_decode(file_get_contents("php://input"), true);
    if ($data === null) {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "JSON inválido"
        ));
        break;
    }
    $id_usuario = intval($data["id_usuario"] ?? 0);
    $id_libro = intval($data["id_libro"] ?? 0);
    $fecha_prestamo = trim($data["fecha_prestamo"] ?? "");
    $fecha_devolucion = trim($data["fecha_devolucion"] ?? "");
    $estado = trim($data["estado"] ?? "");
    if ( $id_usuario <= 0 || $id_libro <= 0 || empty($fecha_prestamo) || empty($fecha_devolucion) || empty($estado) ) {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "Todos los campos son obligatorios"
        ));
        break;
    }
    $conn->begin_transaction();
    try {
        // Insertar préstamo
        $stmt1 = $conn->prepare("INSERT INTO prestamos( id_usuario, fecha_prestamo, fecha_devolucion, estado ) VALUES (  ?, ?, ?, ? )");
        $stmt1->bind_param(
            "isss", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado);
        $stmt1->execute();
        // Obtener el ID del préstamo recién creado
        $id_prestamo = $conn->insert_id;
        // Insertar detalle del préstamo
        $stmt2 = $conn->prepare("INSERT INTO detalle_prestamo(    id_prestamo, id_libro ) VALUES (  ?, ? ) ");
        $stmt2->bind_param(
            "ii", $id_prestamo, $id_libro);
        $stmt2->execute();
        $conn->commit();
        http_response_code(201);
        echo json_encode(array(
            "mensaje" => "Préstamo creado exitosamente"
        ));
        $stmt1->close();
        $stmt2->close();
        $conn->close();
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(array(
            "mensaje" => "Error al crear el préstamo: " . $e->getMessage()
        ));
    }
break;
            case 'PUT':
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "El id es obligatorio para actualizar un préstamo"
        ));
        break;
    }
    $id = intval($_GET['id']);
    $data = json_decode(file_get_contents("php://input"), true);
    if ($data === null) {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "JSON inválido"
        ));
        break;
    }
    $id_usuario = intval($data["id_usuario"] ?? 0);
    $id_libro = intval($data["id_libro"] ?? 0);
    $fecha_prestamo = trim($data["fecha_prestamo"] ?? "");
    $fecha_devolucion = trim($data["fecha_devolucion"] ?? "");
    $estado = trim($data["estado"] ?? "");
    if ( $id_usuario <= 0 ||  $id_libro <= 0 ||  empty($fecha_prestamo) ||  empty($fecha_devolucion) ||  empty($estado)) {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "Todos los campos son obligatorios"
        ));
        break;
    }
    $conn->begin_transaction();
    try {
        // Actualizar préstamo
        $stmt1 = $conn->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ?, estado = ? WHERE id = ?");
        $stmt1->bind_param(
            "isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id );
        $stmt1->execute();
        // Actualizar libro del préstamo
        $stmt2 = $conn->prepare("UPDATE detalle_prestamo SET id_libro = ? WHERE id_prestamo = ?");
        $stmt2->bind_param(
            "ii",$id_libro, $id
        );
        $stmt2->execute();
        $conn->commit();
        http_response_code(200);
        echo json_encode(array(
            "mensaje" => "Préstamo actualizado exitosamente"
        ));
        $stmt1->close();
        $stmt2->close();
        $conn->close();
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(array(
            "mensaje" => "Error al actualizar el préstamo: " . $e->getMessage()
        ));
    }
break;
                case 'PATCH':
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        if ($data === null) {
            http_response_code(400);
            echo json_encode(array(
                "mensaje" => "JSON inválido"
            ));
            break;
        }
        $id_usuario = intval($data["id_usuario"] ?? 0);
        $fecha_prestamos = trim($data["fecha_prestamos"] ?? "");
        $fecha_devolucion = trim($data["fecha_devolucion"] ?? "");
        $estado = trim($data["estado"] ?? "");
        $stmt = $conn->prepare("UPDATE prestamos SET id_usuario = COALESCE(NULLIF(?,0), id_usuario), fecha_prestamo = COALESCE(NULLIF(?,''), fecha_prestamo), fecha_devolucion = COALESCE(NULLIF(?,''), fecha_devolucion), estado = COALESCE(NULLIF(?,''), estado) WHERE id = ?");
        $stmt->bind_param(
            "isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array(
                "mensaje" => "Préstamo actualizado parcialmente"
            ));
        } else {
            http_response_code(500);
            echo json_encode(array(
                "mensaje" => "Error al actualizar el préstamo: " . $stmt->error
            ));
        }
        $stmt->close();
        $conn->close();
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "El id es obligatorio"
        ));
    }
break;
                    case 'DELETE':
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("DELETE FROM prestamos WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array(
                "mensaje" => "Préstamo eliminado exitosamente"
            ));
        } else {
            http_response_code(500);
            echo json_encode(array(
                "mensaje" => "Error al eliminar el préstamo: " . $stmt->error
            ));
        }
        $stmt->close();
        $conn->close();
    } else {
        http_response_code(400);
        echo json_encode(array(
            "mensaje" => "El id es obligatorio para eliminar un préstamo"
        ));
    }
break;
    default:
        http_response_code(405);
        echo json_encode(array( "mensaje" => "Método no permitido"));
        break;
}