<?php
require_once('../config/connection.php');
// Lo hice 100% en prestamos
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        // Buscar por ID
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, cantidad FROM detalle_prestamo WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $detalle = $resultado->fetch_assoc();
                echo json_encode($detalle);
            } else {
                echo json_encode(array( "mensaje" => "Registro no encontrado"));
            }
            $stmt->close();
            $conn->close();
        }
        // Buscar por préstamo
        elseif (isset($_GET['id_prestamo'])) {
            $id_prestamo = intval($_GET['id_prestamo']);
            $stmt = $conn->prepare("SELECT id, cantidad, id_prestamo FROM detalle_prestamo WHERE id_prestamo = ?");
            $stmt->bind_param("i", $id_prestamo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalle = array();
            while ($row = $resultado->fetch_assoc()) {
                $detalle[] = $row;
            }
            if (count($detalle) > 0) {
                echo json_encode($detalle);
            } else {
                echo json_encode(array("mensaje" => "No existen registros para ese préstamo"));
            }
            $stmt->close();
            $conn->close();
        }
        // Buscar por libro
        elseif (isset($_GET['id_libro'])) {
            $id_libro = intval($_GET['id_libro']);
            $stmt = $conn->prepare("SELECT id, cantidad, id_libro FROM detalle_prestamo WHERE id_libro = ?");
            $stmt->bind_param("i", $id_libro);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalle = array();
            while ($row = $resultado->fetch_assoc()) {
                $detalle[] = $row;
            }
            if (count($detalle) > 0) {
                echo json_encode($detalle);
            } else {
                echo json_encode(array("mensaje" => "No existen registros para ese libro"));
            }
            $stmt->close();
            $conn->close();
        }
        // Obtener todos
        else {
            $stmt = $conn->prepare("SELECT * FROM detalle_prestamo");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalle = array();
            while ($row = $resultado->fetch_assoc()) {
                $detalle[] = $row;
            }
            echo json_encode($detalle);
            $stmt->close();
            $conn->close();
        }
        break;
    default:
    http_response_code(405);
    echo json_encode(array("mensaje" => "Método no permitido"));
    break;
}