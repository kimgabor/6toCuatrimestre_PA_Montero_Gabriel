<?php
require_once __DIR__ . '/config.php';
$mysqli = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME,DB_PORT);
if ($mysqli->connect_errno) {
    http_response_code(500);
    die(json_encode([
        "success" => false,
        "message" => "Error al conectar con la base de datos.",
        "dev" => $mysqli->connect_error
    ]));
}
$mysqli->set_charset("utf8mb4");