<?php
define('DB_HOST', 'localhost');
define('DB_PORT', 3307);
define('DB_NAME', 'gestor_alumnos');
define('DB_USER', 'root');
define('DB_PASS', '');
define('URL_BASE', 'http://localhost/gestoralumnossex/');
date_default_timezone_set('America/Merida');
error_reporting(E_ALL);
ini_set('display_errors', 1);