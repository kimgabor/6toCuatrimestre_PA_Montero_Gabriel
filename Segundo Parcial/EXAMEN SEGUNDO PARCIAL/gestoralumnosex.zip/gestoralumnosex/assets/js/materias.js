const API_MATERIAS = "../api/materias.php";
const API_CARRERAS = "../api/carreras.php";
const API_CUATRIMESTRES = "../api/cuatrimestres.php";
document.addEventListener("DOMContentLoaded", () => {
    cargarCarreras();
    cargarCuatrimestres();
    cargarMaterias();
    document
        .getElementById("buscarMateria")
        .addEventListener("input", cargarMaterias);
    document
        .getElementById("filtroCarrera")
        .addEventListener("change", cargarMaterias);
    document
        .getElementById("filtroCuatrimestre")
        .addEventListener("change", cargarMaterias);
    document
        .getElementById("btnActualizar")
        .addEventListener("click", () => {
            document.getElementById("buscarMateria").value = "";
            document.getElementById("filtroCarrera").value = "";
            document.getElementById("filtroCuatrimestre").value = "";
            cargarMaterias();
        });
});
async function cargarCarreras() {
    try {
        const response = await fetch(API_CARRERAS);
        const resultado = await response.json();
        const select = document.getElementById("filtroCarrera");
        resultado.data.forEach(carrera => {
            select.innerHTML += `
                <option value="${carrera.id}">
                    ${carrera.nombre}
                </option>
            `;
        });
    } catch (error) {
        console.error(error);
    }
}
async function cargarCuatrimestres() {
    try {
        const response = await fetch(API_CUATRIMESTRES);
        const resultado = await response.json();
        const select = document.getElementById("filtroCuatrimestre");
        resultado.data.forEach(cuatrimestre => {
            select.innerHTML += `
                <option value="${cuatrimestre.id}">
                    ${cuatrimestre.nombre}
                </option>
            `;
        });
    } catch (error) {
        console.error(error);
    }
}
async function cargarMaterias() {
    mostrarSpinner();
    try {
        const nombre = document.getElementById("buscarMateria").value;
        const carrera = document.getElementById("filtroCarrera").value;
        const cuatrimestre = document.getElementById("filtroCuatrimestre").value;
        let parametros = [];
        if (nombre !== "") {
            parametros.push(`nombre=${encodeURIComponent(nombre)}`);
        }
        if (carrera !== "") {
            parametros.push(`carrera=${carrera}`);
        }
        if (cuatrimestre !== "") {
            parametros.push(`cuatrimestre=${cuatrimestre}`);
        }
        let url = API_MATERIAS;
        if (parametros.length > 0) {
            url += "?" + parametros.join("&");
        }
        const response = await fetch(url);
        const resultado = await response.json();
        if (!resultado.success) {
            mostrarSinResultados();
            return;
        }
        mostrarMaterias(resultado.data);
    } catch (error) {
        console.error(error);
        mostrarAlerta(
            "No fue posible cargar las materias.",
            "danger"
        );
    }
}
function mostrarMaterias(datos) {
    const tbody = document.getElementById("tbodyMaterias");
    let html = "";
    datos.forEach(materia => {
        html += `
        <tr>
            <td class="text-center">
                ${materia.id}
            </td>
            <td>
                ${materia.materia}
            </td>
            <td class="text-center">
                ${materia.creditos}
            </td>
            <td>
                ${materia.carrera}
            </td>
            <td>
                ${materia.cuatrimestre}
            </td>
        </tr>
        `;
    });
    tbody.innerHTML = html;
}
function mostrarSpinner() {
    document.getElementById("tbodyMaterias").innerHTML = `
        <tr>
            <td colspan="5" class="text-center py-5">
                <div class="spinner-border text-primary"></div>
                <div class="mt-3">
                    Cargando materias...
                </div>
            </td>
        </tr>
    `;
}
function mostrarSinResultados() {
    document.getElementById("tbodyMaterias").innerHTML = `
        <tr>
            <td colspan="5" class="text-center py-5 text-muted">
                No se encontraron materias.
            </td>
        </tr>
    `;
}
function mostrarAlerta(mensaje, tipo) {
    document.getElementById("alertas").innerHTML = `
        <div class="alert alert-${tipo} alert-dismissible fade show">
            ${mensaje}
            <button
                class="btn-close"
                data-bs-dismiss="alert">
            </button>
        </div>
    `;
}