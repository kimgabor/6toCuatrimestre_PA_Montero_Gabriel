const API = "../api/alumnos.php";
const tbody = document.getElementById("tbodyAlumnos");
const form = document.getElementById("formAlumno");
const modal = new bootstrap.Modal(
    document.getElementById("modalAlumno")
);
const idAlumno = document.getElementById("idAlumno");
const nombre = document.getElementById("nombre");
const apellido = document.getElementById("apellido");
const email = document.getElementById("email");
const telefono = document.getElementById("telefono");
const fechaNacimiento = document.getElementById("fechaNacimiento");
const activo = document.getElementById("activo");
const buscarNombre = document.getElementById("buscarNombre");
const buscarApellido = document.getElementById("buscarApellido");
const btnActualizar = document.getElementById("btnActualizar");
const btnNuevo = document.getElementById("btnNuevo");
const tituloModal = document.getElementById("tituloModal");
const alertas = document.getElementById("alertas");
document.addEventListener("DOMContentLoaded", () => {
    obtenerAlumnos();
});
btnActualizar.addEventListener("click", obtenerAlumnos);
btnNuevo.addEventListener("click", () => {
    limpiarFormulario();
    tituloModal.textContent = "Nuevo Alumno";
});
buscarNombre.addEventListener("keyup", obtenerAlumnos);
buscarApellido.addEventListener("keyup", obtenerAlumnos);
form.addEventListener("submit", guardarAlumno);
function obtenerAlumnos() {
    let url = API;
    const parametros = [];
    if (buscarNombre.value.trim() !== "") {
        parametros.push(
            "nombre=" + encodeURIComponent(buscarNombre.value.trim())
        );
    }
    if (buscarApellido.value.trim() !== "") {
        parametros.push(
            "apellido=" + encodeURIComponent(buscarApellido.value.trim())
        );
    }
    if (parametros.length > 0) {
        url += "?" + parametros.join("&");
    }
    fetch(url)
        .then(response => response.json())
        .then(resultado => {
            renderizarTabla(resultado.data || []);
        })
        .catch(error => console.error(error));
}
function renderizarTabla(alumnos) {
    tbody.innerHTML = "";
    if (alumnos.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center py-4">
                    No hay alumnos registrados.
                </td>
            </tr>
        `;
        return;
    }
    alumnos.forEach(alumno => {
        tbody.innerHTML += `
            <tr>
                <td>${alumno.id_alumno}</td>
                <td>${alumno.nombre}</td>
                <td>${alumno.apellido}</td>
                <td>${alumno.email}</td>
                <td>${alumno.telefono ?? ""}</td>
                <td>${alumno.fecha_nacimiento ?? ""}</td>
                <td>
                    ${alumno.activo == 1
                        ? '<span class="badge bg-success">Activo</span>'
                        : '<span class="badge bg-danger">Inactivo</span>'
                    }
                </td>
                <td>
                    <button
                        class="btn btn-warning btn-sm me-1"
                        onclick="editarAlumno(${alumno.id_alumno})">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button
                        class="btn btn-danger btn-sm"
                        onclick="eliminarAlumno(${alumno.id_alumno})">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
}
function editarAlumno(id) {
    fetch(API + "?id=" + id)
        .then(response => response.json())
        .then(resultado => {
            if (!resultado.success) {
                mostrarAlerta(resultado.message, "danger");
                return;
            }
            const alumno = resultado.data[0];
            idAlumno.value = alumno.id_alumno;
            nombre.value = alumno.nombre;
            apellido.value = alumno.apellido;
            email.value = alumno.email;
            telefono.value = alumno.telefono;
            fechaNacimiento.value = alumno.fecha_nacimiento;
            activo.value = alumno.activo;
            tituloModal.textContent = "Editar Alumno";
            modal.show();
        });
}
function guardarAlumno(e) {
    e.preventDefault();
    const datos = {
        nombre: nombre.value.trim(),
        apellido: apellido.value.trim(),
        email: email.value.trim(),
        telefono: telefono.value.trim(),
        fecha_nacimiento: fechaNacimiento.value,
        activo: activo.value
    };
    let metodo = "POST";
    let url = API;
    if (idAlumno.value !== "") {
        metodo = "PUT";
        url += "?id=" + idAlumno.value;
    }
    fetch(url, {
        method: metodo,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(datos)
    })
    .then(response => response.json())
    .then(resultado => {
        mostrarAlerta(
            resultado.message,
            resultado.success ? "success" : "danger"
        );
        if (resultado.success) {
            modal.hide();
            limpiarFormulario();
            obtenerAlumnos();
        }
    });
}
function eliminarAlumno(id) {
    if (!confirm("¿Desea eliminar este alumno?")) {
        return;
    }
    fetch(API + "?id=" + id, {
        method: "DELETE"
    })
    .then(response => response.json())
    .then(resultado => {
        mostrarAlerta(
            resultado.message,
            resultado.success ? "success" : "danger"
        );
        if (resultado.success) {
            obtenerAlumnos();
        }
    });
}
function limpiarFormulario() {
    form.reset();
    idAlumno.value = "";
    activo.value = "1";
}
function mostrarAlerta(mensaje, tipo) {
    alertas.innerHTML = `
        <div class="alert alert-${tipo} alert-dismissible fade show">
            ${mensaje}
            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert">
            </button>
        </div>
    `;
    setTimeout(() => {
        alertas.innerHTML = "";
    }, 3000);
}