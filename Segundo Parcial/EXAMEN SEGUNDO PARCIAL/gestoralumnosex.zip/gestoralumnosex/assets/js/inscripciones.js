const API_INSCRIPCIONES = '../api/inscripciones.php';
const API_ALUMNOS = '../api/alumnos.php';
const API_MATERIAS = '../api/materias.php';
let modalInscripcion = null;
let listaInscripciones = [];
document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("modalInscripcion");
    if (modal) {
        modalInscripcion = new bootstrap.Modal(modal);
    }
    document.getElementById("formInscripcion")?.addEventListener("submit", guardarInscripcion);
    document.getElementById("btnNuevo")?.addEventListener("click", () => {
        limpiarFormulario();
        modalInscripcion?.show();
    });
    document.getElementById("btnActualizar")?.addEventListener("click", cargarInscripciones);
    document.getElementById("buscarInscripcion")?.addEventListener("input", buscarInscripciones);
    document.getElementById("tbodyInscripciones")?.addEventListener("click", (e) => {
        const boton = e.target.closest(".btnEliminar");
        if (boton) {
            eliminarInscripcion(boton.dataset.id);
        }
    });
    cargarAlumnos();
    cargarMaterias();
    cargarInscripciones();
});
async function cargarAlumnos() {
    try {
        const response = await fetch(API_ALUMNOS);
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.message || "Error al obtener alumnos");
        }
        const select = document.getElementById("selectAlumno");
        if (!select) return;
        select.innerHTML = "";
        const opcion = document.createElement("option");
        opcion.value = "";
        opcion.textContent = "Seleccione un alumno";
        select.appendChild(opcion);
        result.data.forEach(alumno => {
            const option = document.createElement("option");
            option.value = alumno.id;
            option.textContent =
                `${alumno.matricula} - ${alumno.nombre} ${alumno.apellido_paterno} ${alumno.apellido_materno}`;
            select.appendChild(option);
        });
    } catch (error) {
        console.error(error);
        mostrarAlerta(error.message, "danger");
    }
}
async function cargarMaterias() {
    try {
        const response = await fetch(API_MATERIAS);
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.message || "Error al obtener materias");
        }
        const select = document.getElementById("selectMateria");
        if (!select) return;
        select.innerHTML = "";
        const opcion = document.createElement("option");
        opcion.value = "";
        opcion.textContent = "Seleccione una materia";
        select.appendChild(opcion);
        result.data.forEach(materia => {
            const option = document.createElement("option");
            option.value = materia.id;
            option.textContent = materia.materia;
            select.appendChild(option);
        });
    } catch (error) {
        console.error(error);
        mostrarAlerta(error.message, "danger");
    }
}
async function cargarInscripciones() {
    mostrarSpinner();
    try {
        const response = await fetch(API_INSCRIPCIONES);
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.message || "Error al obtener inscripciones");
        }
        listaInscripciones = result.data || [];
        renderizarTabla(listaInscripciones);
    } catch (error) {
        console.error(error);
        renderizarTabla([]);
        mostrarAlerta(error.message, "danger");
    } finally {
        ocultarSpinner();
    }
}
function renderizarTabla(data) {
    const tbody = document.getElementById("tbodyInscripciones");
    if (!tbody) return;
    if (!data.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-muted py-4">
                    No se encontraron registros.
                </td>
            </tr>
        `;
        return;
    }
    tbody.innerHTML = data.map(ins => `
        <tr>
            <td>${ins.id}</td>
            <td>${ins.nombre_completo_alumno ?? ""}</td>
            <td>${ins.materia ?? ""}</td>
            <td>${ins.carrera ?? ""}</td>
            <td>${ins.cuatrimestre ?? ""}</td>
            <td>${ins.fecha_inscripcion ?? ""}</td>
            <td>${ins.calificacion ?? "-"}</td>
            <td>${ins.periodo ?? ""}</td>
            <td class="text-end">
                <button
                    class="btn btn-sm btn-outline-danger btnEliminar"
                    data-id="${ins.id}">
                    <i class="bi bi-trash-fill"></i>
                </button>
            </td>
        </tr>
    `).join("");
}
async function guardarInscripcion(e) {
    e.preventDefault();
    const calificacion = document
        .getElementById("calificacion")
        .value
        .trim();
    const payload = {
        id_alumno: document.getElementById("selectAlumno").value,
        id_materia: document.getElementById("selectMateria").value,
        fecha_inscripcion: document.getElementById("fechaInscripcion").value,
        calificacion: calificacion === ""
            ? null
            : parseFloat(calificacion),
        periodo: document
            .getElementById("periodo")
            .value
            .trim()
    };
    if (
        !payload.id_alumno ||
        !payload.id_materia ||
        !payload.fecha_inscripcion ||
        !payload.periodo
    ) {
        mostrarAlerta(
            "Todos los campos excepto calificación son obligatorios.",
            "warning"
        );
        return;
    }
    try {
        const response = await fetch(API_INSCRIPCIONES, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(
                result.message ||
                "Error al guardar la inscripción"
            );
        }
        modalInscripcion?.hide();
        limpiarFormulario();
        await cargarInscripciones();
        mostrarAlerta(
            result.message || "Inscripción registrada correctamente.",
            "success"
        );
    } catch (error) {
        console.error(error);
        mostrarAlerta(error.message, "danger");
    }
}
async function eliminarInscripcion(id) {
    if (!confirm("¿Está seguro de eliminar esta inscripción?")) {
        return;
    }
    try {
        const response = await fetch(
            `${API_INSCRIPCIONES}?id=${id}`,
            {
                method: "DELETE"
            }
        );
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(
                result.message ||
                "Error al eliminar la inscripción"
            );
        }
        await cargarInscripciones();
        mostrarAlerta(
            result.message ||
            "Inscripción eliminada correctamente.",
            "success"
        );
    } catch (error) {
        console.error(error);
        mostrarAlerta(error.message, "danger");
    }
}
function buscarInscripciones() {
    const termino = document
        .getElementById("buscarInscripcion")
        .value
        .toLowerCase()
        .trim();
    const filtradas = listaInscripciones.filter(ins => {
        return (
            (ins.nombre_completo_alumno ?? "")
                .toLowerCase()
                .includes(termino) ||
            (ins.materia ?? "")
                .toLowerCase()
                .includes(termino) ||
            (ins.carrera ?? "")
                .toLowerCase()
                .includes(termino) ||
            (ins.periodo ?? "")
                .toLowerCase()
                .includes(termino)
        );
    });
    renderizarTabla(filtradas);
}
function limpiarFormulario() {
    document.getElementById("formInscripcion")?.reset();
    const id = document.getElementById("idInscripcion");
    if (id) {
        id.value = "";
    }
    document.getElementById("fechaInscripcion").value =
        new Date().toISOString().split("T")[0];
}
function mostrarSpinner() {
    const tbody = document.getElementById("tbodyInscripciones");
    if (!tbody) return;
    tbody.innerHTML = `
        <tr>
            <td colspan="8" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
            </td>
        </tr>
    `;
}
function ocultarSpinner() {
}
function mostrarAlerta(mensaje, tipo) {
    const contenedor = document.getElementById("alertas");
    if (!contenedor) return;
    const alerta = document.createElement("div");
    alerta.className = `alert alert-${tipo} alert-dismissible fade show`;
    alerta.setAttribute("role", "alert");
    alerta.innerHTML = `
        ${mensaje}
        <button
            type="button"
            class="btn-close"
            data-bs-dismiss="alert"
            aria-label="Cerrar">
        </button>
    `;
    contenedor.appendChild(alerta);
    setTimeout(() => {
        if (alerta.parentNode) {
            bootstrap.Alert
                .getOrCreateInstance(alerta)
                .close();
        }
    }, 4000);
}