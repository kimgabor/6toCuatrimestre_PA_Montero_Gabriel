<?php
require_once __DIR__ . '/../config/connection.php';
header('Content-Type: application/json; charset=utf-8');
$method = $_SERVER['REQUEST_METHOD'];
try {
    switch ($method) {
        case 'GET':
            obtenerAlumnos($mysqli);
            break;
        case 'POST':
            registrarAlumno($mysqli);
            break;
        case 'PUT':
            actualizarAlumno($mysqli);
            break;
        case 'DELETE':
            eliminarAlumno($mysqli);
            break;
        default:
            respuesta(
                false,
                "Método no permitido.",
                null,
                405
            );
            break;
    }
} catch (mysqli_sql_exception $e) {
    respuesta(
        false,
        "Error interno en la base de datos.",
        $e->getMessage(),
        500
    );
} catch (Exception $e) {
    respuesta(
        false,
        "Error interno del servidor.",
        $e->getMessage(),
        500
    );
}
/*=========================================================
=            FUNCIONES AUXILIARES
=========================================================*/
function respuesta($success, $message, $data = null, $code = 200)
{
    http_response_code($code);
    $response = [
        "success" => $success,
        "message" => $message
    ];
    if ($data !== null) {
        $response["data"] = $data;
    }
    echo json_encode($response);
    exit;
}
/*=========================================
=            OBTENER JSON
=========================================*/
function obtenerJSON()
{
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data) {
        respuesta(
            false,
            "Datos JSON inválidos o vacíos.",
            null,
            400
        );
    }
    return $data;
}
/*=========================================
=            EXISTE ALUMNO
=========================================*/
function existeAlumno($mysqli, $id)
{
    $stmt = $mysqli->prepare(
        "SELECT id_alumno
         FROM alumnos
         WHERE id_alumno = ?"
    );
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}
/*=========================================
=            GET
=========================================*/
function obtenerAlumnos($mysqli)
{
    $sql = "
        SELECT
            id_alumno,
            nombre,
            apellido,
            email,
            telefono,
            fecha_nacimiento,
            activo
        FROM alumnos
    ";
    $condiciones = [];
    $parametros = [];
    $tipos = "";
    /*=========================================
    =            BUSCAR POR ID
    =========================================*/
    if (isset($_GET["id"]) && !empty($_GET["id"])) {
        $id = filter_var($_GET["id"], FILTER_VALIDATE_INT);
        if ($id !== false) {
            $condiciones[] = "id_alumno = ?";
            $parametros[] = $id;
            $tipos .= "i";
        }
    }
    /*=========================================
    =            FILTRAR POR NOMBRE
    =========================================*/
    if (isset($_GET["nombre"]) && !empty($_GET["nombre"])) {
        $condiciones[] = "nombre LIKE ?";
        $parametros[] = "%" . trim($_GET["nombre"]) . "%";
        $tipos .= "s";
    }
    /*=========================================
    =            FILTRAR POR APELLIDO
    =========================================*/
    if (isset($_GET["apellido"]) && !empty($_GET["apellido"])) {
        $condiciones[] = "apellido LIKE ?";
        $parametros[] = "%" . trim($_GET["apellido"]) . "%";
        $tipos .= "s";
    }
    /*=========================================
    =            ARMAR CONSULTA
    =========================================*/
    if (!empty($condiciones)) {
        $sql .= " WHERE " . implode(" AND ", $condiciones);
    }
    $sql .= " ORDER BY nombre ASC";
    $stmt = $mysqli->prepare($sql);
    if (!empty($parametros)) {
        $stmt->bind_param($tipos, ...$parametros);
    }
    $stmt->execute();
    $resultado = $stmt->get_result();
    $alumnos = [];
    while ($fila = $resultado->fetch_assoc()) {
        $alumnos[] = $fila;
    }
    if (count($alumnos) > 0) {
        respuesta(
            true,
            "Consulta realizada correctamente.",
            $alumnos
        );
    }
    respuesta(
        false,
        "Alumno no encontrado.",
        null,
        404
    );
}
/*=========================================
=            POST
=========================================*/
function registrarAlumno($mysqli)
{
    $data = obtenerJSON();
    if (
        empty($data["nombre"]) ||
        empty($data["apellido"]) ||
        empty($data["email"])
    ) {
        respuesta(
            false,
            "Nombre, apellido y email son obligatorios.",
            null,
            400
        );
    }
    if (!filter_var($data["email"], FILTER_VALIDATE_EMAIL)) {
        respuesta(
            false,
            "El correo electrónico no es válido.",
            null,
            400
        );
    }
    // Verificar correo repetido
    $stmt = $mysqli->prepare(
        "SELECT id_alumno
         FROM alumnos
         WHERE email = ?"
    );
    $stmt->bind_param("s", $data["email"]);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        respuesta(
            false,
            "El correo ya se encuentra registrado.",
            null,
            409
        );
    }
    $nombre = trim($data["nombre"]);
    $apellido = trim($data["apellido"]);
    $email = trim($data["email"]);
    $telefono = $data["telefono"] ?? null;
    $fecha = $data["fecha_nacimiento"] ?? null;
    $activo = isset($data["activo"]) ? intval($data["activo"]) : 1;
    $stmt = $mysqli->prepare(
        "INSERT INTO alumnos
        (
            nombre,
            apellido,
            email,
            telefono,
            fecha_nacimiento,
            activo
        )
        VALUES
        (
            ?, ?, ?, ?, ?, ?
        )"
    );
    $stmt->bind_param(
        "sssssi",
        $nombre,
        $apellido,
        $email,
        $telefono,
        $fecha,
        $activo
    );
    if ($stmt->execute()) {
        respuesta(
            true,
            "Alumno registrado correctamente."
        );
    }
    respuesta(
        false,
        "No fue posible registrar el alumno.",
        null,
        500
    );
}
/*=========================================
=            PUT
=========================================*/
function actualizarAlumno($mysqli)
{
    if (!isset($_GET["id"])) {
        respuesta(
            false,
            "Debe indicar el ID del alumno.",
            null,
            400
        );
    }
    $id = intval($_GET["id"]);
    if (!existeAlumno($mysqli, $id)) {
        respuesta(
            false,
            "El alumno no existe.",
            null,
            404
        );
    }
    $data = obtenerJSON();
    if (
        empty($data["nombre"]) ||
        empty($data["apellido"]) ||
        empty($data["email"])
    ) {
        respuesta(
            false,
            "Nombre, apellido y email son obligatorios.",
            null,
            400
        );
    }
    if (!filter_var($data["email"], FILTER_VALIDATE_EMAIL)) {
        respuesta(
            false,
            "Correo electrónico inválido.",
            null,
            400
        );
    }
    // Verificar que el correo no pertenezca a otro alumno
    $stmt = $mysqli->prepare(
        "SELECT id_alumno
         FROM alumnos
         WHERE email = ?
         AND id_alumno <> ?"
    );
    $stmt->bind_param(
        "si",
        $data["email"],
        $id
    );
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        respuesta(
            false,
            "Ese correo ya pertenece a otro alumno.",
            null,
            409
        );
    }
    $nombre = trim($data["nombre"]);
    $apellido = trim($data["apellido"]);
    $email = trim($data["email"]);
    $telefono = $data["telefono"] ?? null;
    $fecha = $data["fecha_nacimiento"] ?? null;
    $activo = isset($data["activo"]) ? intval($data["activo"]) : 1;
    $stmt = $mysqli->prepare(
        "UPDATE alumnos
        SET
            nombre = ?,
            apellido = ?,
            email = ?,
            telefono = ?,
            fecha_nacimiento = ?,
            activo = ?
        WHERE id_alumno = ?"
    );
    $stmt->bind_param(
        "sssssii",
        $nombre,
        $apellido,
        $email,
        $telefono,
        $fecha,
        $activo,
        $id
    );
    if ($stmt->execute()) {
        respuesta(
            true,
            "Alumno actualizado correctamente."
        );
    }
    respuesta(
        false,
        "No fue posible actualizar el alumno.",
        null,
        500
    );
}
/*=========================================
=            DELETE
=========================================*/
function eliminarAlumno($mysqli)
{
    if (!isset($_GET["id"])) {
        respuesta(
            false,
            "Debe indicar el ID del alumno.",
            null,
            400
        );
    }
    $id = intval($_GET["id"]);
    if (!existeAlumno($mysqli, $id)) {
        respuesta(
            false,
            "El alumno no existe.",
            null,
            404
        );
    }
    $stmt = $mysqli->prepare(
        "DELETE FROM alumnos
         WHERE id_alumno = ?"
    );
    $stmt->bind_param(
        "i",
        $id
    );
    if ($stmt->execute()) {
        respuesta(
            true,
            "Alumno eliminado correctamente."
        );
    }
    respuesta(
        false,
        "No fue posible eliminar el alumno.",
        null,
        500
    );
}