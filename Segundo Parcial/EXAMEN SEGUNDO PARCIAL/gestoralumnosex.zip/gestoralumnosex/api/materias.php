<?php
require_once __DIR__ . '/../config/connection.php';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido. Esta API solo soporta GET.'
    ]);
    exit;
}
try {
    $sql = "SELECT  m.id,  m.nombre AS materia,  m.creditos,  c.nombre AS carrera,  cu.nombre AS cuatrimestre FROM materias m INNER JOIN carreras c ON m.id_carrera = c.id INNER JOIN cuatrimestres cu  ON m.id_cuatrimestre = cu.id";
    $conditions = [];
    $params = [];
    $types = '';
    if (isset($_GET['nombre']) && !empty($_GET['nombre'])) {
        $conditions[] = "m.nombre LIKE ?";
        $params[] = "%" . $_GET['nombre'] . "%";
        $types .= 's';
    }

    if (isset($_GET['carrera']) && !empty($_GET['carrera'])) {
        $carreraId = filter_var($_GET['carrera'], FILTER_VALIDATE_INT);
        if ($carreraId !== false) {
            $conditions[] = "m.id_carrera = ?";
            $params[] = $carreraId;
            $types .= 'i';
        }
    }

    if (isset($_GET['cuatrimestre']) && !empty($_GET['cuatrimestre'])) {
        $cuatrimestreId = filter_var($_GET['cuatrimestre'], FILTER_VALIDATE_INT);
        if ($cuatrimestreId !== false) {
            $conditions[] = "m.id_cuatrimestre = ?";
            $params[] = $cuatrimestreId;
            $types .= 'i';
        }
    }

    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }
    $sql .= " ORDER BY m.nombre ASC";
    $stmt = $mysqli->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    if (count($data) > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Consulta realizada correctamente',
            'data' => $data
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'No se encontraron materias'
        ]);
    }
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno en la base de datos.',
        'dev' => $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno del servidor.',
        'dev' => $e->getMessage()
    ]);
}