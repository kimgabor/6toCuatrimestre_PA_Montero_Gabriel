<?php
require_once __DIR__ . '/../config/connection.php';
header('Content-Type: application/json; charset=utf-8');
 $method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            $sql = "SELECT   i.id,   i.id_alumno,   i.id_materia,   a.matricula,   CONCAT(a.nombre, ' ', a.apellido_paterno, ' ', a.apellido_materno) AS nombre_completo_alumno,   m.nombre AS materia,   c.nombre AS carrera,   cu.nombre AS cuatrimestre,   i.fecha_inscripcion,  i.calificacion,  i.periodo    FROM inscripciones i    INNER JOIN alumnos a ON i.id_alumno = a.id  INNER JOIN materias m ON i.id_materia = m.id   INNER JOIN carreras c ON a.id_carrera = c.id   INNER JOIN cuatrimestres cu ON a.cuatrimestre_actual = cu.id";
            $conditions = [];
            $params = [];
            $types = '';
            if (isset($_GET['id']) && !empty($_GET['id'])) {
                $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
                if ($id !== false) {
                    $conditions[] = "i.id = ?";
                    $params[] = $id;
                    $types .= 'i';
                }
            }
            if (isset($_GET['alumno']) && !empty($_GET['alumno'])) {
                $alumnoId = filter_var($_GET['alumno'], FILTER_VALIDATE_INT);
                if ($alumnoId !== false) {
                    $conditions[] = "i.id_alumno = ?";
                    $params[] = $alumnoId;
                    $types .= 'i';
                }
            }

            if (isset($_GET['materia']) && !empty($_GET['materia'])) {
                $materiaId = filter_var($_GET['materia'], FILTER_VALIDATE_INT);
                if ($materiaId !== false) {
                    $conditions[] = "i.id_materia = ?";
                    $params[] = $materiaId;
                    $types .= 'i';
                }
            }

            if (!empty($conditions)) {
                $sql .= " WHERE " . implode(" AND ", $conditions);
            }

            $sql .= " ORDER BY nombre_completo_alumno ASC";
            $stmt = $mysqli->prepare($sql);
            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }

            $stmt->execute();
            $result = $stmt->get_result();
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            if (count($data) > 0) {
                echo json_encode([
                    'success' => true,
                    'data' => $data
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
    'success' => true,
    'data' => $data
]);
            }
            break;


        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Datos JSON inválidos o vacíos.']);
                exit;
            }

            $id_alumno = filter_var($data['id_alumno'] ?? null, FILTER_VALIDATE_INT);
            $id_materia = filter_var($data['id_materia'] ?? null, FILTER_VALIDATE_INT);
            $fecha_inscripcion = trim($data['fecha_inscripcion'] ?? '');
            $calificacion = isset($data['calificacion']) && $data['calificacion'] !== '' ? filter_var($data['calificacion'], FILTER_VALIDATE_FLOAT) : null;
            $periodo = trim($data['periodo'] ?? '');

            if (!$id_alumno || !$id_materia || empty($fecha_inscripcion) || empty($periodo)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Los campos alumno, materia, fecha y periodo son obligatorios.']);
                exit;
            }

            $stmt = $mysqli->prepare("SELECT id FROM alumnos WHERE id = ?");
            $stmt->bind_param('i', $id_alumno);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'El alumno especificado no existe.']);
                exit;
            }

            $stmt = $mysqli->prepare("SELECT id FROM materias WHERE id = ?");
            $stmt->bind_param('i', $id_materia);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'La materia especificada no existe.']);
                exit;
            }

            $stmt = $mysqli->prepare("SELECT id FROM inscripciones WHERE id_alumno = ? AND id_materia = ? AND periodo = ?");
            $stmt->bind_param('iis', $id_alumno, $id_materia, $periodo);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'El alumno ya está inscrito en esta materia en el periodo especificado.']);
                exit;
            }

            $stmt = $mysqli->prepare("INSERT INTO inscripciones (id_alumno, id_materia, fecha_inscripcion, calificacion, periodo) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param('iisds', $id_alumno, $id_materia, $fecha_inscripcion, $calificacion, $periodo);
            $stmt->execute();

            http_response_code(201);
            echo json_encode(['success' => true, 'message' => 'Inscripción registrada correctamente']);
            break;


        case 'DELETE':
            $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID de inscripción no proporcionado o inválido.']);
                exit;
            }

            $stmt = $mysqli->prepare("SELECT id FROM inscripciones WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Inscripción no encontrada.']);
                exit;
            }

            $stmt = $mysqli->prepare("DELETE FROM inscripciones WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();

            http_response_code(200);
            echo json_encode(['success' => true, 'message' => 'Inscripción eliminada correctamente']);
            break;
        default:
            http_response_code(405);
            echo json_encode([
                'success' => false,
                'message' => 'Método no permitido.'
            ]);
            break;
    }
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno en la base de datos.',
        'dev' => $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno del servidor.',
        'dev' => $e->getMessage()
    ]);
}