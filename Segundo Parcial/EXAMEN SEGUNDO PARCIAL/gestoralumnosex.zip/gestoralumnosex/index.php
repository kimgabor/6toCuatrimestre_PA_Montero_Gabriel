<?php
$titulo = "Inicio";
$modulo = "inicio";
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-dark fw-bold">Sistema Gestor de Alumnos</h1>
            <p class="text-muted">Bienvenido al panel principal del sistema.</p>
        </div>
    </div>
    <div class="row g-4">
        <div class="col-lg-4 col-md-6">
            <div class="card h-100 text-center">
                <div class="card-body d-flex flex-column align-items-center">
                    <i class="bi bi-book-fill display-4 text-primary mb-3"></i>
                    <h5 class="card-title fw-bold">Materias</h5>
                    <p class="card-text text-muted flex-grow-1">
                        Consulta y administra las materias.
                    </p>
                    <a href="materias/" class="btn btn-primary w-100 mt-3">
                        Administrar
                    </a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card h-100 text-center">
                <div class="card-body d-flex flex-column align-items-center">
                    <i class="bi bi-people-fill display-4 text-primary mb-3"></i>
                    <h5 class="card-title fw-bold">Alumnos</h5>
                    <p class="card-text text-muted flex-grow-1">
                        Administra la información de los alumnos.
                    </p>
                    <a href="alumnos/index.php" class="btn btn-primary w-100 mt-3">
                        Administrar
                    </a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card h-100 text-center">
                <div class="card-body d-flex flex-column align-items-center">
                    <i class="bi bi-journal-check display-4 text-primary mb-3"></i>
                    <h5 class="card-title fw-bold">Inscripciones</h5>
                    <p class="card-text text-muted flex-grow-1">
                        Gestiona las inscripciones de alumnos.
                    </p>
                    <a href="inscripciones/" class="btn btn-primary w-100 mt-3">
                        Administrar
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>