<?php
$titulo = "Alumnos";
$modulo = "alumnos";
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<div class="container-fluid">
    <div class="mb-4">
        <h1 class="h3 fw-bold mb-1">
            Gestión de Alumnos
        </h1>
        <p class="text-muted mb-0">
            Administra los alumnos registrados en el sistema.
        </p>
    </div>
    <div id="alertas"></div>
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-header bg-white border-0 py-3">
            <div class="row g-3 align-items-center">
                <!-- Buscar por nombre -->
                <div class="col-lg-4">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="bi bi-person"></i>
                        </span>
                        <input
                            type="text"
                            id="buscarNombre"
                            class="form-control"
                            placeholder="Buscar por nombre">
                    </div>
                </div>
                <!-- Buscar por apellido -->
                <div class="col-lg-4">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="bi bi-person-vcard"></i>
                        </span>
                        <input
                            type="text"
                            id="buscarApellido"
                            class="form-control"
                            placeholder="Buscar por apellido">
                    </div>
                </div>
                <!-- Actualizar -->
                <div class="col-lg-2">
                    <button
                        class="btn btn-outline-primary w-100"
                        id="btnActualizar">
                        <i class="bi bi-arrow-clockwise me-2"></i>
                        Actualizar
                    </button>
                </div>
                <!-- Nuevo -->
                <div class="col-lg-2">
                    <button
                        class="btn btn-primary w-100"
                        id="btnNuevo"
                        data-bs-toggle="modal"
                        data-bs-target="#modalAlumno">
                        <i class="bi bi-plus-circle me-2"></i>
                        Nuevo
                    </button>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Fecha de nacimiento</th>
                            <th>Estado</th>
                            <th width="150">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="tbodyAlumnos">
                        <tr>
                            <td colspan="8" class="text-center py-5">
                                <div class="spinner-border text-primary"></div>
                                <div class="mt-3">
                                    Cargando alumnos...
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . "/modal.php"; ?>
<script src="../assets/js/alumnos.js"></script>
<?php require_once __DIR__ . "/../includes/footer.php"; ?>