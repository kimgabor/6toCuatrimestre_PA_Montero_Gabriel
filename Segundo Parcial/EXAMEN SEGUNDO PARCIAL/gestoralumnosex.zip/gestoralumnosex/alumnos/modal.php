<!-- ==========================================================
=            Modal Alumno
========================================================== -->
<div
    class="modal fade"
    id="modalAlumno"
    tabindex="-1"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Encabezado -->
            <div class="modal-header">
                <h5
                    class="modal-title"
                    id="tituloModal">
                    Nuevo Alumno
                </h5>
                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal">
                </button>
            </div>
            <!-- Formulario -->
            <form id="formAlumno">
                <div class="modal-body">
                    <!-- ID oculto -->
                    <input
                        type="hidden"
                        id="idAlumno">
                    <div class="row g-3">
                        <!-- Nombre -->
                        <div class="col-md-6">
                            <label class="form-label">
                                Nombre
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="nombre"
                                required>
                        </div>
                        <!-- Apellido -->
                        <div class="col-md-6">
                            <label class="form-label">
                                Apellido
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="apellido"
                                required>
                        </div>
                        <!-- Email -->
                        <div class="col-md-6">
                            <label class="form-label">
                                Email
                            </label>
                            <input
                                type="email"
                                class="form-control"
                                id="email"
                                required>
                        </div>
                        <!-- Teléfono -->
                        <div class="col-md-6">
                            <label class="form-label">
                                Teléfono
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="telefono">
                        </div>
                        <!-- Fecha -->
                        <div class="col-md-6">
                            <label class="form-label">
                                Fecha de nacimiento
                            </label>
                            <input
                                type="date"
                                class="form-control"
                                id="fechaNacimiento">
                        </div>
                        <!-- Estado -->
                        <div class="col-md-6">
                            <label class="form-label">
                                Estado
                            </label>
                            <select
                                class="form-select"
                                id="activo">
                                <option value="1">
                                    Activo
                                </option>
                                <option value="0">
                                    Inactivo
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Botones -->
                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        class="btn btn-primary">
                        Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>