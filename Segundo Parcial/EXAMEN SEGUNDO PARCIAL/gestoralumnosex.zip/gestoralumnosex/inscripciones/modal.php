<div class="modal fade" id="modalInscripcion" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="formInscripcion">
                <div class="modal-header">
                    <h5 class="modal-title" id="tituloModal">
                        Nueva Inscripción
                    </h5>
                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                    </button>
                </div>
                <div class="modal-body">
                    <input
                        type="hidden"
                        id="idInscripcion">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="selectAlumno" class="form-label">
                                Alumno
                            </label>
                            <select
                                id="selectAlumno"
                                class="form-select"
                                required>
                                <option value="">
                                    Seleccione un alumno
                                </option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="selectMateria" class="form-label">
                                Materia
                            </label>
                            <select
                                id="selectMateria"
                                class="form-select"
                                required>
                                <option value="">
                                    Seleccione una materia
                                </option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="fechaInscripcion" class="form-label">
                                Fecha de inscripción
                            </label>
                            <input
                                type="date"
                                id="fechaInscripcion"
                                class="form-control"
                                required>
                        </div>
                        <div class="col-md-6">
                            <label for="calificacion" class="form-label">
                                Calificación
                            </label>
                            <input
                                type="number"
                                id="calificacion"
                                class="form-control"
                                step="0.01"
                                min="0"
                                max="100"
                                placeholder="Opcional">
                        </div>
                        <div class="col-md-6">
                            <label for="periodo" class="form-label">
                                Periodo
                            </label>
                            <input
                                type="text"
                                id="periodo"
                                class="form-control"
                                placeholder="Ej. 2026-3"
                                required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        class="btn btn-primary">
                        Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>