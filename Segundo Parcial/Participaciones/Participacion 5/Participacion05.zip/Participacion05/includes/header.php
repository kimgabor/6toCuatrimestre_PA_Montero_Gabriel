<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrera</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <h2><i class="fas fa-book-open"></i> MDC</h2>
        <p>Sistema de Gestión Modo Carrea</p>
    </div>
    <?php $ruta = $_SERVER['PHP_SELF']; ?>
    <nav class="sidebar-nav">
        <a href="../equipo/index.php" <?= strpos($ruta, 'equipo') !== false ? 'class="active"' : '' ?>><i class="fas fa-tags"></i> Equipos</a>
        <a href="../jugadores/index.php" <?= strpos($ruta, 'jugadores') !== false ? 'class="active"' : '' ?>><i class="fas fa-user"></i> Jugadores</a>
        <a href="../transferencias/index.php" <?= strpos($ruta, 'transferencias') !== false ? 'class="active"' : '' ?>><i class="fas fa-book"></i> Transferencias</a>

    </nav>
</aside>

<div class="main-content">
