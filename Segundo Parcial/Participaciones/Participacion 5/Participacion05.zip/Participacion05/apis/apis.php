<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
        //comenzamos con equipos

case 'GET':

    // buscar equipo por ID
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT * FROM equipos WHERE id=?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        if($resultado->num_rows>0){
            echo json_encode($resultado->fetch_assoc());
        }else{
            echo json_encode(["mensaje"=>"Equipo no encontrado"]);
        }
        $stmt->close();
        $conn->close();
    }
    //buscar equipo por nombre
    elseif(isset($_GET['nombre'])){
        $nombre="%".trim($_GET['nombre'])."%";
        $stmt=$conn->prepare("SELECT * FROM equipos WHERE nombre LIKE ?");
        $stmt->bind_param("s",$nombre);
        $stmt->execute();
        $resultado=$stmt->get_result();
        $equipos=[];
        while($row=$resultado->fetch_assoc()){
            $equipos[]=$row;
        }
        echo json_encode($equipos);
        $stmt->close();
        $conn->close();
    }
    //buscar por liga
    elseif(isset($_GET['liga'])){
        $liga="%".trim($_GET['liga'])."%";
        $stmt=$conn->prepare("SELECT * FROM equipos WHERE liga LIKE ?");
        $stmt->bind_param("s",$liga);
        $stmt->execute();
        $resultado=$stmt->get_result();
        $equipos=[];
        while($row=$resultado->fetch_assoc()){
            $equipos[]=$row;
        }
        echo json_encode($equipos);
        $stmt->close();
        $conn->close();
    }
    //buscar por presupuesto
    elseif(isset($_GET['presupuesto'])){
        $presupuesto=floatval($_GET['presupuesto']);
        $stmt=$conn->prepare("SELECT * FROM equipos WHERE presupuesto>=?");
        $stmt->bind_param("d",$presupuesto);
        $stmt->execute();
        $resultado=$stmt->get_result();
        $equipos=[];
        while($row=$resultado->fetch_assoc()){
            $equipos[]=$row;
        }
        echo json_encode($equipos);
        $stmt->close();
        $conn->close();
    }
    // todos los equipos
    elseif(isset($_GET['equipos'])){
        $stmt=$conn->prepare("SELECT * FROM equipos ORDER BY nombre");
        $stmt->execute();
        $resultado=$stmt->get_result();
        $equipos=[];
        while($row=$resultado->fetch_assoc()){
            $equipos[]=$row;
        }
        echo json_encode($equipos);
        $stmt->close();
        $conn->close();
    }

    //todos los jugadores
    elseif(isset($_GET['jugadores'])){
        $stmt=$conn->prepare("SELECT * FROM jugadores");
        $stmt->execute();
        $resultado=$stmt->get_result();
        $jugadores=[];
        while($row=$resultado->fetch_assoc()){
            $jugadores[]=$row;
        }
        echo json_encode($jugadores);
        $stmt->close();
        $conn->close();
    }
    //buscar jugador por nombre
    elseif(isset($_GET['jugador'])){
        $jugador="%".trim($_GET['jugador'])."%";
        $stmt=$conn->prepare("SELECT * FROM jugadores WHERE nombre LIKE ?");
        $stmt->bind_param("s",$jugador);
        $stmt->execute();
        $resultado=$stmt->get_result();
        $jugadores=[];
        while($row=$resultado->fetch_assoc()){
            $jugadores[]=$row;
        }
        echo json_encode($jugadores);
        $stmt->close();
        $conn->close();
    }
    //buscar por posición
    elseif(isset($_GET['posicion'])){
        $posicion=trim($_GET['posicion']);
        $stmt=$conn->prepare("SELECT * FROM jugadores WHERE posicion=?");
        $stmt->bind_param("s",$posicion);
        $stmt->execute();
        $resultado=$stmt->get_result();
        $jugadores=[];
        while($row=$resultado->fetch_assoc()){
            $jugadores[]=$row;
        }
        echo json_encode($jugadores);
        $stmt->close();
        $conn->close();
    }
    // todas las transferencias
    elseif(isset($_GET['transferencias'])){
        $stmt=$conn->prepare("SELECT * FROM transferencias");
        $stmt->execute();
        $resultado=$stmt->get_result();
        $transferencias=[];
        while($row=$resultado->fetch_assoc()){
            $transferencias[]=$row;
        }
        echo json_encode($transferencias);
        $stmt->close();
        $conn->close();
    }
    // buuscar transferencia por jugador
    elseif(isset($_GET['jugador_id'])){
        $jugador_id=intval($_GET['jugador_id']);
        $stmt=$conn->prepare("SELECT * FROM transferencias WHERE jugador_id=?");
        $stmt->bind_param("i",$jugador_id);
        $stmt->execute();
        $resultado=$stmt->get_result();
        $transferencias=[];
        while($row=$resultado->fetch_assoc()){
            $transferencias[]=$row;
        }
        echo json_encode($transferencias);
        $stmt->close();
        $conn->close();
    }
    else{  //default
        echo json_encode([
            "mensaje"=>"Debe indicar un parámetro de búsqueda."
        ]);
    }
break;
/**
 * 1	id Primaria	int(11)			No	Ninguna		AUTO_INCREMENT	Cambiar Cambiar	Eliminar Eliminar	
	*2	nombre	varchar(100)	utf8mb4_general_ci		No	Ninguna			Cambiar Cambiar	Eliminar Eliminar	
	*3	liga	varchar(100)	utf8mb4_general_ci		No	Ninguna			Cambiar Cambiar	Eliminar Eliminar	
	*4	presupuesto	decimal(15,2)			No	Ninguna			Cambiar Cambiar	Eliminar Eliminar	
	*5	creado_en
 */
}