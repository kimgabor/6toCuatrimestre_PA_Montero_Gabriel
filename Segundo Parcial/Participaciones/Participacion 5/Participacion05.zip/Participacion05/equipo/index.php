<?php
require_once "../config/connection.php";
include_once "../includes/header.php";
?>
<div class="page-header">
    <h1><i class="fas fa-users"></i> Equipos</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Equipo
    </a>
</div>
<?php if (isset($_GET["success"])): ?>
<div class="alert alert-success">
    <i class="fas fa-check-circle"></i>
    <?= htmlspecialchars($_GET["success"]) ?>
</div>
<?php elseif (isset($_GET["error"])): ?>
<div class="alert alert-danger">
    <i class="fas fa-exclamation-circle"></i>
    <?= htmlspecialchars($_GET["error"]) ?>
</div>
<?php endif; ?>
<div class="table-container">
    <table>
        <thead>
            <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Liga</th>
            <th>Presupuesto</th>
            <th>Creado en</th>
            <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
<?php
$url = "http://localhost/modocarrera/modocarrera/apis/apis.php?equipos=1";
$respuesta = file_get_contents($url);
if ($respuesta === false) {
    echo "<tr>";
    echo "<td colspan='6'>No se pudo conectar con la API.</td>";
    echo "</tr>";
} else {
    $equipos = json_decode($respuesta, true);
    if (is_array($equipos) && count($equipos) > 0) {
        foreach ($equipos as $equipo) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($equipo["id"]) . "</td>";
            echo "<td>" . htmlspecialchars($equipo["nombre"]) . "</td>";
            echo "<td>" . htmlspecialchars($equipo["liga"]) . "</td>";
            echo "<td>$ " . number_format($equipo["presupuesto"], 2) . "</td>";
            echo "<td>" . htmlspecialchars($equipo["creado_en"]) . "</td>";
            echo "<td>";
            echo "<a href='edit.php?id=" . urlencode($equipo["id"]) . "' class='btn btn-sm btn-warning'>
                    <i class='fas fa-edit'></i> Editar
                  </a> ";
            echo "<a href='delete.php?id=" . urlencode($equipo["id"]) . "' class='btn btn-sm btn-danger'>
                    <i class='fas fa-trash'></i> Eliminar
                  </a>";
            echo "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr>";
        echo "<td colspan='6'>No hay equipos registrados.</td>";
        echo "</tr>";
    }
}
?>
        </tbody>
    </table>
</div>
<?php include_once "../includes/footer.php"; ?>