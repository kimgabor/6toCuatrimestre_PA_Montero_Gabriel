<?php
require_once('../config/connection.php'); // Importa la conexión a la base de datos
// Configuración de encabezados HTTP
header("Access-Control-Allow-Origin: *"); // Permite que cualquier origen pueda acceder a esta API, sin importar su dominio. Esto nos va a ayudar a prevenir los famosos problemas de CORS (Cross-Origin Resource Sharing). ¿Qué es CORS? CORS es una política de seguridad implementada por los navegadores web para restringir las solicitudes HTTP que se puedan hacer a un dominio diferente al que sirvió la página web.
header("Content-Type: application/json; charset=UTF-8"); // Esta cabecer, indica el tipo de contenido que va a ser devuelto por esta API, para este ejemplo, va ser en formato JSON. Además, también especificamos la encodificación de caracteres, en este caso UTF-8.
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE"); // Esta cabecera especifica los métodos HTTP que esta API va a aceptar. Es una cabecera importante para temas de seguridad. ¿Qué ocurre si un cliente intenta hacer una solicitud no permitida? En este caso, el servidor responderá con un código de estado HTTP 405 Method Not Allowed, indicando que el método utilizado en la solicitud no está permitido para el recurso solicitado.
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"); // Esta cabecera especifica los encabezados HTTP que se permitirán en las solicitudes o peticiones recibidas por esta API. Es decir, si un cliente hace una solicitud a esta API, y envía una cabecer no permitida, el servidor responderá con un código de estado HTTP 400 Bad Request, indicando que la solicitud no se pudo procesar debido a encabezados no permitidos.

// Obtener el método HTTP de la solicitud
$method = $_SERVER['REQUEST_METHOD']; // Defino una variable, en este caso yo la definí como "method" (Ojo, no importa el nombre que tú coloques). En esta variable estoy almacenando el método HTTP que se utilizó para hacer la solicitud a esta API. ¿Cómo hago esto? Lo hago utilizando la superglobal $_SERVER, que se comporta como un arreglo asociativo que contiene información sobre el servidor y la solicitud actual. La clave 'REQUEST_METHOD' dentro de $_SERVER nos devuelve el método HTTP utilizado en la solicitud (Que por ende, puede ser GET, POST, PUT, PATCH o DELETE).
// Procesamos la solicitud según el método HTTP
switch ($method) { // Utilizamos la condicional switch-case para evaluar el valor de la variable $method. NOTA: Técnicamente igual podríamos utilizar una estructura if-else, sin embargo el switch-case es un método más limpio
    case 'GET':
        // Bloque de código con estructura y operaciones para manejar solicitudes GET (Si, aquí usarías tus prepared statements, pero tu respuesta será en JSON)
        // Endpoint para obtener categorías filtradas por id - http://localhost/gestor_bibliotecario/api/api-libros.php?titulo=java
        if (isset($_GET['titulo'])) {
    $titulo = trim($_GET['titulo']);  // Si la variable $_GET['id'] está definida, la almacenamos en una variable llamada $id. Nota: También podríamos trabajarla con la variable superglobal.
    $stmt = $conn->prepare(" SELECT id, titulo, anio_publicacion FROM libros WHERE titulo LIKE ? ");
    $titulo_param = "%$titulo%";
    $stmt->bind_param("s", $titulo_param);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $libros = array();
    if ($resultado->num_rows > 0) {
      while ($row = $resultado->fetch_assoc()) {
          $libros[] = $row;
        }
     echo json_encode($libros);
    } else {
     echo json_encode(array(
        "mensaje" => "Libro no encontrado"
        ));

    }

    $stmt->close();
    $conn->close();
}
    elseif (isset($_GET['anio_publicacion'])) { // Endpoint para obtener categorías filtradas por nombre - http://localhost/gestor_bibliotecario/api/api-categorias.php?nombre="Ficcion"
        $anio = intval($_GET['anio_publicacion']);
        $stmt = $conn->prepare("SELECT id, titulo, anio_publicacion FROM libros WHERE anio_publicacion = ? ");
    $stmt->bind_param("i", $anio);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $libros = array();
    while ($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }
    echo json_encode($libros);
    $stmt->close();
    $conn->close();

} elseif (isset($_GET['id_categoria'])) {
    $id_categoria = intval($_GET['id_categoria']);
    $stmt = $conn->prepare("SELECT id, titulo, id_categoria FROM libros WHERE id_categoria= ?");
    $stmt->bind_param("i", $id_categoria);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $libros = array();
    while($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }
    echo json_encode($libros);
    $stmt->close();
    $conn->close();

} elseif (isset($_GET['disponibles'])){
    $disponibles = intval($_GET['disponibles']);
    $stmt = $conn -> prepare ("SELECT id, titulo, disponibles FROM libros WHERE disponibles=?");
    $stmt->bind_param("i", $disponibles);
    $stmt->execute();
    $resultado= $stmt->get_result();
    $libros= array();
    while($row = $resultado->fetch_assoc()){
        $libros[] = $row;
    }
    echo json_encode($libros);
    $stmt->close();
    $conn->close();

} elseif (isset($_GET['editorial'])){
    $editorial = trim($_GET['editorial']);
    $stmt = $conn -> prepare ("SELECT id, titulo, editorial FROM libros WHERE editorial LIKE ?");
    $stmt->bind_param("s", $editorial);
    $stmt->execute();
    $resultado= $stmt->get_result();
    $libros= array();
    while($row = $resultado->fetch_assoc()){
        $libros[] = $row;
    }
    echo json_encode($libros);
    $stmt->close();
    $conn->close();

}
        else {

        $stmt = $conn->prepare("SELECT id, titulo, anio_publicacion FROM libros "); // Operación para obtener todos los registros de la tabla "categorias" - http://localhost/gestor_bibliotecario/api/api-categorias.php
    $stmt->execute();
    $resultado = $stmt->get_result();
    $libros = array();
    while ($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }
    echo json_encode($libros);
    $stmt->close();
    $conn->close();
}
        break;
    case 'POST':
        // Bloque de código con estructura y operaciones para manejar solicitudes POST
        // Operación para crear un nuevo registro en la tabla "categorías"
        $data = json_decode(file_get_contents("php://input"), true); // Aquí lo que estoy haciendo es crear una variable llamada $data, y esta variable contiene la decodificación de los datos JSON, que se realiza mediante el método json_decode(). ¿A qué se refiere o para qué me sirve la decodificación? Recuerda que el cliente envía los datos en formato JSON, entonces para poder trabajarlos en nuestro código PHP necesitamos convertirlos de formato JSON a un formato que PHP pueda entender, en este caso usaremos un arreglo asociativo. El método json_decode() hace tal cual eso, convierte una cadena JSON en una estructura de datos de PHP. El parámetro file_get_contents("php://input") se utiliza para leer el cuerpo de la solicitud HTTP, y el parámetro true, indica que el resultado debe ser un arreglo asociativo.
        $titulo = trim($data['titulo'] ?? "");
        $isbn = trim($data['isbn'] ?? "");
        $anio_publicacion = trim($data['anio_publicacion'] ?? "");
        $editorial = trim($data['editorial'] ?? "");
        $cantidad = intval($data['cantidad'] ?? 0);
        $disponibles = intval($data['disponibles'] ?? 0);
        $id_categoria = intval($data['id_categoria'] ?? 0);
        $fecha_registro = trim($data['fecha_registro'] ?? "");
    
        if(!empty($titulo) && !empty($isbn) && !empty($anio_publicacion) && !empty($editorial) && $cantidad > 0  && $disponibles >= 0 && $id_categoria > 0 && !empty($fecha_registro) ){
            $stmt = $conn->prepare("INSERT INTO libros (titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_registro) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssiiis", $titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria, $fecha_registro);
            if($stmt->execute()){
                http_response_code(201); // Código HTTP indicando que el recurso fue creado exitosamente. Recuerda que el código 201 es un código de estado HTTP que indica que la solicitud se ha completado con éxito y que se ha creado un nuevo recurso como resultado de la solicitud. En este caso, estamos indicando que la categoría fue creada exitosamente.
                echo json_encode(array("mensaje" => "Libro creado exitosamente")); // Con json_encode(), hacemos lo contrario que con json_decode(), es decir, convertimos un arreglo asociativo de PHP a una cadena en formato JSON. Posteriormente enviamos la respuesta al cliente con echo.
            }else{
                http_response_code(500); // Código HTTP indicando que ocurrió un error interno en el servidor.
                echo json_encode(array("mensaje" => "Error al crear el libro " . $stmt->error)); // En caso de que ocurra un error al ejecutar la consulta, enviamos un mensaje de error al cliente con el detalle del error.
            }
        }else{
            http_response_code(400); // Código HTTP indicando que la solicitud es inválida.
            echo json_encode(array("mensaje" => "Todos los campos son obligatorios"));
        }
        break;

//ENCODE & DECODE 


    case 'PUT':
        if(isset($_GET['id'])){
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $titulo = trim($data['titulo'] ?? "");
        $isbn = trim($data['isbn'] ?? "");
        $anio_publicacion = trim($data['anio_publicacion'] ?? "");
        $editorial = trim($data['editorial'] ?? "");
        $cantidad = intval($data['cantidad'] ?? 0);
        $disponibles = intval($data['disponibles'] ?? 0);
        $id_categoria = intval($data['id_categoria'] ?? 0);
             if(!empty($titulo) || !empty($isbn) || !empty($anio_publicacion) || !empty($editorial) || $cantidad > 0 || $disponibles >= 0 || $id_categoria > 0 ){
            $stmt = $conn->prepare("UPDATE libros SET titulo=?, isbn=?, anio_publicacion=?, editorial=?, cantidad=?, disponibles=?, id_categoria=? WHERE id=?");
                 $stmt->bind_param("ssssiiii", $titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria, $id);
                if($stmt->execute()){
                    http_response_code(200); // Código HTTP indicando que la solicitud fue exitosa
                    echo json_encode(array("mensaje" => "Libro actualizado exitosamente"));
                }else{
                    http_response_code(500); // Código HTTP indicando que ocurrió un error en el servidor
                    echo json_encode(array("mensaje" => "Error al actualizar el libro " . $stmt->error));
                }
            }else{
                http_response_code(400); // Código HTTP indicando que la solicitud es inválida
                echo json_encode(array("mensaje" => "Los datos son campos obligatorios"));
            }
        }
        break;
//endpoint http://localhost/gestor_bibliotecario/api/api-libros.php?id=1
        /*
        { “editorial”: “Pearson”, “cantidad”: 50 }
        */
    case 'PATCH':
        // Bloque de código con estructura y operaciones para manejar solicitudes PATCH
         if(isset($_GET['id'])){
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $titulo = trim($data['titulo'] ?? "");
        $isbn = trim($data['isbn'] ?? "");
        $anio_publicacion = trim($data['anio_publicacion'] ?? "");
        $editorial = trim($data['editorial'] ?? "");
        $cantidad = intval($data['cantidad'] ?? 0);
        $disponibles = intval($data['disponibles'] ?? 0);
        $id_categoria = intval($data['id_categoria'] ?? 0);
             if(!empty($titulo) || !empty($isbn) || !empty($anio_publicacion) || !empty($editorial) || $cantidad > 0 || $disponibles >= 0 || $id_categoria > 0){
                $stmt = $conn->prepare("UPDATE libros SET titulo = COALESCE(NULLIF(?, ''), titulo), isbn = COALESCE(NULLIF(?, ''), isbn), anio_publicacion = COALESCE(NULLIF(?, ''), anio_publicacion), editorial = COALESCE(NULLIF(?, ''), editorial), cantidad = COALESCE(NULLIF(?, 0), cantidad), disponibles = COALESCE(NULLIF(?, 0), disponibles), id_categoria = COALESCE(NULLIF(?, 0), id_categoria)  WHERE id = ?");
                 $stmt->bind_param("ssssiiii", $titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria, $id);
                if($stmt->execute()){
                    http_response_code(200); // Código HTTP indicando que la solicitud fue exitosa
                    echo json_encode(array("mensaje" => "Libro actualizado exitosamente"));
                }else{
                    http_response_code(500); // Código HTTP indicando que ocurrió un error en el servidor
                    echo json_encode(array("mensaje" => "Error al actualizar el libro " . $stmt->error));
                }
            }else{
                http_response_code(400); // Código HTTP indicando que la solicitud es inválida
                echo json_encode(array("mensaje" => "El ******* es un campo obligatorio"));
            }
        }
        break;
        //endpoint http://localhost/gestor_bibliotecario/api/api-libros.php?id=1
    case 'DELETE':
        // Bloque de código con estructura y operaciones para manejar solicitudes DELETE
        if(isset($_GET['id'])){
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM libros WHERE id=?");
            $stmt-> bind_param("i", $id);
            if($stmt->execute()){
                http_response_code(200);
                echo json_encode(array("mensaje" => "Libro eliminado correctamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "error al eliminar el libro " . $stmt->error));
            }
        } else {
            http_response_code(400);
                echo json_encode(array("mensaje" => "El id es obligatorio para elimianrlo correctamente"));
        }
        break;
        
    default:
        // Mensajito por si no cae en ninguna de los casos anteriores
        break;
}
