    <footer>
        <p>&copy; <?= date("Y") ?> Gestor Bibliotecario &mdash; Sistema de administración de biblioteca</p>
    </footer>
</div>
<script src="../assets/js/script.js"></script>
</body>
</html>
